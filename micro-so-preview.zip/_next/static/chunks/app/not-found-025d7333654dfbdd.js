(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[345],{5362:(e,i,r)=>{Promise.resolve().then(r.bind(r,8047))},8047:(e,i,r)=>{"use strict";r.r(i),r.d(i,{default:()=>a});var n=r(8946),t=r(954),l=r(3893),c=r(972),s=r(7248),d=r(2048);function a(){let e,i;let r=(0,t.c)(2);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(l.default,{isDark:!0}),r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(i=(0,n.jsxs)(n.Fragment,{children:[e,(0,n.jsx)(c.PreloaderSlide,{children:(0,n.jsxs)(h,{children:[(0,n.jsx)(o,{children:"404"}),(0,n.jsx)(u,{}),(0,n.jsx)(x,{children:"This page could not be found"})]})})]}),r[1]=i):i=r[1],i}let h=(0,s.I4)("div",{...(0,s.vi)((0,s.AH)`
		grid-column: main;
		height: 90vh;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 24px;
		text-align: center;
		color: white;
	`)}),o=(0,s.I4)("h1",{...(0,s.vi)((0,s.AH)`
		${d.Ay.header4};
	`)}),u=(0,s.I4)("div",{...(0,s.vi)((0,s.AH)`
		width: 1px;
		height: 64px;
		background-color: rgb(255 255 255 / 60%);
	`)}),x=(0,s.I4)("div",{...(0,s.vi)((0,s.AH)`
		${d.Ay.body1};
	`)})}},e=>{var i=i=>e(e.s=i);e.O(0,[896,86,821,835,972,757,349,513,705,358],()=>i(5362)),_N_E=e.O()}]);