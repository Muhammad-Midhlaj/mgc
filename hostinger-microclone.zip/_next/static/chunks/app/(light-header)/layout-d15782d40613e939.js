(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[569],{3136:(e,l,r)=>{Promise.resolve().then(r.bind(r,5423))},5423:(e,l,r)=>{"use strict";r.r(l),r.d(l,{default:()=>u});var i=r(8946),t=r(954),a=r(330),o=r(3893),s=r(1765),d=r(972),c=r(7248),n=r(9986);function u(e){let l,r,d,u,f,g;let b=(0,t.c)(8),{children:_}=e;return b[0]===Symbol.for("react.memo_cache_sentinel")?(l=(0,i.jsx)(s.default,{}),r=(0,i.jsx)(o.default,{isDark:!1}),b[0]=l,b[1]=r):(l=b[0],r=b[1]),b[2]===Symbol.for("react.memo_cache_sentinel")?(d=(0,i.jsx)(a.default,{}),b[2]=d):d=b[2],b[3]!==_?(u=(0,i.jsxs)(h,{children:[_,d]}),b[3]=_,b[4]=u):u=b[4],b[5]===Symbol.for("react.memo_cache_sentinel")?(f=(0,i.jsx)(c.kH,{children:{"body:has(.light-layout)":{background:n.A.white4}}}),b[5]=f):f=b[5],b[6]!==u?(g=(0,i.jsxs)(m,{className:"light-layout",children:[l,r,u,f]}),b[6]=u,b[7]=g):g=b[7],g}let m=(0,c.I4)("div",{...(0,c.vi)((0,c.AH)`
		grid-column: fullbleed;
		display: grid;
		grid-template-columns: subgrid;
		${n.A.lightDotBackground};
		color: ${n.A.black1};
	`)}),h=(0,c.I4)(d.PreloaderSlide,(0,c.vi)((0,c.AH)`
		isolation: isolate;
		grid-column: fullbleed;
		display: grid;
		grid-template-columns: subgrid;
		grid-template-rows: 1fr auto;
		overflow-x: clip;
	`))}},e=>{var l=l=>e(e.s=l);e.O(0,[896,86,821,835,865,972,757,349,682,513,705,358],()=>l(3136)),_N_E=e.O()}]);