(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[480],{862:(e,t,r)=>{"use strict";r.d(t,{A:()=>v});var i,o,l,s,n,a,c,p,d,u,h=r(8946),y=r(954),A=r(1839),g=r(4522);function f(){return(f=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function m(){return(m=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}var x=r(7248),k=r(9302);let b=(e,t)=>Math.random()*(t-e)+e;function v(e){let t,r,i,o,l;let s=(0,y.c)(12),{size:n,css:a,className:c,isLight:p}=e;s[0]!==a?(t=void 0===a?{}:a,s[0]=a,s[1]=t):t=s[1];let d=t,u=(0,g.useRef)(null);return s[2]!==n?(r=()=>{if(!u.current)return;let e=.5*n+100,t=.25*n+50,r=()=>{let e=b(-t,t),i=b(3,7);A.Ay.to(u.current,{x:e,duration:i,ease:"sine.inOut",onComplete:r})},i=()=>{let t=b(-e,e),r=b(4,8);A.Ay.to(u.current,{y:t,duration:r,ease:"sine.inOut",onComplete:i})};r(),i()},i=[n],s[2]=n,s[3]=r,s[4]=i):(r=s[3],i=s[4]),(0,k.s)(r,i),s[5]!==p?(o=p?(0,h.jsx)(C,{}):(0,h.jsx)(E,{}),s[5]=p,s[6]=o):o=s[6],s[7]!==c||s[8]!==d||s[9]!==n||s[10]!==o?(l=(0,h.jsx)(w,{className:c,ref:u,extraStyles:d,size:n,children:o}),s[7]=c,s[8]=d,s[9]=n,s[10]=o,s[11]=l):l=s[11],l}let w=(0,x.I4)("div",({extraStyles:e,size:t})=>({...(0,x.vi)((0,x.AH)`
			width: ${t}px;
			height: ${t}px;
			position: absolute;
			border-radius: 50%;
			backdrop-filter: blur(12px);
			will-change: transform, filter;
		`),...e})),C=(0,x.I4)(e=>g.createElement("svg",m({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 201 201"},e),g.createElement("g",{filter:"url(#LightOrb_svg__a)"},g.createElement("circle",{cx:116.727,cy:135.818,r:93.184,fill:"black",fillOpacity:.15,style:{fill:"black",fillOpacity:.15}})),a||(a=g.createElement("circle",{cx:100.817,cy:100.817,r:100.002,fill:"url(#LightOrb_svg__b)",fillOpacity:.5,"data-figma-bg-blur-radius":21.357})),g.createElement("mask",{id:"LightOrb_svg__d",width:201,height:201,x:0,y:0,maskUnits:"userSpaceOnUse",style:{maskType:"alpha"}},c||(c=g.createElement("circle",{cx:100.819,cy:100.817,r:100.002,fill:"url(#LightOrb_svg__c)"}))),g.createElement("g",{mask:"url(#LightOrb_svg__d)"},g.createElement("g",{filter:"url(#LightOrb_svg__e)"},g.createElement("circle",{cx:72.186,cy:74.453,r:44.092,fill:"white",style:{fill:"white",fillOpacity:1}})),g.createElement("g",{filter:"url(#LightOrb_svg__f)"},g.createElement("path",{fill:"white",fillRule:"evenodd",d:"M75.2529 201.273C130.483 201.273 175.255 156.501 175.255 101.271C175.255 75.603 165.585 52.1938 149.689 34.4878C176.098 52.4881 193.438 82.8091 193.438 117.18C193.438 172.41 148.665 217.182 93.4356 217.182C63.8737 217.182 37.3078 204.355 19 183.963C35.027 194.887 54.3942 201.273 75.2529 201.273Z",clipRule:"evenodd",style:{fill:"white",fillOpacity:1}}))),g.createElement("defs",null,p||(p=g.createElement("filter",{id:"LightOrb_svg__a",width:291.824,height:291.825,x:-29.186,y:-10.095,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7077",stdDeviation:26.364}))),d||(d=g.createElement("filter",{id:"LightOrb_svg__e",width:157.276,height:157.276,x:-6.452,y:-4.185,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7077",stdDeviation:17.273}))),u||(u=g.createElement("filter",{id:"LightOrb_svg__f",width:243.53,height:251.787,x:-15.546,y:-.058,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7077",stdDeviation:17.273}))),g.createElement("linearGradient",{id:"LightOrb_svg__b",x1:78.303,x2:230.626,y1:59.712,y2:184.567,gradientUnits:"userSpaceOnUse"},g.createElement("stop",{stopColor:"#EAEAEA",style:{stopColor:"#EAEAEA",stopColor:"color(display-p3 0.9180 0.9180 0.9180)",stopOpacity:1}}),g.createElement("stop",{offset:1,stopColor:"#969696",style:{stopColor:"#969696",stopColor:"color(display-p3 0.5879 0.5879 0.5879)",stopOpacity:1}})),g.createElement("linearGradient",{id:"LightOrb_svg__c",x1:78.305,x2:230.628,y1:59.712,y2:184.567,gradientUnits:"userSpaceOnUse"},g.createElement("stop",{stopColor:"#EAEAEA",style:{stopColor:"#EAEAEA",stopColor:"color(display-p3 0.9180 0.9180 0.9180)",stopOpacity:1}}),g.createElement("stop",{offset:1,stopColor:"#C4C4C4",style:{stopColor:"#C4C4C4",stopColor:"color(display-p3 0.7675 0.7675 0.7675)",stopOpacity:1}})))),{...(0,x.vi)((0,x.AH)`
		overflow: visible;
	`)}),E=(0,x.I4)(e=>g.createElement("svg",f({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 200 200"},e),g.createElement("g",{filter:"url(#DarkOrb_svg__a)"},g.createElement("circle",{cx:115.91,cy:135.003,r:93.184,fill:"black",fillOpacity:.04,style:{fill:"black",fillOpacity:.04}})),i||(i=g.createElement("circle",{cx:100.002,cy:100.002,r:100.002,fill:"url(#DarkOrb_svg__b)",fillOpacity:.2,"data-figma-bg-blur-radius":21.357})),g.createElement("mask",{id:"DarkOrb_svg__d",width:202,height:201,x:-1,y:0,maskUnits:"userSpaceOnUse",style:{maskType:"alpha"}},o||(o=g.createElement("circle",{cx:100,cy:100.002,r:100.002,fill:"url(#DarkOrb_svg__c)"}))),g.createElement("g",{mask:"url(#DarkOrb_svg__d)"},g.createElement("g",{filter:"url(#DarkOrb_svg__e)"},g.createElement("circle",{cx:71.363,cy:73.638,r:44.092,fill:"white",style:{fill:"white",fillOpacity:1}})),g.createElement("g",{filter:"url(#DarkOrb_svg__f)"},g.createElement("path",{fill:"white",fillRule:"evenodd",d:"M74.4342 200.458C129.664 200.458 174.436 155.686 174.436 100.456C174.436 74.7892 164.767 51.3806 148.871 33.6748C175.279 51.6752 192.619 81.9956 192.619 116.366C192.619 171.595 147.846 216.368 92.6165 216.368C63.054 216.368 36.4875 203.54 18.1797 183.147C34.207 194.072 53.5748 200.458 74.4342 200.458Z",clipRule:"evenodd",style:{fill:"white",fillOpacity:1}}))),g.createElement("defs",null,l||(l=g.createElement("filter",{id:"DarkOrb_svg__a",width:291.824,height:291.824,x:-30.002,y:-10.91,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7067",stdDeviation:26.364}))),s||(s=g.createElement("filter",{id:"DarkOrb_svg__e",width:157.276,height:157.276,x:-7.275,y:-5,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7067",stdDeviation:17.273}))),n||(n=g.createElement("filter",{id:"DarkOrb_svg__f",width:243.532,height:251.786,x:-16.366,y:-.871,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},g.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),g.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),g.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_1016_7067",stdDeviation:17.273}))),g.createElement("linearGradient",{id:"DarkOrb_svg__b",x1:77.489,x2:229.811,y1:58.897,y2:183.752,gradientUnits:"userSpaceOnUse"},g.createElement("stop",{stopColor:"#EAEAEA",style:{stopColor:"#EAEAEA",stopColor:"color(display-p3 0.9180 0.9180 0.9180)",stopOpacity:1}}),g.createElement("stop",{offset:1,stopColor:"#969696",style:{stopColor:"#969696",stopColor:"color(display-p3 0.5879 0.5879 0.5879)",stopOpacity:1}})),g.createElement("linearGradient",{id:"DarkOrb_svg__c",x1:77.487,x2:229.809,y1:58.897,y2:183.752,gradientUnits:"userSpaceOnUse"},g.createElement("stop",{stopColor:"#EAEAEA",style:{stopColor:"#EAEAEA",stopColor:"color(display-p3 0.9180 0.9180 0.9180)",stopOpacity:1}}),g.createElement("stop",{offset:1,stopColor:"#C4C4C4",style:{stopColor:"#C4C4C4",stopColor:"color(display-p3 0.7675 0.7675 0.7675)",stopOpacity:1}})))),{...(0,x.vi)((0,x.AH)`
		overflow: visible;
	`)})},993:(e,t,r)=>{"use strict";r.d(t,{default:()=>f});var i=r(8946),o=r(954),l=r(862),s=r(1839),n=r(5895),a=r(1290),c=r(7008),p=r(7248),d=r(9302),u=r(4052),h=r(4522),y=r(9986),A=r(2048),g=r(6253);function f(){let e,t,r,l,p,A,f,b;let E=(0,o.c)(14),O=(0,h.useRef)(null),H=(0,h.useRef)(null),j=(0,h.useRef)(null),L=(0,a.l5)(),_=(0,u.Q)(!1,!1,!1,!0);E[0]!==_||E[1]!==L?(e=()=>{if(!j.current)return;let e=new n.A(j.current);if(!H.current?.children)return;_||(0,g.U)([j.current],{triggerPoint:1,duration:1.2,delay:0,ease:"power3.out",from:{opacity:0,y:200},to:{opacity:1,y:0}});let t=(0,c.A)({trigger:H.current,endTrigger:O.current,start:"center center",end:"bottom bottom",scrub:!0,pin:H.current,pinType:L,smoothLevel:Number.POSITIVE_INFINITY});s.Ay.to(e.chars,{color:y.A.js.black2,stagger:.1,duration:.001,scrollTrigger:{start:()=>t.start,end:()=>t.end,scrub:!0}})},t=[L,_],E[0]=_,E[1]=L,E[2]=e,E[3]=t):(e=E[2],t=E[3]),E[4]===Symbol.for("react.memo_cache_sentinel")?(r={recreateOnResize:!0},E[4]=r):r=E[4],(0,d.s)(e,t,r);let I=_?106.7:151;E[5]!==I?(l=(0,i.jsx)(v,{isLight:!0,size:I}),E[5]=I,E[6]=l):l=E[6];let B=_?75:151;return E[7]!==B?(p=(0,i.jsx)(w,{isLight:!0,size:B}),E[7]=B,E[8]=p):p=E[8],E[9]===Symbol.for("react.memo_cache_sentinel")?(A=(0,i.jsx)(C,{isLight:!0,size:213}),E[9]=A):A=E[9],E[10]===Symbol.for("react.memo_cache_sentinel")?(f=(0,i.jsxs)(k,{ref:j,children:["Designed to let you focus on your work, ",(0,i.jsx)("br",{})," not productivity."]}),E[10]=f):f=E[10],E[11]!==l||E[12]!==p?(b=(0,i.jsx)(m,{ref:O,"data-header-hide":!0,children:(0,i.jsxs)(x,{ref:H,children:[l,p,A,f]})}),E[11]=l,E[12]=p,E[13]=b):b=E[13],b}s.Ay.registerPlugin(n.A);let m=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: relative;
		grid-column: 1 / -1;
		background: ${y.A.white4};
		border-top: 1px solid #e5d8c4;
		${y.A.lightDotBackground};
		display: flex;
		justify-content: center;
		height: 150vh;
	`)}),x=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		display: grid;
		place-items: center;
		place-content: center;
		height: 100vh;
		width: 1440px;
	`)}),k=(0,p.I4)("h1",{...(0,p.vi)((0,p.AH)`
		${A.Ay.custom.oversize4};
		width: 620px;
		color: ${y.A.white5};
		text-align: center;
		z-index: 0;
		transform: translateY(-33%);
	`),...(0,p.ZQ)((0,p.AH)`
		width: 960px;
	`),...(0,p.PK)((0,p.AH)`
		${A.Ay.header5};
		width: 355px;
		transform: translateY(0);
	`)}),b=(0,p.I4)(l.A,{...(0,p.vi)((0,p.AH)`
		position: absolute;
		transform: translateY(-33%);
	`)}),v=(0,p.I4)(b,{...(0,p.vi)((0,p.AH)`
		left: 170px;
		bottom: 249px;
	`),...(0,p.PK)((0,p.AH)`
		left: 110px;
		bottom: unset;
		top: 0;
	`)}),w=(0,p.I4)(b,{...(0,p.vi)((0,p.AH)`
		left: 665px;
		top: 118px;
		z-index: 1;
	`),...(0,p.PK)((0,p.AH)`
		top: 400px;
		right: 70px;
		left: unset;
	`)}),C=(0,p.I4)(b,{...(0,p.vi)((0,p.AH)`
		right: 148px;
		top: 296px;
	`),...(0,p.ZQ)((0,p.AH)`
		display: none;
	`),...(0,p.PK)((0,p.AH)`
		display: none;
	`)})},1373:(e,t,r)=>{"use strict";r.d(t,{default:()=>L});var i=r(8946),o=r(954),l=r(3436),s=r(1839),n=r(1290),a=r(7537),c=r(7008),p=r(7248),d=r(9302),u=r(4052),h=r(9144),y=r(4522),A=r(9986),g=r(2048),f=r(3568),m=r(862),x=r(7606);let k=()=>{let e,t;let r=(0,o.c)(2),[i,l]=(0,y.useState)(!0);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=()=>{if(!a.Bd)return;let e=window.matchMedia("(hover: none)"),t=()=>l(!e.matches);return t(),e.addEventListener("change",t),()=>e.removeEventListener("change",t)},t=[],r[0]=e,r[1]=t):(e=r[0],t=r[1]),(0,y.useEffect)(e,t),i};var b=r(4977);let v={src:"/_next/static/media/Background.9321a94d.png",height:3032,width:6420,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAASFBMVEX917OrrKnQqaUoODc/cGtIp6h2jYpivb0aDQ3/y6OTlox3d3EAAwMZTE5zurt7w8H/1rprwb7/y6n6ybrjt7Ln0bJfbnHVyKl6DUWCAAAADnRSTlP8/v6iNNhw/gv8xOpT2hbLje8AAAAJcEhZcwAALEsAACxLAaU9lqkAAAArSURBVHicBcGHAQAgCAOwOsGFuP//1AREo3cRwZkJCjwEs5fa28A+5uIqfxp6AV/i84heAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:4},w={src:"/_next/static/media/Foreground.c9666dea.png",height:2646,width:6420,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAJ1BMVEVRaVEmLyU5PS8VKiqGb1AZNSg7PiwiOS5fWUMpOSl0XkRoYEsaKiPNMN1OAAAADHRSTlMBlvskjNyoFtE+tD144/LRAAAACXBIWXMAACxLAAAsSwGlPZapAAAAH0lEQVR4nGNgZudkAANWNkYGBgZuRgYeHiYuFg4mHgAEYQBqp+VS7gAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:3};function C({className:e,needsAdjustment:t=!1,ref:r}){let o=(0,b.A)(r),l=(0,y.useRef)(null),n=(0,y.useRef)(null),a=k(),c=(0,y.useCallback)(()=>{let e=o.current?.parentElement?.parentElement,r=o.current?.parentElement;if(!e||!r||!o.current||!t)return;s.Ay.set(o.current,{clearProps:"all"}),o.current.style.scale="1",o.current.style.translate="unset";let i=e.style.transform;e.style.transform="unset";let l=r.style.transform;r.style.transform="unset";let n=e.getBoundingClientRect(),a=o.current.getBoundingClientRect();e.style.transform=i,r.style.transform=l,o.current.style.removeProperty("scale"),o.current.style.removeProperty("translate"),s.Ay.set(o.current,{opacity:1,top:`calc(50% + ${n.top-a.top}px + ${n.height/2}px)`,left:`calc(50% + ${n.left-a.left}px + ${n.width/2}px)`,minWidth:`${n.width}px`,minHeight:`${n.height}px`})},[t,o]);return(0,d.s)(()=>{if(!l.current||!n.current)return;c();let e={duration:.8},t=s.Ay.quickTo(l.current,"xPercent",e),r=s.Ay.quickTo(l.current,"yPercent",e),i=s.Ay.quickTo(n.current,"xPercent",e),o=s.Ay.quickTo(n.current,"yPercent",e);s.Ay.to([l.current,n.current],{scale:1.1});let p=e=>{let l=e.target;for(;l;){if(l.classList.contains("disable-move"))return;l=l.parentElement}let s=(e.clientX/window.innerWidth-.5)*2,n=(e.clientY/window.innerHeight-.5)*2;t(2.5*s),r(2.5*n-2.5),i(5*s),o(5*n+5)};return a&&window.addEventListener("mousemove",p),()=>{window.removeEventListener("mousemove",p)}},[c,a],{recreateOnResize:!0}),(0,y.useEffect)(()=>{if(!o.current)return;let e=new ResizeObserver(()=>{c()});return e.observe(o.current),()=>{e.disconnect()}},[o,c]),(0,i.jsxs)(E,{className:e,ref:o,style:{opacity:+!t},children:[(0,i.jsx)(O,{priority:!0,ref:l,src:v,alt:"",loading:"eager"}),(0,i.jsx)(H,{priority:!0,ref:n,src:w,alt:"",loading:"eager"})]})}let E=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		top: 50%;
		left: 50%;
		translate: -50% -50%;
		min-width: 100%;
		min-height: 100%;
		aspect-ratio: 1600 / 880;
	`)}),O=(0,p.I4)(x.default,{...(0,p.vi)((0,p.AH)`
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		transform-origin: top center;
		scale: ${1.1};
	`),...(0,p.PK)((0,p.AH)`
		left: -30%;
	`)}),H=(0,p.I4)(x.default,{...(0,p.vi)((0,p.AH)`
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		transform-origin: bottom center;
		scale: ${1.1};
	`),...(0,p.PK)((0,p.AH)`
		left: -30%;
	`)}),j={src:"/_next/static/media/mask.a09c5af6.svg"};function L(){let e,t,r,l,A,g,x,k,b,v,w,E,O,H,L,V,Z,G,N,K,J,Y,X,q,ee;let et=(0,o.c)(38),er=(0,y.useRef)(null),ei=(0,y.useRef)(null),eo=(0,y.useRef)(null),el=(0,y.useRef)(null),es=(0,y.useRef)(null),en=(0,y.useRef)(null),ea=(0,y.useRef)(null),ec=(0,y.useRef)(null),ep=(0,y.useRef)(null),ed=(0,n.l5)();et[0]!==ed?(e=()=>{let e=s.Ay.timeline({scrollTrigger:{trigger:er.current,start:0,end:"bottom bottom",scrub:!0},defaults:{duration:1}}),t=(0,h._y)(),r=(0,h.Ne)((0,h.BS)(200));e.to(es.current,{opacity:0}).fromTo(ei.current,{"--clip-border-opacity":0},{"--clip-border-opacity":1,duration:.1},"-=0.1");let i="mobile"===t?r/2:r,o=350*i/200,l=240*i/200,n=390*o/350,p=.5*i,d=.5*o;if(a.pH.isMobileOS){let t=()=>{s.Ay.set(eo.current,{mask:`url(${j.src}) no-repeat center / ${l}px ${n}px`}),s.Ay.set(el.current,{mask:`
				linear-gradient(
					to bottom,
					red 0,
					red calc(50% - ${d}px),
					transparent calc(50% - ${d}px),
					transparent calc(50% + ${d}px),
					red calc(50% + ${d}px),
					red 100%
					),
					linear-gradient(
						to right,
						red 0,
						red calc(50% - ${p}px),
						transparent calc(50% - ${p}px),
						transparent calc(50% + ${p}px),
						red calc(50% + ${p}px),
						red 100%
						)
						`})};s.Ay.delayedCall(.5,t),e.call(t,[],0),e.call(t,[],.1)}else e.fromTo(eo.current,{mask:`url(${j.src}) no-repeat center / 0px 0px`},{mask:`url(${j.src}) no-repeat center / ${l}px ${n}px`},"mobile"===t?"<":void 0),e.fromTo(el.current,{mask:`
								linear-gradient(
									to bottom,
									red 0,
									red calc(50% - 0px),
									transparent calc(50% - 0px),
									transparent calc(50% + 0px),
									red calc(50% + 0px),
									red 100%
								),
								linear-gradient(
									to right,
									red 0,
									red calc(50% - 0px),
									transparent calc(50% - 0px),
									transparent calc(50% + 0px),
									red calc(50% + 0px),
									red 100%
								)
						`},{mask:`
								linear-gradient(
									to bottom,
									red 0,
									red calc(50% - ${d}px),
									transparent calc(50% - ${d}px),
									transparent calc(50% + ${d}px),
									red calc(50% + ${d}px),
									red 100%
								),
								linear-gradient(
									to right,
									red 0,
									red calc(50% - ${p}px),
									transparent calc(50% - ${p}px),
									transparent calc(50% + ${p}px),
									red calc(50% + ${p}px),
									red 100%
								)
						`},"<");"mobile"!==t&&e.to([en.current,ec.current],{yPercent:-110,ease:"power1.in"},"<+=0.5");let y=(0,u.x)(80,80,80,96)??80;e.call(()=>{ei.current?.classList.remove("optimized"),ei.current?.classList.remove("disable-move")}),e.call(()=>{ei.current?.classList.add("optimized"),ei.current?.classList.add("disable-move")}),e.to(ei.current,{z:y,ease:"power1.inOut",duration:1.7}).call(()=>{a.pH.isChrome&&!a.pH.isAndroid&&ei.current?.classList.remove("optimized")}).to("p",{yPercent:200,scale:1.2,duration:.2,ease:"linear"},"-=0.7").to("h2",{yPercent:-200,scale:1.2,duration:.2,ease:"linear"},"-=0.7").to(ei.current,{duration:1e-5,pointerEvents:"none",opacity:0}),s.Ay.delayedCall(0,()=>{let t=e.progress();s.Ay.fromTo(e,{progress:0},{progress:t})}),(0,c.A)({trigger:ep.current,endTrigger:er.current,start:0,end:"bottom bottom+=100",smoothType:"out",pinType:ed})},t=[ed],et[0]=ed,et[1]=e,et[2]=t):(e=et[1],t=et[2]),et[3]===Symbol.for("react.memo_cache_sentinel")?(r={recreateOnResize:!0,scope:er},et[3]=r):r=et[3],(0,d.s)(e,t,r);let eu=(0,u.Q)(80,80,80,120);et[4]===Symbol.for("react.memo_cache_sentinel")?(l={...(0,p.vi)((0,p.AH)`
						left: 20vw;
						top: 140vh;
					`),...(0,p.PK)((0,p.AH)`
						left: -50px;
						top: 160vh;
					`)},et[4]=l):l=et[4],et[5]!==eu?(A=(0,i.jsx)(m.A,{size:eu,css:l}),et[5]=eu,et[6]=A):A=et[6],et[7]===Symbol.for("react.memo_cache_sentinel")?(g=(0,i.jsx)(_,{"data-header-stick":!0}),et[7]=g):g=et[7],et[8]===Symbol.for("react.memo_cache_sentinel")?(x=(0,i.jsx)(m.A,{size:180,css:{...(0,p.vi)((0,p.AH)`
								left: 50vw;
								top: 40vh;
							`),...(0,p.PK)((0,p.AH)`
								scale: 0.5;
							`)}}),et[8]=x):x=et[8];let eh=(0,u.Q)(40,40,40,20);et[9]===Symbol.for("react.memo_cache_sentinel")?(k={...(0,p.vi)((0,p.AH)`
								left: 50vw;
								top: 30vh;
							`),...(0,p.PK)((0,p.AH)``)},et[9]=k):k=et[9],et[10]!==eh?(b=(0,i.jsxs)(I,{ref:ep,children:[x,(0,i.jsx)(m.A,{size:eh,css:k})]}),et[10]=eh,et[11]=b):b=et[11],et[12]===Symbol.for("react.memo_cache_sentinel")?(v=(0,i.jsx)(C,{ref:es}),et[12]=v):v=et[12],et[13]===Symbol.for("react.memo_cache_sentinel")?(w=(0,i.jsx)(D,{ref:en,children:(0,i.jsx)(C,{needsAdjustment:!0})}),et[13]=w):w=et[13],et[14]===Symbol.for("react.memo_cache_sentinel")?(E=(0,i.jsxs)(D,{ref:ea,className:"center",children:[(0,i.jsx)(B,{needsAdjustment:!0,ref:eo}),(0,i.jsx)(F,{needsAdjustment:!0,ref:el})]}),et[14]=E):E=et[14],et[15]===Symbol.for("react.memo_cache_sentinel")?(O=(0,i.jsx)(D,{ref:ec,children:(0,i.jsx)(C,{needsAdjustment:!0})}),et[15]=O):O=et[15];let ey=(0,u.Q)(230,230,230,115);et[16]===Symbol.for("react.memo_cache_sentinel")?(H={...(0,p.vi)((0,p.AH)`
									left: 78px;
									top: 135px;
								`),...(0,p.ZQ)((0,p.AH)`
									top: 80px;
								`),...(0,p.PK)((0,p.AH)`
									left: -80px;
								`)},et[16]=H):H=et[16],et[17]!==ey?(L=(0,i.jsx)(m.A,{size:ey,css:H}),et[17]=ey,et[18]=L):L=et[18];let eA=(0,u.Q)(140,140,140,70);et[19]===Symbol.for("react.memo_cache_sentinel")?(V={...(0,p.vi)((0,p.AH)`
									right: 50vw;
									top: -70px;
								`),...(0,p.ZQ)((0,p.AH)`
									right: 200px;
								`),...(0,p.PK)((0,p.AH)`
									display: none;
								`)},et[19]=V):V=et[19],et[20]!==eA?(Z=(0,i.jsx)(m.A,{size:eA,css:V}),et[20]=eA,et[21]=Z):Z=et[21];let eg=(0,u.Q)(140,140,140,70);return et[22]===Symbol.for("react.memo_cache_sentinel")?(G={...(0,p.vi)((0,p.AH)`
									right: 127px;
									top: 224px;
								`),...(0,p.ZQ)((0,p.AH)`
									top: 400px;
								`),...(0,p.PK)((0,p.AH)`
									right: -30px;
									top: 50vh;
								`)},et[22]=G):G=et[22],et[23]!==eg?(N=(0,i.jsx)(m.A,{size:eg,css:G}),et[23]=eg,et[24]=N):N=et[24],et[25]===Symbol.for("react.memo_cache_sentinel")?(K=(0,i.jsx)(P,{}),J=(0,i.jsx)($,{}),et[25]=K,et[26]=J):(K=et[25],J=et[26]),et[27]===Symbol.for("react.memo_cache_sentinel")?(Y=(0,i.jsxs)(U,{children:[(0,i.jsx)(W,{children:"Organized."}),(0,i.jsx)(z,{children:"So you don't have to be."}),(0,i.jsx)(Q,{children:"Micro is an all-in-one tool for email, CRM, project management and more that automatically organizes itself."}),(0,i.jsx)(T,{href:f.A.joinTheWaitlist,variant:"light",analyticsLocation:"Homepage Hero",children:"Join the Waitlist"})]}),et[27]=Y):Y=et[27],et[28]!==L||et[29]!==Z||et[30]!==N?(X=(0,i.jsx)(M,{children:(0,i.jsxs)(S,{ref:ei,children:[v,w,E,O,L,Z,N,K,J,Y]})}),et[28]=L,et[29]=Z,et[30]=N,et[31]=X):X=et[31],et[32]!==b||et[33]!==X?(q=(0,i.jsxs)(R,{ref:er,children:[b,X]}),et[32]=b,et[33]=X,et[34]=q):q=et[34],et[35]!==q||et[36]!==A?(ee=(0,i.jsxs)(i.Fragment,{children:[A,g,q]}),et[35]=q,et[36]=A,et[37]=ee):ee=et[37],ee}let _=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		height: 85vh;
	`)}),I=(0,p.I4)("div",{position:"absolute"}),B=(0,p.I4)(C),F=(0,p.I4)(C),R=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		height: 200vh;
		grid-column: scaled-main;
		position: relative;
		isolation: isolate;
		z-index: 1;
	`)}),M=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: sticky;
		top: 83px;
		perspective: 100px;
	`)}),S=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		color: ${A.A.white1};
		height: calc(100svh - 83px - max(env(safe-area-inset-bottom, 0), 32px));
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		padding: 8px;
		gap: 8px;
		border-radius: 27px;
		overflow: clip;
		position: relative;
		background:
			linear-gradient(
				to right,
				${A.A.black1},
				${A.A.black1} 34%,
				transparent 34%,
				transparent 66%,
				${A.A.black1} 66%,
				${A.A.black1}
			),
			linear-gradient(
				to bottom,
				${A.A.black1},
				${A.A.black1} 30px,
				transparent 30px,
				transparent calc(100% - 30px),
				${A.A.black1} calc(100% - 30px),
				${A.A.black1}
			);
		transition: opacity 0.2s;

		&.optimized,
		&.optimized .center {
			will-change: transform;
		}
	`),...(0,p.PK)((0,p.AH)`
		background:
			linear-gradient(
				to right,
				${A.A.black1},
				${A.A.black1} 30px,
				transparent 30px,
				transparent calc(100% - 30px),
				${A.A.black1} calc(100% - 30px),
				${A.A.black1}
			),
			linear-gradient(
				to bottom,
				${A.A.black1},
				${A.A.black1} 30px,
				transparent 30px,
				transparent calc(100% - 30px),
				${A.A.black1} calc(100% - 30px),
				${A.A.black1}
			);
	`)}),D=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		border-radius: 19px;
		overflow: clip;
		position: relative;
		border: 0.5px solid rgb(255 255 255 / 80%);
		border: 0.5px solid color(display-p3 1 1 1 / 80%);
	`),...(0,p.PK)((0,p.AH)`
		display: none;

		&.center {
			display: block;
			grid-column: 1 / span 3;
		}
	`)}),P=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 281px;
		background: linear-gradient(
			180deg,
			rgb(0 0 0 / 65%) 3.2%,
			rgb(0 0 0 / 65%) 70.11%
		);
		background: linear-gradient(
			180deg,
			color(display-p3 0 0 0 / 0%) 3.2%,
			color(display-p3 0 0 0 / 65%) 70.11%
		);
	`),...(0,p.ZQ)((0,p.AH)`
		height: 611px;
	`),...(0,p.PK)((0,p.AH)`
		height: 280px;
	`)}),$=(0,p.I4)(P,{display:"none",...(0,p.PK)((0,p.AH)`
		display: block;
		rotate: 180deg;
		top: -130px;
		bottom: unset;
	`)}),U=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		inset: 32px;
		display: grid;
		grid-template-areas:
			"description title"
			"button title"
			"button subtitle";
		grid-template-rows: 1fr auto auto;
	`),...(0,p.ZQ)((0,p.AH)`
		grid-template-areas: "title" "subtitle" "description" "button";
	`),...(0,p.PK)((0,p.AH)`
		display: flex;
		flex-direction: column;
		align-items: center;
		inset: 40px 28px 22px;
	`)}),W=(0,p.I4)("h1",{...(0,p.vi)((0,p.AH)`
		${g.Ay.oversize1};
		grid-area: title;
		place-self: end;
	`),...(0,p.PK)((0,p.AH)`
		${g.Ay.header5};
		place-self: center;
	`)}),z=(0,p.I4)("h2",{...(0,p.vi)((0,p.AH)`
		${g.Ay.header3};
		margin-top: 19px;
		grid-area: subtitle;
		place-self: end;
	`),...(0,p.PK)((0,p.AH)`
		${g.Ay.header3};
		place-self: center;
		text-align: center;
	`)}),Q=(0,p.I4)("p",{...(0,p.vi)((0,p.AH)`
		${g.Ay.body2};
		max-width: 321px;
		place-self: end start;
		grid-area: description;
	`),...(0,p.ZQ)((0,p.AH)`
		place-self: end;
		text-align: right;
		margin-top: 49px;
	`),...(0,p.PK)((0,p.AH)`
		margin-top: auto;
	`)}),T=(0,p.I4)(l.j,{...(0,p.vi)((0,p.AH)`
		place-self: start;
		grid-area: button;
		margin-top: 40px;
	`),...(0,p.ZQ)((0,p.AH)`
		place-self: end;
		margin-top: 36px;
	`)})},2114:(e,t,r)=>{"use strict";r.d(t,{default:()=>b});var i=r(8946),o=r(954),l=r(3436),s=r(884),n=r(5611),a=r(3336),c=r(7606),p=r(7248),d=r(9302),u=r(4052),h=r(9144),y=r(4522),A=r(9986),g=r(2048),f=r(3568),m=r(6253);let x={src:"/_next/static/media/arrow.f400b257.svg",height:20,width:11,blurWidth:0,blurHeight:0};s.os.registerPlugin(n.u);let k=[{logo:{src:"/_next/static/media/shield.99c33afb.svg",height:37,width:131,blurWidth:0,blurHeight:0},text:"We've been able to close much more capital since onboarding to Micro. It's eliminated 80% of the busywork we'd have to do and has helped us engage with investors we would have missed.",author:"Emmanuel Udotong - Cofounder/CEO - Shield",alt:"Shield"},{logo:{src:"/_next/static/media/superpower.c8915e11.svg",height:31,width:195,blurWidth:0,blurHeight:0},text:"Micro has been game-changing for staying on top of my connections. Love how easy it is to search through and get detailed info on my contacts.",author:"Jacob Peters - Cofounder/CEO - Superpower ",alt:"Superpower"}];function b(){let e,t,r,a,p,A,g,b,W,z,Q,T,V,Z,G,N,K,J,Y,X,q;let ee=(0,o.c)(40),[et,er]=(0,y.useState)(0),[ei,eo]=(0,y.useState)("forward"),el=(0,y.useRef)(null),es=(0,y.useRef)(null),en=(0,y.useRef)(null),ea=(0,y.useRef)(null),ec=(0,y.useRef)(null),ep=(0,y.useRef)(null),ed=(0,y.useRef)(null),eu=(0,u.Q)("top 60%","top 60%","top 50%","top 40%"),eh=(0,u.Q)("top 20%","top 20%","top 20%","top 10%"),ey=(0,u.Q)(25,25,25,12);ee[0]===Symbol.for("react.memo_cache_sentinel")?(e=[ea,ec],ee[0]=e):e=ee[0],(0,m.A)(e),ee[1]===Symbol.for("react.memo_cache_sentinel")?(t=()=>{eo("backward"),er(C),es.current&&es.current.restart()},ee[1]=t):t=ee[1];let eA=t;ee[2]===Symbol.for("react.memo_cache_sentinel")?(r=()=>{eo("forward"),er(w),es.current&&es.current.restart()},ee[2]=r):r=ee[2];let eg=r;ee[3]!==eh||ee[4]!==eu||ee[5]!==ey?(a=()=>{if(!el.current)return;let e=(0,u.x)(!0,!0,!0,!1);es.current=s.os.timeline({repeat:-1,repeatDelay:10,onRepeat:()=>{el.current&&n.u.isInViewport(el.current)&&(eo("forward"),er(v))}}),n.u.create({trigger:el.current,start:"top bottom",end:"bottom top",onEnter:()=>es.current?.play(),onEnterBack:()=>es.current?.play(),onLeave:()=>es.current?.pause(),onLeaveBack:()=>es.current?.pause()}),n.u.isInViewport(el.current)?es.current.play():es.current.pause();let t=s.os.timeline({scrollTrigger:{trigger:en.current,start:eu,end:eh,scrub:!0}});t.fromTo(ep.current,{y:`${(0,h.qM)(-1*ey)}px`},{y:`${(0,h.qM)(ey)}px`,ease:"linear"},0),e&&t.fromTo(ed.current,{y:`${(0,h.qM)(-50)}px`},{y:`${(0,h.qM)(0)}px`,ease:"linear"},0)},p=[eu,eh,ey],ee[3]=eh,ee[4]=eu,ee[5]=ey,ee[6]=a,ee[7]=p):(a=ee[6],p=ee[7]),ee[8]===Symbol.for("react.memo_cache_sentinel")?(A={recreateOnResize:!0},ee[8]=A):A=ee[8],(0,d.s)(a,p,A),ee[9]===Symbol.for("react.memo_cache_sentinel")?(g={ease:"power4.out"},ee[9]=g):g=ee[9];let ef="forward"===ei?100:-100;ee[10]!==ef?(b={yPercent:ef,opacity:0},ee[10]=ef,ee[11]=b):b=ee[11];let em="forward"===ei?-100:100;ee[12]!==em?(W={yPercent:em,opacity:0},ee[12]=em,ee[13]=W):W=ee[13];let ex=k[et]?.logo.src||`card-${et}`,ek=k[et]?.logo.src,eb=k[et]?.alt;ee[14]!==ek||ee[15]!==eb?(z=(0,i.jsx)(F,{src:ek,alt:eb}),ee[14]=ek,ee[15]=eb,ee[16]=z):z=ee[16];let ev=k[et]?.text||"";ee[17]!==ev?(Q=(0,i.jsx)(R,{children:ev}),ee[17]=ev,ee[18]=Q):Q=ee[18];let ew=k[et]?.author||"";return ee[19]!==ew?(T=(0,i.jsx)(M,{children:ew}),ee[19]=ew,ee[20]=T):T=ee[20],ee[21]!==z||ee[22]!==Q||ee[23]!==T?(V=(0,i.jsxs)(S,{children:[z,Q,T]}),ee[21]=z,ee[22]=Q,ee[23]=T,ee[24]=V):V=ee[24],ee[25]!==ex||ee[26]!==V?(Z=(0,i.jsx)(_,{children:V},ex),ee[25]=ex,ee[26]=V,ee[27]=Z):Z=ee[27],ee[28]!==W||ee[29]!==Z||ee[30]!==b?(G=(0,i.jsx)(I,{duration:1.3,alignment:"center",parameters:g,fromParameters:b,toParameters:W,children:Z}),ee[28]=W,ee[29]=Z,ee[30]=b,ee[31]=G):G=ee[31],ee[32]===Symbol.for("react.memo_cache_sentinel")?(N=(0,i.jsx)(P,{direction:"up",onClick:eA,children:(0,i.jsx)(c.default,{src:x,alt:"arrow up"})}),ee[32]=N):N=ee[32],ee[33]===Symbol.for("react.memo_cache_sentinel")?(K=(0,i.jsxs)(D,{children:[N,(0,i.jsx)(P,{direction:"down",onClick:eg,children:(0,i.jsx)(c.default,{src:x,alt:"arrow down"})})]}),ee[33]=K):K=ee[33],ee[34]!==G?(J=(0,i.jsxs)(B,{ref:ed,children:[G,K]}),ee[34]=G,ee[35]=J):J=ee[35],ee[36]===Symbol.for("react.memo_cache_sentinel")?(Y=(0,i.jsxs)(O,{children:[(0,i.jsx)(j,{ref:ep}),(0,i.jsx)(H,{}),(0,i.jsx)(L,{ref:en})]}),ee[36]=Y):Y=ee[36],ee[37]===Symbol.for("react.memo_cache_sentinel")?(X=(0,i.jsxs)($,{children:[(0,i.jsx)(U,{ref:ea,children:"Apply Now to be part of the closed beta"}),(0,i.jsx)(l.j,{ref:ec,href:f.A.joinTheWaitlist,variant:"grayOversize",analyticsLocation:"Testimonials",children:"Join the Waitlist"})]}),ee[37]=X):X=ee[37],ee[38]!==J?(q=(0,i.jsxs)(E,{ref:el,"data-header-hide":!0,children:[J,Y,X]}),ee[38]=J,ee[39]=q):q=ee[39],q}function v(e){return(e+1)%k.length}function w(e){return(e+1)%k.length}function C(e){return(e-1+k.length)%k.length}let E=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		overflow: hidden;
		position: relative;
		width: 100vw;
		height: 863px;
		display: grid;
		grid-template-rows: 460px auto;
		justify-items: center;
		padding-top: 45px;
		margin-top: -45px;
	`),...(0,p.PK)((0,p.AH)`
		height: auto;
	`)}),O=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		will-change: transform;
		position: relative;
		width: 1302px;
		height: 460px;
		pointer-events: none;
		border-radius: 200vw;
	`),...(0,p.ZQ)((0,p.AH)`
		width: 960px;
		height: 460px;
	`),...(0,p.PK)((0,p.AH)`
		width: 335px;
		height: 576px;
	`)}),H=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		inset: -50vmax;
		border-radius: 200vw;
		${A.A.lightDotBackground};
		mask:
		/* stylelint-disable-next-line declaration-property-value-no-unknown */
			linear-gradient(#fff 0 0) padding-box,
			linear-gradient(#fff 0 0);
		mask-composite: exclude;
		border: 50vmax solid transparent;
	`)}),j=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		inset: -49.2vmax;
		border-radius: 200vw;
		background: ${A.A.white2};
		mask:
		/* stylelint-disable-next-line declaration-property-value-no-unknown */
			linear-gradient(#fff 0 0) padding-box,
			linear-gradient(#fff 0 0);
		mask-composite: exclude;
		border: 50vmax solid transparent;
		transform: translateY(17px);
		opacity: 1;
	`),...(0,p.PK)((0,p.AH)`
		inset: -49vmax;
	`)}),L=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		width: 1302px;
		height: 460px;
		border-radius: 200vw;
		border: 1px solid ${A.A.white5};
		z-index: 3;
	`),...(0,p.ZQ)((0,p.AH)`
		width: 960px;
		height: 460px;
	`),...(0,p.PK)((0,p.AH)`
		width: 335px;
		height: 576px;
	`)}),_=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		width: 100%;
		height: 100%;
		color: ${A.A.white1};
		display: flex;
		justify-content: center;
		align-items: center;
	`),...(0,p.PK)((0,p.AH)`
		width: 100%;
		height: 100%;
		color: ${A.A.white1};
		display: flex;
		justify-content: center;
	`)}),I=(0,p.I4)(a.A,{...(0,p.vi)((0,p.AH)`
		position: relative;
		width: 1302px;
		margin-top: 80px;
		height: 460px;
		color: ${A.A.white1};
		display: grid;
		place-content: center;
		place-items: center;
	`),...(0,p.ZQ)((0,p.AH)`
		margin-top: 100px;
		width: 960px;
		height: 460px;
	`),...(0,p.PK)((0,p.AH)`
		margin-top: 80px;
		width: 335px;
		height: 576px;
	`)}),B=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		width: 1302px;
		height: ${502}px;
		left: 50%;
		color: ${A.A.white1};
		transform: translateX(-50%);
		display: grid;
		place-content: center;
		place-items: center;
	`),...(0,p.ZQ)((0,p.AH)`
		width: 960px;
		height: 460px;
	`),...(0,p.PK)((0,p.AH)`
		width: 335px;
		height: 576px;
	`)}),F=(0,p.I4)("img",{...(0,p.vi)((0,p.AH)`
		max-height: 30px;
		height: 30px;
		max-width: 200px;
		width: auto;
		text-align: center;
	`)}),R=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		${g.Ay.header3};
	`)}),M=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		${g.Ay.body1};
	`),...(0,p.PK)((0,p.AH)`
		${g.Ay.body4};
	`)}),S=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		width: 761px;
		display: flex;
		flex-direction: column;
		gap: 24px;
		text-align: center;
		align-items: center;
	`),...(0,p.PK)((0,p.AH)`
		width: 295px;
		gap: 42px;
	`)}),D=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: absolute;
		right: 135px;
		bottom: 77px;
		display: flex;
		flex-direction: row;
		gap: 12px;
		z-index: 200;
		pointer-events: auto;
	`),...(0,p.ZQ)((0,p.AH)`
		right: 150px;
		bottom: 20px;
	`),...(0,p.PK)((0,p.AH)`
		right: 50%;
		bottom: -10px;
		transform: translateX(50%);
	`)}),P=(0,p.I4)("button",({direction:e})=>({...(0,p.vi)((0,p.AH)`
		border: none;
		display: flex;
		align-items: center;
		justify-content: center;
		cursor: pointer;
		transform: ${"up"===e?"rotate(0deg)":"rotate(180deg)"};
		transition:
			background-color 0.2s,
			transform 0.2s;
		box-shadow: 0 4px 8px rgb(0 0 0 / 10%);

		img {
			width: 9px;
			height: 20px;
			transform: translateY(0);
			transition: transform 0.3s ease-in-out;
		}

		&:hover img {
			transform: translateY(${"-2px"});
		}

		&:focus {
			outline: none;
		}
	`)})),$=(0,p.I4)("div",{...(0,p.vi)((0,p.AH)`
		position: relative;
		width: 1302px;
		color: ${A.A.white1};
		display: flex;
		flex-direction: column;
		justify-content: center;
		gap: 40px;
		margin: 116px 0;
		padding-top: 40px;
		border-top: 1px solid ${A.A.white5};
		align-items: center;
	`),...(0,p.ZQ)((0,p.AH)`
		width: 741px;
		margin: 132px 0;
	`),...(0,p.PK)((0,p.AH)`
		width: 335px;
		margin: 204px 0 0;
	`)}),U=(0,p.I4)("h3",{...(0,p.vi)((0,p.AH)`
		${g.Ay.header2};
		color: ${A.A.black2};
	`),...(0,p.ZQ)((0,p.AH)`
		${g.Ay.header3};
	`),...(0,p.PK)((0,p.AH)`
		${g.Ay.header3};
		text-align: center;
	`)})},2508:(e,t,r)=>{"use strict";r.d(t,{default:()=>v});var i=r(8946),o=r(954),l=r(862),s=r(1839),n=r(5895),a=r(5611),c=r(4522),p=r(2478);let d=(e,t)=>{let{shouldHydrateUtilities:r}=(0,c.use)(p.cH);return r?e:t};var u=r(7537);let h=()=>d(u.pH)??{};var y=r(7248),A=r(9302),g=r(9986),f=r(2048),m=r(2926),x=r(813);function k(e){let t,r,l;let n=(0,o.c)(6),{letterElements:p,forceStrength:d,wrapperRef:h}=e,y=(0,c.useRef)(null);return n[0]!==d||n[1]!==p||n[2]!==h?(t=()=>{let e,t;if(!u.Bd||!y.current||!p||!h.current)return;let r=y.current,i=r.clientWidth,o=r.clientHeight,l=r.getBoundingClientRect(),n=x.Engine.create(),c=x.Bodies.rectangle(i/2,o+250,i,502,{isStatic:!0,render:{fillStyle:"green"}}),A=x.Bodies.rectangle(-250,o/2,500,o,{isStatic:!0,render:{fillStyle:"green"}}),g=x.Bodies.rectangle(i+250,o/2,500,o,{isStatic:!0,render:{fillStyle:"green"}});x.World.add(n.world,[c,A,g]);let f=[];for(let e of p.current){if(!e)continue;let t=e.getBoundingClientRect(),r=t.left-l.left,o=t.top-l.top,s=r+t.width/2,a=o+t.height/2,c=x.Bodies.rectangle((0,m.hw)(100,i-100),0,t.width,t.height,{isStatic:!1,restitution:.5,chamfer:{radius:Math.min(5,t.width/2)},collisionFilter:{group:-1}}),p=e.cloneNode(!0);p.style.position="fixed",p.style.top="0",p.style.left="0",p.style.visibility="hidden";let d=window.getComputedStyle(e);p.style.font=d.font,p.style.color=d.color,y.current?.appendChild(p),f.push({body:c,element:e,fixedClone:p,originalPosition:{x:s,y:a},isTweening:!1}),x.World.add(n.world,c)}e=window.scrollY,t=1;let k=[];x.Events.on(n,"afterUpdate",()=>{let r=window.scrollY,l=r-e;e=r;let a=!1,c=!1;if(0===d.current)for(let e of(t-=.01,t=Math.max(0,t),0===n.gravity.y&&(a=!0),n.gravity.y=1,f))e.body.collisionFilter.group=1;else for(let e of(t+=.05,t=Math.min(1,t),1===n.gravity.y&&(c=!0),n.gravity.y=0,f))e.body.collisionFilter.group=-1;if(a){for(let e of k)e.kill();k.length=0}for(let e of f)if(e.element&&e.body){if(x.Body.setPosition(e.body,{x:e.body.position.x,y:e.body.position.y-l*Math.min(1,t**2)}),e.originalPosition.y=e.originalPosition.y-l,a&&(x.Body.setPosition(e.body,{x:e.body.position.x,y:e.body.position.y+1}),x.Body.setVelocity(e.body,{x:e.body.velocity.x,y:e.body.velocity.y+1})),c){let t=e.originalPosition.x,r=e.originalPosition.y,i={...e.body.position};e.isTweening=!0,k.push(s.Ay.to(i,{duration:1,ease:"power3.inOut",x:e.originalPosition.x,y:e.originalPosition.y,modifiers:{x:r=>r+(e.originalPosition.x-t),y:t=>t+(e.originalPosition.y-r)},onUpdate:()=>{x.Body.setPosition(e.body,i)},onComplete:()=>{e.isTweening=!1}}))}let r=e.body.position,n=e.originalPosition,p=x.Vector.sub(n,r),u=Math.min(100,x.Vector.magnitude(p));e.body.friction=d.current>0?0:.1,e.body.frictionAir=d.current>0?.15:.01;let h=Math.min(.001,d.current*u**1.5*1e-5),y=x.Vector.mult(x.Vector.normalise(p),h);e.isTweening||x.Body.applyForce(e.body,r,y);let A=2*Math.PI,g=(e.body.angle%A+A)%A,f=g;if(g>Math.PI){let t=.2*(f=A-g)*d.current;x.Body.setAngularVelocity(e.body,e.body.angularVelocity+t)}else{let t=-(.2*f)*d.current;x.Body.setAngularVelocity(e.body,e.body.angularVelocity+t)}!e.isTweening&&u<10&&d.current>0&&(x.Body.setVelocity(e.body,x.Vector.mult(e.body.velocity,.5)),x.Body.setAngularVelocity(e.body,.5*e.body.angularVelocity)),(e.body.position.y>o+500||e.body.position.x<-500||e.body.position.x>i+500)&&x.Body.setPosition(e.body,{x:i/2,y:-100}),"scroll"==(d.current>0?"scroll":"fixed")?(s.Ay.set(e.fixedClone,{visibility:"hidden"}),s.Ay.set(e.element,{visibility:"visible",x:e.body.position.x-e.originalPosition.x,y:e.body.position.y-e.originalPosition.y,rotate:e.body.angle*(180/Math.PI)})):(s.Ay.set(e.element,{visibility:"hidden"}),s.Ay.set(e.fixedClone,{visibility:"visible",x:e.body.position.x,y:e.body.position.y,yPercent:-50,xPercent:-50,rotate:e.body.angle*(180/Math.PI)}))}});let b=x.Runner.create();x.Runner.run(b,n),b.enabled=!1;let v=a.u.create({trigger:h.current,start:"top bottom+=200",end:"bottom top-=200",onEnter:()=>{b.enabled=!0},onLeave:()=>{b.enabled=!1},onEnterBack:()=>{b.enabled=!0},onLeaveBack:()=>{b.enabled=!1}});return()=>{v.kill(),x.Runner.stop(b),x.World.clear(n.world,!1),x.Engine.clear(n)}},r=[p,d,h],n[0]=d,n[1]=p,n[2]=h,n[3]=t,n[4]=r):(t=n[3],r=n[4]),(0,c.useEffect)(t,r),n[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,i.jsx)(b,{ref:y}),n[5]=l):l=n[5],l}let b=(0,y.I4)("div",{...(0,y.vi)((0,y.AH)`
		width: 100vw;
		height: 100lvh;
		top: 0;
		left: 0;
		pointer-events: none;
		position: fixed;
		visibility: hidden;
	`)});function v(){let e,t,r,p,d,u,g,f,m,x,b,v,H,j,L;let _=(0,o.c)(19),I=(0,c.useRef)(null),B=(0,c.useRef)(null),F=(0,c.useRef)(0),{isSafari:R}=h();_[0]!==R?(e=()=>{if(void 0===R)return;new n.A(B.current,{type:"chars, words",charsClass:"letter",wordsClass:"word"});let e=s.Ay.utils.toArray("strong .letter"),t=s.Ay.utils.toArray(R?".letter":"& > .word .letter")??[];return s.Ay.from(I.current,{opacity:0,scrollTrigger:{trigger:I.current,start:"top bottom",end:"+=1",scrub:.3}}),a.u.create({trigger:B.current,start:"bottom 75%",end:"center center",scrub:!0,onLeave:()=>{F.current=1},onEnterBack:()=>{F.current=0}}),s.Ay.from(t,{opacity:0,stagger:.005,scrollTrigger:{trigger:B.current,start:"bottom 75%",end:"center center",toggleActions:"play none none reverse"}}),{current:e,key:Math.random()}},t=[R],_[0]=R,_[1]=e,_[2]=t):(e=_[1],t=_[2]),_[3]===Symbol.for("react.memo_cache_sentinel")?(r={scope:B,recreateOnResize:!0},_[3]=r):r=_[3];let{result:M}=(0,A.s)(e,t,r);return _[4]===Symbol.for("react.memo_cache_sentinel")?(p=(0,i.jsx)(l.A,{size:240,css:{...(0,y.vi)((0,y.AH)`
							top: -47px;
							right: calc(100% + 197px);
						`),...(0,y.ZQ)((0,y.AH)`
							top: -200px;
							right: unset;
							left: -100px;
						`),...(0,y.PK)((0,y.AH)`
							display: none;
						`)}}),_[4]=p):p=_[4],_[5]===Symbol.for("react.memo_cache_sentinel")?(d=(0,i.jsx)(l.A,{size:180,css:{...(0,y.vi)((0,y.AH)`
							top: -81px;
							left: calc(100% + 185px);
						`),...(0,y.ZQ)((0,y.AH)`
							left: unset;
							right: -100px;
							top: 150px;
						`),...(0,y.PK)((0,y.AH)`
							top: 500px;
							scale: 0.6;
							left: unset;
							right: -80px;
						`)}}),u=(0,i.jsx)(C,{children:"Working hard just got easy"}),g=(0,i.jsx)(E,{children:"The era of Brute Force Productivity™ is over and a new one has begun."}),_[5]=d,_[6]=u,_[7]=g):(d=_[5],u=_[6],g=_[7]),_[8]===Symbol.for("react.memo_cache_sentinel")?(f=(0,i.jsx)("strong",{children:"messages"}),_[8]=f):f=_[8],_[9]===Symbol.for("react.memo_cache_sentinel")?(m=(0,i.jsx)("strong",{children:"project"}),_[9]=m):m=_[9],_[10]===Symbol.for("react.memo_cache_sentinel")?(x=(0,i.jsx)("br",{}),_[10]=x):x=_[10],_[11]===Symbol.for("react.memo_cache_sentinel")?(b=(0,i.jsx)("strong",{children:"CRM"}),_[11]=b):b=_[11],_[12]===Symbol.for("react.memo_cache_sentinel")?(v=(0,i.jsx)("strong",{children:"emails"}),_[12]=v):v=_[12],_[13]===Symbol.for("react.memo_cache_sentinel")?(H=(0,i.jsxs)(O,{ref:B,children:["Where everything is centralized - one place to catch up on all your"," ",f,", check in on a ",m," or prep for a meeting with a customer or investor.",x,"Where your work is done for you - ",b," records are updated, ",v," are triaged and"," ",(0,i.jsx)("strong",{children:"documents"})," are drafted automatically."]}),_[13]=H):H=_[13],_[14]!==R||_[15]!==M?(j=!1===R&&(0,i.jsx)(k,{letterElements:M,forceStrength:F,wrapperRef:I},M?.key),_[14]=R,_[15]=M,_[16]=j):j=_[16],_[17]!==j?(L=(0,i.jsx)(i.Fragment,{children:(0,i.jsxs)(w,{ref:I,children:[p,d,u,g,H,j]})}),_[17]=j,_[18]=L):L=_[18],L}s.Ay.registerPlugin(n.A);let w=(0,y.I4)("div",{...(0,y.vi)((0,y.AH)`
		grid-column: column-3-end / column-10-start;
		margin-top: -25vh;
		isolation: isolate;
		padding-bottom: 285px;
		position: relative;
	`),...(0,y.ZQ)((0,y.AH)`
		grid-column: fullbleed;
		padding-left: 125px;
		padding-right: 125px;
	`),...(0,y.PK)((0,y.AH)`
		grid-column: main;
	`)}),C=(0,y.I4)("h1",{...(0,y.vi)((0,y.AH)`
		${f.Ay.header1};
		margin-bottom: 46px;
	`),...(0,y.PK)((0,y.AH)`
		${f.Ay.header5};
		margin-bottom: 36px;
	`)}),E=(0,y.I4)("h2",{...(0,y.vi)((0,y.AH)`
		${f.Ay.header2};
		max-width: 653px;
		margin-bottom: 66px;
	`),...(0,y.PK)((0,y.AH)`
		${f.Ay.header3};
		margin-bottom: 48px;
	`)}),O=(0,y.I4)("div",{...(0,y.vi)((0,y.AH)`
		${f.Ay.body1};
		max-width: 503px;

		strong {
			color: ${g.A.green3};
		}

		.letter {
			${f.Ay.body1};
			will-change: transform;
		}
	`)})},2896:(e,t,r)=>{"use strict";r.d(t,{Y:()=>i});let i={back:{in:"cubic-bezier(0.6, -0.28, 0.735, 0.045)",inOut:"cubic-bezier(0.68, -0.55, 0.265, 1.55)",out:"cubic-bezier(0.175, 0.885, 0.32, 1.275)"},circ:{in:"cubic-bezier(0.6, 0.04, 0.98, 0.335)",inOut:"cubic-bezier(0.785, 0.135, 0.15, 0.86)",out:"cubic-bezier(0.075, 0.82, 0.165, 1)"},quad:{in:"cubic-bezier(0.55, 0.085, 0.68, 0.53)",inOut:"cubic-bezier(0.455, 0.03, 0.515, 0.955)",out:"cubic-bezier(0.25, 0.46, 0.45, 0.94)"},cubic:{in:"cubic-bezier(0.55, 0.055, 0.675, 0.19)",inOut:"cubic-bezier(0.645, 0.045, 0.355, 1)",out:"cubic-bezier(0.215, 0.610, 0.355, 1)"},quart:{in:"cubic-bezier(0.895, 0.03, 0.685, 0.22)",inOut:"cubic-bezier(0.77, 0, 0.175, 1)",out:"cubic-bezier(0.165, 0.84, 0.44, 1)"},quint:{in:"cubic-bezier(0.755, 0.05, 0.855, 0.06)",inOut:"cubic-bezier(0.86, 0, 0.07, 1)",out:"cubic-bezier(0.23, 1, 0.320, 1)"},expo:{in:"cubic-bezier(0.95, 0.05, 0.795, 0.035)",inOut:"cubic-bezier(1, 0, 0, 1)",out:"cubic-bezier(0.19, 1, 0.22, 1)"},sine:{in:"cubic-bezier(0.47, 0, 0.745, 0.715)",inOut:"cubic-bezier(0.445, 0.05, 0.55, 0.95)",out:"cubic-bezier(0.39, 0.575, 0.565, 1)"}}},3008:(e,t,r)=>{"use strict";r.d(t,{default:()=>y});var i=r(8946),o=r(862),l=r(1839),s=r(5611),n=r(7248),a=r(9302),c=r(4052),p=r(9144),d=r(4522),u=r(9986),h=r(2048);function y({children:e}){let t=(0,d.useRef)(null),r=(0,d.useRef)(null),h=(0,d.useRef)(null),y=(0,d.useRef)(null),w=(0,d.useRef)(null),C=(0,d.useRef)(null),E=(0,d.useRef)(null);return(0,a.s)(()=>{let e=e=>`calc(${(0,p.Ne)((0,p.BS)(200))}px * ${e})`,i=e=>`calc(${(0,p.Ne)((0,p.BS)(350))}px * ${e})`;l.Ay.set(t.current,{"--section-height":`${t.current?.clientHeight}px`}),l.Ay.timeline({scrollTrigger:{trigger:t.current,start:"top top",end:()=>`+=${(0,p.bJ)(100)}px`,scrub:!0}}).fromTo(C.current,{scale:1},{scale:8,ease:"power3.in"}).fromTo(r.current,{maskSize:`${e(1)} ${i(1)}`,maskPosition:`center calc(50vh - calc(${i(1)} * 0.5))`},{maskSize:`${e(8)} ${i(8)}`,maskPosition:`center calc(50vh - calc(${i(8)} * 0.5))`,ease:"power3.in"},"<").to([y.current,w.current],{scale:8,ease:"power3.in"},0).to(r.current,{maskImage:"unset",duration:1e-5}),l.Ay.fromTo(C.current,{y:`${(0,p.Ne)((0,p.BS)(21))}px`,yPercent:-50,xPercent:-50},{ease:"linear",y:"0px",yPercent:-50,xPercent:-50,scrollTrigger:{trigger:C.current,start:"center bottom",end:"center center",scrub:!0}}),navigator.userAgent.toLowerCase().includes("firefox")&&s.u.create({trigger:E.current,start:`top top-=${(0,p.bJ)(80)}px`,onEnter:()=>{l.Ay.set(E.current,{marginTop:"80vh",position:"static"}),l.Ay.set([y.current,w.current],{display:"none"})},onLeaveBack:()=>{l.Ay.set(E.current,{clearProps:"all"}),l.Ay.set([y.current,w.current],{clearProps:"display"})}})},[],{recreateOnResize:!0}),(0,i.jsx)(g,{ref:t,children:(0,i.jsxs)(f,{ref:E,children:[(0,i.jsx)(A,{ref:C}),(0,i.jsxs)(m,{ref:r,children:[(0,i.jsx)(k,{children:(0,i.jsx)(o.A,{isLight:!0,size:(0,c.Q)(160,160,160,80),css:{...(0,n.vi)((0,n.AH)`
									left: 43vw;
									top: 40vh;
									box-shadow: 0 0 10px 4px ${u.A.js.white5}40;
								`)}})}),(0,i.jsx)(x,{ref:h,children:e})]}),(0,i.jsxs)(b,{ref:y,children:["Built different",(0,i.jsx)("br",{}),"so you can build different."]}),(0,i.jsxs)(v,{ref:w,children:[(0,i.jsx)("h2",{children:"Startups, investors, anyone."}),(0,i.jsx)("p",{children:"Micro was built for you."})]})]})})}let A=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
			position: absolute;
			top: 50vh;
			left: 50%;
			width: calc(var(--mask-width) + 20px);
			height: calc(var(--mask-height) + 35px);
			border-radius: 99vw;
			border: 1px solid ${u.A.black6};
			background: ${u.A.black2};
			z-index: 0;
			--mask-width: calc(200px);
			--mask-height: calc(350px);
		`,{scaleFully:!0})}),g=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
		display: grid;
		grid-template-columns: subgrid;
		grid-column: fullbleed;
		height: calc(var(--section-height) + 80vh);
		position: relative;
		overflow-x: clip;
	`)}),f=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
		display: grid;
		grid-template-columns: subgrid;
		grid-column: fullbleed;
		position: sticky;
		top: 0;
		height: var(--section-height);
		overflow: clip;
	`)}),m=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
			display: grid;
			grid-template-columns: subgrid;
			grid-column: fullbleed;

			/* Apply the SVG mask */
			mask-image: url(${"/_next/static/media/mask.57d10cde.svg"});
			mask-repeat: no-repeat;
		`,{scaleFully:!0})}),x=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
		display: grid;
		grid-template-columns: subgrid;
		grid-column: fullbleed;
		margin-top: -230px;
		${u.A.lightDotBackground};
	`)}),k=(0,n.I4)("div",{position:"absolute",zIndex:1}),b=(0,n.I4)("p",{...(0,n.vi)((0,n.AH)`
			${h.Ay.header2};
			color: ${u.A.white1};
			text-align: center;
			position: absolute;
			top: calc(50vh + 244px);
			width: 100vw;
			transform-origin: center -400px;
		`,{scaleFully:!0}),...(0,n.ZQ)((0,n.AH)`
		display: none;
	`),...(0,n.PK)((0,n.AH)`
		display: none;
	`)}),v=(0,n.I4)("div",{...(0,n.vi)((0,n.AH)`
		display: none;
		width: 100vw;
	`),...(0,n.ZQ)((0,n.AH)`
		display: flex;
		flex-direction: column;
		text-align: center;
		${u.A.white1};
		position: absolute;
		top: calc(50vh + 294px);
		gap: 32px;
		transform-origin: center -500px;

		h2 {
			${h.Ay.header2};
		}

		p {
			${h.Ay.body1};
		}
	`),...(0,n.PK)((0,n.AH)`
		top: calc(50vh + 223px);
		text-align: center;
		position: absolute;
		display: block;
		transform-origin: center -600px;

		h2 {
			${h.Ay.header2};
		}

		p {
			display: none;
		}
	`)})},3336:(e,t,r)=>{"use strict";r.d(t,{A:()=>d});var i=r(8946),o=r(7486),l=r(1839),s=r(4522),n=r(7248),a=r(954);let c=e=>{if(Array.isArray(e)&&e.every(e=>"string"==typeof e))return e.join("");if("object"==typeof e&&null!==e&&"key"in e&&"string"==typeof e.key)return e.key;if("object"==typeof e&&null!==e)throw Error("Element passed to AutoAnimate must have a key!");return String(e)},p=e=>{if(!e.current)return{width:0,height:0};let t=e.current?.offsetWidth,r=e.current?.offsetHeight,i=e.current.getBoundingClientRect(),o=i.width,l=i.height;return Math.round(o)===t&&Math.round(l)===r?{width:Math.ceil(o),height:Math.ceil(l)}:{width:t+1,height:r}};function d({children:e,duration:t=1,skipFirstAnimation:r=!0,parameters:n,fromParameters:d,toParameters:y,alignment:A="start",className:g=""}){let f=(0,s.useRef)(null),m=(0,s.useRef)(null),x=(0,s.useRef)(null),k=(0,s.useRef)(null),b=(0,s.useRef)(!0),v=c(e),w=(0,s.useRef)({});w.current[v]=e;let C=function(e,t){let r,i,l;let n=(0,a.c)(7),[c,p]=(0,s.useState)(e),d=(0,s.useRef)(new Date().getTime()+t),u=(0,s.useRef)(!1),[h,y]=(0,s.useState)(0);return n[0]!==t||n[1]!==h||n[2]!==e?(r=()=>{if(!u.current){if(new Date().getTime()<d.current){u.current=!0,setTimeout(()=>{u.current=!1,y(h+1)},d.current-new Date().getTime());return}p(e),d.current=new Date().getTime()+t}},i=[t,h,e],n[0]=t,n[1]=h,n[2]=e,n[3]=r,n[4]=i):(r=n[3],i=n[4]),(0,s.useEffect)(r,i),n[5]!==t?(l=()=>{"hidden"===document.visibilityState?d.current=Number.POSITIVE_INFINITY:d.current=new Date().getTime()+t},n[5]=t,n[6]=l):l=n[6],(0,o.A)("visibilitychange",l),c}(v,1e3*t+100),E=e=>null===e?null:w.current[e]??null,O=(0,s.useRef)("A"),[H,j]=(0,s.useState)(r?v:null),[L,_]=(0,s.useState)(null);return(0,s.useEffect)(()=>{let e,i;if(!x.current||!k.current)return;x.current.style.display="block",k.current.style.display="none";let o=p(x);x.current.style.display="none",k.current.style.display="grid";let s=o.height!==p(k).height;l.os.set(k.current,{height:s?void 0:"auto"}),l.os.to(k.current,{width:o.width,height:s?o.height:void 0,ease:n?.ease??"power3.inOut",duration:b.current?0:t,onComplete:()=>{l.os.set(k.current,{height:"auto",width:"auto",delay:1e-4})}});let a=()=>{l.os.set(k.current,p(k))};return b.current&&(b.current=!1,r)||("A"===O.current?(O.current="B",_(C),e=m,i=f):(O.current="A",j(C),e=f,i=m),l.os.set([f.current,m.current],{clearProps:"all"}),l.os.set(i.current,{width:p(i).width}),l.os.set(e.current,{width:o.width}),l.os.to(i.current,{yPercent:-100,ease:"power3.inOut",duration:t,onComplete:()=>{l.os.set(i.current,{width:"auto",delay:1e-4}),"A"===O.current?_(null):j(null)},...n,...y}),l.os.from(e.current,{yPercent:100,ease:"power3.inOut",duration:t,...n,...d,onComplete:()=>{l.os.set(e.current,{width:"auto",delay:1e-4})}})),a},[C]),(0,o.A)("resize",()=>{if(x.current&&k.current){for(let e of l.os.getTweensOf(k.current))e.revert();l.os.set(k.current,{width:"auto",height:"auto"})}}),(0,i.jsxs)(u,{className:g,children:[(0,i.jsx)("div",{ref:x,style:{display:"none"},children:E(C)}),(0,i.jsxs)(h,{ref:k,alignment:A,children:[(0,i.jsx)("div",{ref:f,children:E(H)}),(0,i.jsx)("div",{ref:m,children:E(L)})]})]})}let u=(0,n.I4)("div",(0,n.WC)((0,n.AH)`
		overflow: clip;
	`)),h=(0,n.I4)("div",({alignment:e})=>(0,n.WC)((0,n.AH)`
			display: grid;
			place-items: ${e};
			place-content: ${e};

			> * {
				grid-area: 1 / 1 / 2 / 2;
				min-width: 100%;
				min-height: 100%;
				display: grid;
				place-items: ${e};
				place-content: ${e};

				&:empty {
					pointer-events: none;
				}
			}
		`))},4052:(e,t,r)=>{"use strict";r.d(t,{Q:()=>n,x:()=>a});var i=r(4522),o=r(9240),l=r(2478),s=r(7537);function n(e,t,r,o){let{desktop:s,fullWidth:n,mobile:a,tablet:c}=(0,i.use)(l.cH);if(n)return e;if(s)return t;if(c)return r;if(a)return o;throw Error("useMedia must be used within a ScreenProvider")}function a(e,t,r,i){return!s.Bd||window.innerWidth<=o.ik?i:window.innerWidth>o.ik&&window.innerWidth<=o.g8?r:window.innerWidth>o.g8&&window.innerWidth<=o.gR?t:window.innerWidth>o.gR?e:void 0}},5532:(e,t,r)=>{"use strict";r.d(t,{default:()=>S});var i,o,l=r(8946),s=r(954),n=r(862),a=r(5963),c=r(5611),p=r(1839),d=r(6910),u=r(4522),h=r(2478),y=r(8322),A=r(8665);p.os.registerPlugin(y.s,A.w6);var g=r(7248),f=r(9302);p.os.registerPlugin(d.nu);let m=(0,g.I4)("div",(0,g.vi)((0,g.AH)`
		display: grid;
		position: relative;
	`)),x=(0,g.I4)("div",(0,g.vi)((0,g.AH)`
		display: flex;
		width: 100%;
		overflow: hidden;

		> * {
			flex-shrink: 0;
		}
	`)),k=(0,g.I4)("div",(0,g.vi)((0,g.AH)`
		display: flex;
	`)),b=(0,g.I4)(k,(0,g.vi)((0,g.AH)`
		> *:first-child {
			scale: -1 1;
		}
	`));var v=r(4052),w=r(9986),C=r(2048);function E(){return(E=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let O=e=>u.createElement("svg",E({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 348 348"},e),u.createElement("rect",{width:346.5,height:346.5,x:.75,y:.75,stroke:"#539590",strokeWidth:.5,rx:29.25,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("circle",{cx:174,cy:174,r:172.75,stroke:"#539590",strokeWidth:.5,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("circle",{cx:317.5,cy:30.5,r:29.75,stroke:"#539590",strokeDasharray:"5 5",strokeWidth:.5,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("circle",{cx:30.5,cy:30.5,r:29.75,stroke:"#539590",strokeDasharray:"5 5",strokeWidth:.5,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("circle",{cx:30.5,cy:317.5,r:29.75,stroke:"#539590",strokeDasharray:"5 5",strokeWidth:.5,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("circle",{cx:317.5,cy:317.5,r:29.75,stroke:"#539590",strokeDasharray:"5 5",strokeWidth:.5,style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeDasharray:"5 5",strokeWidth:.5,d:"M345.431 166.696C346.115 168.276 346.581 169.877 346.817 171.497L346.57 171.533C346.69 172.351 346.75 173.173 346.75 174C346.75 174.827 346.69 175.649 346.57 176.467L346.817 176.504C346.581 178.123 346.115 179.724 345.431 181.304L345.202 181.205C344.572 182.658 343.753 184.096 342.753 185.515L342.958 185.659C342.038 186.964 340.966 188.251 339.75 189.519L339.569 189.346C338.468 190.493 337.246 191.626 335.907 192.742L336.067 192.934C334.836 193.96 333.508 194.971 332.087 195.967L331.943 195.762C330.626 196.684 329.227 197.593 327.75 198.488L327.879 198.702C326.492 199.542 325.036 200.37 323.513 201.184L323.395 200.963C321.963 201.729 320.473 202.483 318.924 203.224L319.032 203.45C317.56 204.155 316.037 204.848 314.464 205.53L314.365 205.3C312.866 205.95 311.322 206.588 309.734 207.215L309.826 207.448C308.301 208.051 306.735 208.643 305.13 209.225L305.045 208.99C303.501 209.549 301.92 210.099 300.304 210.638L300.383 210.875C298.818 211.398 297.221 211.91 295.591 212.413L295.517 212.174C293.943 212.66 292.338 213.136 290.705 213.603L290.774 213.843C289.192 214.295 287.584 214.738 285.949 215.171L285.885 214.929C284.291 215.352 282.672 215.766 281.029 216.171L281.089 216.414C279.48 216.81 277.848 217.197 276.194 217.576L276.138 217.332C274.523 217.702 272.887 218.063 271.231 218.415L271.283 218.66C269.668 219.003 268.034 219.338 266.381 219.665L266.332 219.419C264.707 219.74 263.063 220.053 261.401 220.358L261.446 220.604C259.808 220.904 258.153 221.196 256.482 221.479L256.44 221.233C254.812 221.509 253.168 221.777 251.509 222.037L251.547 222.284C249.907 222.541 248.252 222.791 246.582 223.032L246.546 222.784C244.898 223.023 243.235 223.253 241.559 223.475L241.592 223.723C239.951 223.941 238.297 224.151 236.63 224.353L236.6 224.105C234.948 224.305 233.285 224.497 231.609 224.682L231.637 224.931C229.982 225.113 228.317 225.288 226.64 225.455L226.615 225.206C224.963 225.37 223.301 225.527 221.628 225.677L221.651 225.926C219.988 226.074 218.316 226.215 216.634 226.348L216.614 226.099C214.959 226.23 213.295 226.353 211.621 226.469L211.638 226.718C209.976 226.833 208.305 226.941 206.626 227.041L206.611 226.792C204.948 226.891 203.276 226.982 201.596 227.066L201.608 227.316C199.947 227.399 198.278 227.475 196.601 227.543L196.59 227.294C194.921 227.362 193.245 227.422 191.561 227.475L191.569 227.725C189.907 227.777 188.239 227.822 186.564 227.86L186.558 227.61C184.89 227.647 183.215 227.677 181.534 227.7L181.537 227.95C179.871 227.972 178.199 227.987 176.521 227.994L176.52 227.744C175.681 227.748 174.841 227.75 174 227.75C173.159 227.75 172.318 227.748 171.48 227.744L171.479 227.994C169.801 227.987 168.129 227.972 166.463 227.95L166.466 227.7C164.785 227.677 163.11 227.647 161.442 227.61L161.436 227.86C159.761 227.822 158.093 227.777 156.431 227.725L156.439 227.475C154.755 227.422 153.079 227.362 151.41 227.294L151.399 227.543C149.722 227.475 148.053 227.399 146.392 227.316L146.404 227.066C144.724 226.982 143.052 226.891 141.389 226.792L141.374 227.041C139.694 226.941 138.024 226.833 136.362 226.718L136.379 226.469C134.705 226.353 133.041 226.23 131.386 226.099L131.366 226.348C129.684 226.215 128.012 226.074 126.349 225.926L126.372 225.677C124.699 225.527 123.037 225.37 121.385 225.206L121.36 225.455C119.683 225.288 118.018 225.113 116.363 224.931L116.391 224.682C114.715 224.497 113.052 224.305 111.4 224.105L111.37 224.353C109.703 224.151 108.049 223.941 106.408 223.723L106.441 223.475C104.765 223.253 103.102 223.023 101.454 222.784L101.418 223.032C99.7484 222.791 98.093 222.541 96.4525 222.284L96.4913 222.037C94.8321 221.777 93.1883 221.509 91.5602 221.233L91.5184 221.479C89.8467 221.196 88.1916 220.904 86.5537 220.604L86.5987 220.358C84.9371 220.053 83.2932 219.74 81.6677 219.419L81.6192 219.665C79.966 219.338 78.3318 219.003 76.7172 218.66L76.7692 218.415C75.1125 218.063 73.4765 217.702 71.8618 217.332L71.8061 217.576C70.1519 217.197 68.5201 216.81 66.9114 216.414L66.9712 216.171C65.328 215.766 63.7091 215.352 62.1151 214.929L62.051 215.171C60.4163 214.738 58.8078 214.295 57.2262 213.843L57.2949 213.603C55.6616 213.136 54.0571 212.66 52.4825 212.174L52.4088 212.413C50.7793 211.91 49.1815 211.398 47.6167 210.875L47.6958 210.638C46.0801 210.099 44.4994 209.549 42.9551 208.99L42.87 209.225C41.2651 208.643 39.6993 208.051 38.1738 207.448L38.2657 207.215C36.6779 206.588 35.1339 205.95 33.6353 205.3L33.5359 205.53C31.963 204.848 30.4397 204.155 28.9677 203.45L29.0756 203.224C27.5275 202.483 26.0365 201.729 24.6046 200.963L24.4867 201.184C22.9644 200.37 21.5083 199.542 20.1208 198.702L20.2503 198.488C18.7731 197.593 17.3743 196.684 16.0568 195.762L15.9134 195.967C14.4917 194.971 13.1636 193.96 11.9327 192.934L12.0927 192.742C10.7542 191.626 9.53214 190.493 8.43078 189.346L8.2504 189.519C7.03384 188.251 5.96249 186.964 5.04239 185.659L5.24671 185.514C4.24657 184.096 3.42826 182.658 2.79848 181.205L2.56908 181.304C1.88486 179.724 1.41943 178.123 1.18262 176.503L1.42999 176.467C1.31042 175.649 1.25 174.827 1.25 174C1.25 173.173 1.31042 172.351 1.43 171.533L1.18263 171.496C1.41944 169.877 1.88488 168.276 2.5691 166.696L2.7985 166.795C3.42828 165.342 4.2466 163.904 5.24674 162.485L5.04241 162.341C5.96252 161.036 7.03387 159.749 8.25043 158.481L8.43081 158.654C9.53217 157.507 10.7542 156.374 12.0928 155.258L11.9327 155.066C13.1636 154.04 14.4917 153.029 15.9135 152.033L16.0568 152.238C17.3743 151.316 18.7731 150.407 20.2504 149.512L20.1208 149.298C21.5083 148.458 22.9644 147.63 24.4867 146.816L24.6046 147.037C26.0365 146.271 27.5275 145.517 29.0757 144.776L28.9677 144.55C30.4397 143.845 31.963 143.152 33.536 142.47L33.6354 142.7C35.134 142.05 36.6779 141.412 38.2657 140.785L38.1739 140.552C39.6994 139.949 41.2652 139.357 42.87 138.775L42.9552 139.01C44.4995 138.451 46.0801 137.901 47.6959 137.362L47.6167 137.125C49.1816 136.602 50.7793 136.09 52.4088 135.587L52.4825 135.826C54.0572 135.34 55.6616 134.864 57.2949 134.397L57.2263 134.157C58.8078 133.705 60.4163 133.262 62.051 132.829L62.1151 133.071C63.7091 132.648 65.3281 132.234 66.9712 131.829L66.9114 131.586C68.5201 131.19 70.1519 130.803 71.8061 130.424L71.8619 130.668C73.4765 130.298 75.1126 129.937 76.7693 129.585L76.7173 129.34C78.3319 128.997 79.9661 128.662 81.6193 128.335L81.6677 128.581C83.2932 128.26 84.9371 127.947 86.5987 127.642L86.5537 127.396C88.1916 127.096 89.8467 126.804 91.5185 126.521L91.5603 126.767C93.1883 126.491 94.8321 126.223 96.4913 125.963L96.4526 125.716C98.093 125.459 99.7485 125.209 101.418 124.968L101.454 125.216C103.102 124.977 104.765 124.747 106.441 124.525L106.408 124.277C108.049 124.059 109.703 123.849 111.37 123.647L111.4 123.895C113.052 123.695 114.715 123.503 116.391 123.318L116.363 123.069C118.018 122.887 119.683 122.712 121.36 122.545L121.385 122.794C123.037 122.63 124.699 122.473 126.372 122.323L126.349 122.074C128.012 121.926 129.684 121.785 131.366 121.652L131.386 121.901C133.041 121.77 134.705 121.647 136.379 121.531L136.362 121.282C138.024 121.167 139.694 121.059 141.374 120.959L141.389 121.208C143.052 121.109 144.724 121.018 146.404 120.934L146.392 120.684C148.053 120.601 149.722 120.525 151.399 120.457L151.41 120.706C153.079 120.638 154.755 120.578 156.439 120.525L156.431 120.275C158.093 120.223 159.761 120.178 161.436 120.14L161.442 120.39C163.11 120.353 164.785 120.323 166.466 120.3L166.463 120.05C168.129 120.028 169.801 120.013 171.479 120.006L171.48 120.256C172.319 120.252 173.159 120.25 174 120.25C174.841 120.25 175.682 120.252 176.52 120.256L176.521 120.006C178.199 120.013 179.871 120.028 181.537 120.05L181.534 120.3C183.215 120.323 184.89 120.353 186.558 120.39L186.564 120.14C188.239 120.178 189.907 120.223 191.569 120.275L191.561 120.525C193.245 120.578 194.921 120.638 196.59 120.706L196.601 120.457C198.278 120.525 199.947 120.601 201.608 120.684L201.596 120.934C203.276 121.018 204.948 121.109 206.611 121.208L206.626 120.959C208.306 121.059 209.976 121.167 211.638 121.282L211.621 121.531C213.295 121.647 214.959 121.77 216.614 121.901L216.634 121.652C218.316 121.785 219.988 121.926 221.651 122.074L221.628 122.323C223.301 122.473 224.963 122.63 226.615 122.794L226.64 122.545C228.317 122.712 229.982 122.887 231.637 123.069L231.609 123.318C233.285 123.503 234.948 123.695 236.6 123.895L236.63 123.647C238.297 123.849 239.951 124.059 241.592 124.277L241.559 124.525C243.235 124.747 244.898 124.977 246.546 125.216L246.582 124.968C248.252 125.209 249.907 125.459 251.547 125.716L251.509 125.963C253.168 126.223 254.812 126.491 256.44 126.767L256.482 126.521C258.153 126.804 259.808 127.096 261.446 127.396L261.401 127.642C263.063 127.947 264.707 128.26 266.332 128.581L266.381 128.335C268.034 128.662 269.668 128.997 271.283 129.34L271.231 129.585C272.887 129.937 274.523 130.298 276.138 130.668L276.194 130.424C277.848 130.803 279.48 131.19 281.089 131.586L281.029 131.829C282.672 132.234 284.291 132.648 285.885 133.071L285.949 132.829C287.584 133.262 289.192 133.705 290.774 134.157L290.705 134.397C292.338 134.864 293.943 135.34 295.518 135.826L295.591 135.587C297.221 136.09 298.818 136.602 300.383 137.125L300.304 137.362C301.92 137.901 303.501 138.451 305.045 139.01L305.13 138.775C306.735 139.357 308.301 139.949 309.826 140.552L309.734 140.785C311.322 141.412 312.866 142.05 314.365 142.7L314.464 142.47C316.037 143.152 317.56 143.845 319.032 144.55L318.924 144.776C320.473 145.517 321.963 146.271 323.395 147.037L323.513 146.816C325.036 147.63 326.492 148.458 327.879 149.298L327.75 149.512C329.227 150.407 330.626 151.316 331.943 152.238L332.087 152.033C333.508 153.029 334.836 154.04 336.067 155.066L335.907 155.258C337.246 156.374 338.468 157.507 339.569 158.654L339.75 158.481C340.966 159.749 342.038 161.036 342.958 162.341L342.753 162.486C343.753 163.904 344.572 165.342 345.202 166.795L345.431 166.696Z",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M174 347C203.823 347 228 269.545 228 174C228 78.4547 203.823 0.999999 174 0.999998",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M222 340C251 335 276 265.127 276 174C276 82.873 250 13 222 8",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M174 347C144.177 347 120 269.545 120 174C120 78.4547 144.177 0.999999 174 0.999998",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M126 340C97 335 72 265.127 72 174C72 82.873 98 13 126 8",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("mask",{id:"crafted_svg__a",width:346,height:108,x:1,y:120,maskUnits:"userSpaceOnUse",style:{maskType:"alpha"}},u.createElement("ellipse",{cx:174,cy:174,fill:"#D9D9D9",rx:173,ry:54,style:{fill:"#D9D9D9",fill:"color(display-p3 0.8510 0.8510 0.8510)",fillOpacity:1}})),u.createElement("g",{mask:"url(#crafted_svg__a)"},u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M144.367 -64.7715L-56.7713 122.761",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M149.824 -58.9199L-51.3143 128.612",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M155.277 -53.0693L-45.8611 134.463",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M160.734 -47.2178L-40.4041 140.314",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M166.188 -41.3662L-34.951 146.166",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M171.645 -35.5146L-29.4939 152.018",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M177.102 -29.6641L-24.0369 157.868",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M182.555 -23.8125L-18.5838 163.72",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M188.012 -17.9609L-13.1268 169.571",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M193.465 -12.1094L-7.67363 175.423",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M198.922 -6.25879L-2.2166 181.273",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M204.379 -0.407227L3.24044 187.125",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M209.832 5.44434L8.69356 192.977",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M215.289 11.2959L14.1506 198.828",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M220.742 17.1465L19.6037 204.679",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M226.199 22.998L25.0607 210.53",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M231.656 28.8496L30.5178 216.382",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M237.109 34.7002L35.9709 222.232",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M242.566 40.5518L41.4279 228.084",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M248.02 46.4033L46.8811 233.936",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M253.477 52.2549L52.3381 239.787",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M258.934 58.1055L57.7951 245.638",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M264.387 63.957L63.2482 251.489",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M269.844 69.8086L68.7053 257.341",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M275.297 75.6602L74.1584 263.192",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M280.754 81.5107L79.6154 269.043",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M286.211 87.3623L85.0725 274.894",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M291.664 93.2139L90.5256 280.746",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M297.121 99.0645L95.9826 286.597",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M302.574 104.916L101.436 292.448",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M308.031 110.768L106.893 298.3",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M313.488 116.619L112.35 304.151",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M318.941 122.47L117.803 310.002",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M324.398 128.321L123.26 315.853",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M329.855 134.173L128.717 321.705",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M335.309 140.024L134.17 327.557",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M340.766 145.875L139.627 333.407",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M346.219 151.727L145.08 339.259",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M351.676 157.578L150.537 345.11",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M357.133 163.43L155.994 350.962",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M362.586 169.28L161.447 356.812",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M368.043 175.132L166.904 362.664",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M373.496 180.983L172.358 368.516",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M378.953 186.834L177.815 374.366",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M384.41 192.686L183.272 380.218",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M389.863 198.537L188.725 386.069",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M395.32 204.389L194.182 391.921",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}}),u.createElement("path",{stroke:"#539590",strokeWidth:.5,d:"M400.773 210.239L199.635 397.771",style:{stroke:"#539590",stroke:"color(display-p3 0.3255 0.5843 0.5647)",strokeOpacity:1}})));function H(){return(H=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let j=e=>u.createElement("svg",H({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 72 72"},e),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M33.7752 35.559C33.7752 42.4918 28.6849 48.0692 22.456 48.0692C16.227 48.0692 11.1367 42.4918 11.1367 35.559C11.1367 28.6262 16.227 23.0488 22.456 23.0488C28.6849 23.0488 33.7752 28.6262 33.7752 35.559Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M40.9221 35.5583C40.9221 47.7938 33.2841 57.5961 23.9884 57.5961C14.6927 57.5961 7.05469 47.7938 7.05469 35.5583C7.05469 23.3228 14.6927 13.5205 23.9884 13.5205C33.2841 13.5205 40.9221 23.3228 40.9221 35.5583Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M48.0686 35.2186C48.0686 51.3847 37.3201 64.4021 24.1593 64.4021C10.9985 64.4021 0.25 51.3847 0.25 35.2186C0.25 19.0526 10.9985 6.03516 24.1593 6.03516C37.3201 6.03516 48.0686 19.0526 48.0686 35.2186Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M54.8731 35.2176C54.8731 53.0699 42.7578 67.4635 27.9014 67.4635C13.045 67.4635 0.929688 53.0699 0.929688 35.2176C0.929688 17.3654 13.045 2.97168 27.9014 2.97168C42.7578 2.97168 54.8731 17.3654 54.8731 35.2176Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M62.0188 34.1974C62.0188 52.5905 48.3241 67.4642 31.4743 67.4642C14.6245 67.4642 0.929688 52.5905 0.929688 34.1974C0.929688 15.8043 14.6245 0.930664 31.4743 0.930664C48.3241 0.930664 62.0188 15.8043 62.0188 34.1974Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("circle",{cx:35.728,cy:35.728,r:35.478,stroke:"#DBCAAB",strokeWidth:.5,style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M71.2071 35.7285C71.2071 55.3332 55.9982 71.207 37.2598 71.207C18.5214 71.207 3.3125 55.3332 3.3125 35.7285C3.3125 16.1238 18.5214 0.25 37.2598 0.25C55.9982 0.25 71.2071 16.1238 71.2071 35.7285Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M71.2069 35.5579C71.2069 53.5945 58.7899 68.1441 43.5546 68.1441C28.3193 68.1441 15.9023 53.5945 15.9023 35.5579C15.9023 17.5213 28.3193 2.97168 43.5546 2.97168C58.7899 2.97168 71.2069 17.5213 71.2069 35.5579Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M71.205 35.7287C71.205 43.6688 68.876 50.847 65.1231 56.0339C61.37 61.2211 56.2068 64.4018 50.5283 64.4018C44.8498 64.4018 39.6865 61.2211 35.9334 56.0339C32.1805 50.847 29.8516 43.6688 29.8516 35.7287C29.8516 27.7887 32.1805 20.6105 35.9334 15.4236C39.6865 10.2363 44.8498 7.05566 50.5283 7.05566C56.2068 7.05566 61.37 10.2363 65.1231 15.4236C68.876 20.6105 71.205 27.7887 71.205 35.7287Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M71.2064 35.5587C71.2064 42.6113 69.3318 48.9847 66.314 53.5875C63.2949 58.1925 59.1526 60.9992 54.613 60.9992C50.0733 60.9992 45.9311 58.1925 42.9119 53.5875C39.8942 48.9847 38.0195 42.6113 38.0195 35.5587C38.0195 28.5061 39.8942 22.1326 42.9119 17.5298C45.9311 12.9249 50.0733 10.1182 54.613 10.1182C59.1526 10.1182 63.2949 12.9249 66.314 17.5298C69.3318 22.1326 71.2064 28.5061 71.2064 35.5587Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}),u.createElement("path",{stroke:"#DBCAAB",strokeWidth:.5,d:"M71.2079 35.559C71.2079 40.541 69.792 45.0406 67.5158 48.2881C65.239 51.5363 62.1175 53.5135 58.6977 53.5135C55.2779 53.5135 52.1564 51.5363 49.8796 48.2881C47.6033 45.0406 46.1875 40.541 46.1875 35.559C46.1875 30.5771 47.6033 26.0774 49.8796 22.83C52.1564 19.5817 55.2779 17.6045 58.6977 17.6045C62.1175 17.6045 65.239 19.5817 67.5158 22.83C69.792 26.0774 71.2079 30.5771 71.2079 35.559Z",style:{stroke:"#DBCAAB",stroke:"color(display-p3 0.8588 0.7922 0.6706)",strokeOpacity:1}}));function L(){return(L=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let _=e=>u.createElement("svg",L({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 428 390"},e),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M397 190H27V198C27 295.202 105.798 374 203 374H221C318.202 374 397 295.202 397 198V190Z",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M122 163H27L67 65H212M122 163L212 65M122 163H301M212 65H357L397 163H301M212 65L301 163",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M67.5 65.5L68 161.5L122 65.5L97 163",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M357 65.5L356.5 161.5L302.5 65.5L327.5 163",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M122 163V65L211.5 20.5",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M301.5 163V65L212 20.5",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M67 64.9393L212 20M357 64.9393L212 20M212 20V390",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M212 0V36",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M386 257.25C381.085 289.472 307.555 315.25 212 315.25C116.445 315.25 43.4068 289.472 38 257.25",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeDasharray:"4 5",strokeWidth:.5,d:"M38 258C42.9153 225.778 116.445 200 212 200C307.555 200 380.593 225.778 386 258",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M365.75 257.5C365.75 263.378 361.53 269.034 353.759 274.224C345.997 279.408 334.749 284.086 320.826 288.019C292.986 295.883 254.51 300.75 212 300.75C169.49 300.75 131.014 295.883 103.174 288.019C89.2514 284.086 78.003 279.408 70.2409 274.224C62.4695 269.034 58.25 263.378 58.25 257.5C58.25 251.622 62.4695 245.966 70.2409 240.776C78.003 235.592 89.2514 230.914 103.174 226.981C131.014 219.117 169.49 214.25 212 214.25C254.51 214.25 292.986 219.117 320.826 226.981C334.749 230.914 345.997 235.592 353.759 240.776C361.53 245.966 365.75 251.622 365.75 257.5Z",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M0 190H428",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M184 19.5H240",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}),u.createElement("path",{stroke:"#B9DCEF",strokeWidth:.5,d:"M152 375H276",style:{stroke:"#B9DCEF",stroke:"color(display-p3 0.7255 0.8627 0.9373)",strokeOpacity:1}}));function I(){return(I=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let B=e=>u.createElement("svg",I({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 383 381"},e),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M369 171C369 204.689 293.336 232 200 232C106.664 232 31 204.689 31 171",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeDasharray:"5 3",strokeWidth:.5,d:"M31 176C31 142.311 106.664 115 200 115C293.336 115 369 142.311 369 176",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M337 258C337 285.614 275.663 308 200 308C124.337 308 63 285.614 63 258",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeDasharray:"5 3",strokeWidth:.5,d:"M63 263C63 235.386 124.337 213 200 213C275.663 213 337 235.386 337 263",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M337 101C337 128.614 275.663 151 200 151C124.337 151 63 128.614 63 101",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeDasharray:"5 3",strokeWidth:.5,d:"M63 106C63 78.3858 124.337 56 200 56C275.663 56 337 78.3858 337 106",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("circle",{cx:200,cy:182,r:159.75,stroke:"#F3E8AF",strokeWidth:.5,style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("circle",{cx:200,cy:182,r:169.75,stroke:"#F3E8AF",strokeWidth:.5,style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M200 35V329",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M347 182L53 182",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M303.945 285.944L96.0559 78.0549",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M96.0547 285.944L303.944 78.0549",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M58.0078 220.046L341.99 143.953",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M58.0078 143.953L341.99 220.046",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M72.6914 108.5L327.303 255.5",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M126.496 54.6943L273.496 309.306",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M161.949 40.0088L238.042 323.991",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M238.043 40.0088L161.95 323.991",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M273.496 54.6943L126.496 309.306",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M327.301 108.5L72.6893 255.5",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("circle",{cx:200,cy:182,r:18.75,fill:"#14151A",stroke:"#F3E8AF",strokeWidth:.5,style:{fill:"#14151A",fill:"color(display-p3 0.0784 0.0824 0.1020)",fillOpacity:1,stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M379 3L14 368",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("circle",{cx:30,cy:351,r:29.75,stroke:"#F3E8AF",strokeWidth:.5,style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("circle",{cx:374,cy:9,r:8.75,stroke:"#F3E8AF",strokeWidth:.5,style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M82.0352 44.0059C154.865 -17.0921 261.497 -11.4107 327.5 54.5298",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}),u.createElement("path",{stroke:"#F3E8AF",strokeWidth:.5,d:"M334.498 47.5298C317.058 30.1056 296.78 16.8889 275.039 8",style:{stroke:"#F3E8AF",stroke:"color(display-p3 0.9531 0.9106 0.6872)",strokeOpacity:1}}));function F(){return(F=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function R(){return(R=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function M(){return(M=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function S(){let e,t,r,i,o,n,a,c,d,h,y,A,g,m,x,k;let b=(0,s.c)(27),w=(0,u.useRef)(null),C=(0,u.useRef)(null),E=(0,u.useRef)(null),H=(0,u.useRef)(null),L=(0,u.useRef)(null),I=(0,u.useRef)(null),F=(0,u.useRef)(null),R=(0,v.Q)("bottom","bottom","bottom","bottom"),M=(0,v.Q)("-50%","-50%","-50%","30%"),S=(0,v.Q)(-150,-150,-150,-120),U=(0,v.Q)(!1,!1,!1,!0),Q=(0,v.Q)(151,151,151,75.82);b[0]===Symbol.for("react.memo_cache_sentinel")?(t={title:"Built for speed",subtitle:"Lightning-fast performance for every task",image:(0,l.jsx)(B,{ref:C})},b[0]=t):t=b[0],b[1]===Symbol.for("react.memo_cache_sentinel")?(r={title:"Beautifully crafted",subtitle:"Designed to be easy on the eyes",image:(0,l.jsx)(O,{ref:E})},b[1]=r):r=b[1],b[2]===Symbol.for("react.memo_cache_sentinel")?(i=[t,r,{title:"Optimally secure",subtitle:"Enterprise grade security, verified by Google",image:(0,l.jsx)(_,{ref:H})}],b[2]=i):i=b[2],e=i,b[3]!==M||b[4]!==R||b[5]!==U||b[6]!==S?(o=()=>{if(!w.current||!C.current||!E.current||!H.current)return;let e=C.current.querySelectorAll("path"),t=E.current.querySelectorAll("path"),r=H.current.querySelectorAll("path"),i=[C,E,H],o=[e,t,r],l=[".home__built-card-0",".home__built-card-1",".home__built-card-2"],s=[I.current,L.current,F.current];l&&s&&i.forEach((e,t)=>{let r=o[t],i=l[t];if(!r||!i)return;let n=s[t];if(!e.current||!r||!i||!n)return;let a=w.current?.querySelector(i);if(!a)return;let c=a.querySelector(".home__built-card--title"),d=a.querySelector(".home__built-card--sub"),u=p.Ay.timeline({scrollTrigger:{trigger:e.current,start:`top ${R}`,end:`bottom ${M}`,scrub:!0,onEnter:()=>{u.scrollTrigger?.refresh()},onEnterBack:()=>{u.scrollTrigger?.refresh()}}});u.fromTo(r,{drawSVG:"0 0"},{opacity:1,duration:.2,drawSVG:"0 100%"},.1),u.to(n,{opacity:1,duration:.5},0),u.to(a,{opacity:1,duration:.3},0),U||u.to(a,{yPercent:S,duration:1},0),u.to([c,d],{y:0,opacity:1,duration:.2,stagger:.05,ease:"power3.inOut"},.15)})},n=[R,S,M,U],b[3]=M,b[4]=R,b[5]=U,b[6]=S,b[7]=o,b[8]=n):(o=b[7],n=b[8]),b[9]===Symbol.for("react.memo_cache_sentinel")?(a={scope:w,recreateOnResize:!0},b[9]=a):a=b[9],(0,f.s)(o,n,a),b[10]===Symbol.for("react.memo_cache_sentinel")?(c=e.map(D),b[10]=c):c=b[10];let N=c;return b[11]!==U?(d=!U&&(0,l.jsxs)(l.Fragment,{children:[(0,l.jsxs)(T,{children:[N[0],(0,l.jsx)(q,{ref:L}),N[2]]}),(0,l.jsxs)(V,{children:[(0,l.jsx)(ee,{ref:I}),N[1],(0,l.jsx)(et,{ref:F})]})]}),b[11]=U,b[12]=d):d=b[12],b[13]!==U?(h=U&&(0,l.jsxs)(en,{children:[N[0],(0,l.jsx)(ee,{ref:I}),N[1],(0,l.jsx)(q,{ref:L}),N[2],(0,l.jsx)(et,{ref:F})]}),b[13]=U,b[14]=h):h=b[14],b[15]!==d||b[16]!==h?(y=(0,l.jsxs)(z,{"data-header-hide":!0,children:[d,h]}),b[15]=d,b[16]=h,b[17]=y):y=b[17],b[18]===Symbol.for("react.memo_cache_sentinel")?(A=(0,l.jsx)(G,{children:(0,l.jsx)(Z,{marqueeSpeed:.5,disableDrag:!0,children:(0,l.jsxs)(W,{children:["Micro is Built different.",(0,l.jsx)($,{children:(0,l.jsx)(j,{})})]})})}),b[18]=A):A=b[18],b[19]!==Q?(g=(0,l.jsx)(eo,{isLight:!0,size:Q}),m=(0,l.jsx)(el,{isLight:!0,size:Q}),b[19]=Q,b[20]=g,b[21]=m):(g=b[20],m=b[21]),b[22]===Symbol.for("react.memo_cache_sentinel")?(x=(0,l.jsx)(es,{isLight:!0,size:213}),b[22]=x):x=b[22],b[23]!==y||b[24]!==g||b[25]!==m?(k=(0,l.jsxs)(P,{ref:w,children:[y,A,g,m,x]}),b[23]=y,b[24]=g,b[25]=m,b[26]=k):k=b[26],k}function D(e,t){return(0,l.jsxs)(N,{className:`home__built-card-${t}`,children:[(0,l.jsx)(U,{children:e.image}),(0,l.jsxs)(X,{children:[(0,l.jsxs)(J,{className:"home__built-card--title",children:[(0,l.jsx)(K,{children:e.title}),(0,l.jsxs)(er,{children:["[\xa00",t+1,"\xa0]"]})]}),(0,l.jsx)(Y,{className:"home__built-card--sub",children:e.subtitle})]})]},e.title)}p.Ay.registerPlugin(c.u,a.E);let P=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		position: relative;
		grid-column: fullbleed;
		${w.A.lightDotBackground};
		overflow-x: clip;
		display: grid;
		grid-template-columns: subgrid;
		grid-template-rows: auto 1fr;
		padding-top: 100vh;
	`)}),$=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		position: relative;
		background: ${w.A.black3};
		display: grid;
		place-items: center;
		border-radius: 16px;
		padding: 20px;
		margin: 0 24px;
		isolation: isolate;
		will-change: transform;

		svg {
			width: 71.5px;
			height: auto;
		}
	`),...(0,g.PK)((0,g.AH)`
		border-radius: 8px;
		padding: 9.77px;

		svg {
			width: 35.73px;
			height: auto;
		}
	`)}),U=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		position: relative;
		background: ${w.A.black3};
		display: grid;
		place-items: center;
		border-radius: 16px;
		padding: 20px 41px;
		isolation: isolate;

		svg {
			width: 100%;
			height: auto;
		}
	`)}),W=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		display: flex;
		align-items: center;
		${C.Ay.oversize3};
		color: ${w.A.black3};
	`),...(0,g.PK)((0,g.AH)`
		display: flex;
		align-items: center;
		${C.Ay.header2};
		color: ${w.A.black3};
	`)}),z=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		display: grid;
		grid-template-columns: subgrid;
		grid-column: main;
		grid-row: 1 / 3;
		height: 100%;
	`)}),Q=(0,g.AH)`
	border-left: 1px solid #e5d8c4;
`,T=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		${Q};
		grid-column: column-3 / dead-center;
		height: 100%;
		padding-top: 495px;
	`),...(0,g.ZQ)((0,g.AH)`
		grid-column: column-1-start / dead-center;
	`),...(0,g.PK)((0,g.AH)`
		display: none;
	`)}),V=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		${Q};
		grid-column: dead-center / column-10-end;
		border-right: 1px solid #e5d8c4;
		padding-top: 623px;
	`),...(0,g.ZQ)((0,g.AH)`
		padding-top: 560px;
		grid-column: dead-center / main-end;
	`),...(0,g.PK)((0,g.AH)`
		display: none;
	`)}),Z=(0,g.I4)(function({children:e,ArrowButton:t,BackArrowButton:r,className:i,marqueeSpeed:o=0,reversed:s=!1,disableDrag:n=!1,scrollVelocity:a,onChange:g,loopRef:v}){let w=(0,u.useRef)(null),[C,E]=(0,u.useState)(1),O=(0,u.useRef)(g);O.current=g;let{result:H}=(0,f.s)(()=>{var e,t;let r,i;if(!w.current)return;let l=!n,u=w.current.children.length/C,h=w.current.children[u-1],g=Number(p.os.getProperty(h??null,"marginRight")),f=w.current.children[u],m=Number(p.os.getProperty(f??null,"marginLeft")),x=h&&f?Math.abs(h.getBoundingClientRect().right-f.getBoundingClientRect().left)-g-m:0,k=(e=w.current.children,t={draggable:l,paused:0===o,center:!0,speed:0===o?2:o,reversed:s,repeat:-1,paddingRight:x,onChange:(e,t)=>{O.current?.(t)}},e=p.os.utils.toArray(e),t=t||{},p.os.context(()=>{let r=t.onChange,o=0,l=p.os.timeline({repeat:t.repeat,onUpdate:r&&(()=>{let t=l.closestIndex();o!==t&&(o=t,r(e[t],t))}),paused:t.paused,defaults:{ease:"none"},onReverseComplete:()=>l.totalTime(l.rawTime()+100*l.duration())}),s=e.length,n=e[0].offsetLeft,a=[],c=[],d=[],u=[],h=0,g=!1,f=t.center,m=100*(t.speed||1),x=!1===t.snap?e=>e:p.os.utils.snap(t.snap||1),k=0,b=!0===f?e[0].parentNode:p.os.utils.toArray(f)[0]||e[0].parentNode,v,w=()=>e[s-1].offsetLeft+u[s-1]/100*c[s-1]-n+d[0]+e[s-1].offsetWidth*p.os.getProperty(e[s-1],"scaleX")+(Number.parseFloat(t.paddingRight)||0),C=()=>{let t=b.getBoundingClientRect(),r;e.forEach((e,i)=>{c[i]=Number.parseFloat(p.os.getProperty(e,"width","px")),u[i]=x(Number.parseFloat(p.os.getProperty(e,"x","px"))/c[i]*100+p.os.getProperty(e,"xPercent")),r=e.getBoundingClientRect(),d[i]=r.left-(i?t.right:t.left),t=r}),p.os.set(e,{xPercent:e=>u[e]}),v=w()},E,O=()=>{k=f?l.duration()*(b.offsetWidth/2)/v:0,f&&a.forEach((e,t)=>{a[t]=E(l.labels["label"+t]+l.duration()*c[t]/2/v-k)})},H=(e,t,r)=>{let i=e.length,o=1e10,l=0,s;for(;i--;)(s=Math.abs(e[i]-t))>r/2&&(s=r-s),s<o&&(o=s,l=i);return l},j=()=>{let t,r,i,o,h;for(l.clear(),t=0;t<s;t++)r=e[t],i=u[t]/100*c[t],h=(o=r.offsetLeft+i-n+d[0])+c[t]*p.os.getProperty(r,"scaleX"),l.to(r,{xPercent:x((i-h)/c[t]*100),duration:h/m},0).fromTo(r,{xPercent:x((i-h+v)/c[t]*100)},{xPercent:u[t],duration:(i-h+v-i)/m,immediateRender:!1},h/m).add("label"+t,o/m),a[t]=o/m;E=p.os.utils.wrap(0,l.duration())},L=e=>{let r=l.progress();l.progress(0,!0),C(),e&&j(),O(),e&&l.draggable&&t.paused?l.time(a[h],!0):l.progress(r,!0)},_=()=>L(!0),I;function B(e,t){t=t||{},Math.abs(e-h)>s/2&&(e+=e>h?-s:s);let r=p.os.utils.wrap(0,s,e),i=a[r];return i>l.time()!=e>h&&e!==h&&(i+=l.duration()*(e>h?1:-1)),(i<0||i>l.duration())&&(t.modifiers={time:E}),h=r,t.overwrite=!0,p.os.killTweensOf(I),0===t.duration?l.time(E(i)):l.tweenTo(i,t)}if(p.os.set(e,{x:0}),C(),j(),O(),window.addEventListener("resize",_),l.toIndex=(e,t)=>B(e,t),l.closestIndex=e=>{let t=H(a,l.time(),l.duration());return e&&(h=t,g=!1),t},l.current=()=>g?l.closestIndex(!0):h,l.next=e=>B(l.current()+1,e),l.previous=e=>B(l.current()-1,e),l.times=a,l.progress(1,!0).progress(0,!0),t.reversed&&(l.vars.onReverseComplete(),l.reverse()),t.draggable&&"function"==typeof y.s){I=document.createElement("div");let t=p.os.utils.wrap(0,1),r,i,o,s,n,c,d,u=()=>l.progress(t(i+(o.startX-o.x)*r)),h=()=>l.closestIndex(!0);void 0===A.w6&&console.warn("InertiaPlugin required for momentum-based scrolling and snapping. https://greensock.com/club"),o=y.s.create(I,{trigger:e[0].parentNode,type:"x",onPressInit(){d=!1;let e=this.x;p.os.killTweensOf(l),c=c||!l.paused(),l.pause(),i=l.progress(),L(),n=-(i/(r=1/v))-e,p.os.set(I,{x:-(i/r)})},onDrag:()=>{d=!0,u()},onThrowUpdate:u,overshootTolerance:0,inertia:!0,snap(e){if(10>Math.abs(-(i/r)-this.x))return s+n;let t=-(e*r)*l.duration(),o=E(t),c=a[H(a,o,l.duration())]-o;return Math.abs(c)>l.duration()/2&&(c+=c<0?l.duration():-l.duration()),s=-((t+c)/l.duration()/r)},onRelease(){h(),o.isThrowing&&(g=!0),!d&&c&&l.play()},onThrowComplete:()=>{h(),c&&l.play()}})[0],l.draggable=o}return l.scrollBy=e=>{let t=p.os.utils.wrap(0,1)(l.progress()+e/v);l.progress(t),l.closestIndex(!0)},l.closestIndex(!0),o=h,r&&r(e[h],h),i=l,()=>window.removeEventListener("resize",_)}),i);if(v&&(v.current=k),0===o&&(k.toIndex(0),k.timeScale(999),requestAnimationFrame(()=>{k.timeScale(1)})),a&&c.u.create({onUpdate:e=>{let t="function"==typeof a?a(e.getVelocity()):e.getVelocity()*(a/1e3);k.scrollBy(t)}}),!l)return k;let b=e=>{!(Math.abs(e.deltaX)<=Math.abs(e.deltaY))&&(k.draggable.isDragging||k.draggable.isThrowing||(e.preventDefault(),r?.kill(),p.os.killTweensOf(k),k.scrollBy(e.deltaX)))};return p.os.context(()=>{let e=w.current;return e?.addEventListener("wheel",b),()=>{e?.removeEventListener("wheel",b)}}),d.nu.create({target:w.current,type:"wheel",onStop:()=>{o&&!s?k.play():o&&s?k.reverse():r=k.toIndex(k.current(),{ease:"power3.inOut",duration:1})}}),k},[o,s,n,a,C,v],{recreateOnResize:!0});(0,u.useEffect)(()=>{let e=()=>{if(w.current){let e=Array.from(w.current.children).reduce((e,t)=>e+t.clientWidth,0);E(t=>{let r=Math.ceil(window.innerWidth/(e/t))+1;return Number.isFinite(r)&&r>0?r:t})}};e();let t=Array.from(w.current?.querySelectorAll("*")??[]),r=new ResizeObserver(e);for(let e of t)r.observe(e);let i=(0,h.oq)("resize",e);return()=>{i.cleanup(),r.disconnect()}},[]);let j=!!(t||r),L=!!(t&&r),_=r||t,I=t||r;return(0,l.jsxs)(m,{className:i,children:[(0,l.jsx)(x,{ref:w,className:"track",children:Array.from({length:C},(t,r)=>(0,l.jsx)(u.Fragment,{children:e},r))}),j&&(0,l.jsxs)(L?k:b,{className:"buttons",children:[_&&(0,l.jsx)(_,{onClick:()=>H?.previous({duration:1,ease:"power3.out"})}),I&&(0,l.jsx)(I,{onClick:()=>H?.next({duration:1,ease:"power3.out"})})]})]})},{...(0,g.vi)((0,g.AH)`
		position: relative;
	`)}),G=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		grid-column: fullbleed;
		padding-top: 230px;
		grid-row: 1;
		position: relative;
		z-index: 1;
	`),...(0,g.PK)((0,g.AH)`
		padding-top: 180px;
	`)}),N=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		border-radius: 16px;
		display: flex;
		flex-direction: column;
		gap: 18px;
		color: ${w.A.black2};
		opacity: 0;
		transform: translateY(50%);
		position: relative;
		z-index: 2;
		will-change: transform;
	`),...(0,g.PK)((0,g.AH)`
		position: relative;
		opacity: 0;
		transform: translateY(0);
		z-index: 1;
	`)}),K=(0,g.I4)("h3",{...(0,g.vi)((0,g.AH)`
		${C.Ay.header6};
	`),...(0,g.PK)((0,g.AH)`
		${C.Ay.header4};
	`)}),J=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		margin-bottom: 16px;
		opacity: 0;
		transform: translateY(40px);
		display: flex;
		justify-content: space-between;
		width: 100%;
		will-change: transform;
	`)}),Y=(0,g.I4)("h4",{...(0,g.vi)((0,g.AH)`
		${C.Ay.body1};
		opacity: 0;
		transform: translateY(40px);
		will-change: transform;
	`),...(0,g.PK)((0,g.AH)`
		${C.Ay.body1};
	`)}),X=(0,g.I4)("div",{position:"relative"}),q=(0,g.I4)(e=>u.createElement("svg",F({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 510 738"},e),i||(i=u.createElement("circle",{cx:255,cy:483,r:254.5,stroke:"#E1D8C8"})),o||(o=u.createElement("circle",{cx:255,cy:255,r:254.5,stroke:"#E1D8C8"}))),{...(0,g.vi)((0,g.AH)`
		margin: 28px 0 128px;
		opacity: 0;
	`),...(0,g.ZQ)((0,g.AH)`
		margin: 28px 0 146px;
	`),...(0,g.PK)((0,g.AH)`
		position: absolute;
		z-index: 0;
		width: 240px;
		height: 480px;
		top: 850px;
		left: 0;
		opacity: 1;
	`)}),ee=(0,g.I4)(e=>u.createElement("svg",M({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 512 419"},e),u.createElement("rect",{width:254,height:418,x:257.5,y:.5,stroke:"#E1D8C8",rx:127,style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}}),u.createElement("rect",{width:257,height:418,x:.5,y:.5,stroke:"#E1D8C8",rx:128.5,style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}})),{...(0,g.vi)((0,g.AH)`
		margin: 0 0 163px;
		opacity: 0;
	`),...(0,g.PK)((0,g.AH)`
		position: absolute;
		z-index: 0;
		width: 240px;
		right: 0;
		height: 226px;
		top: 620px;
		opacity: 1;
	`)}),et=(0,g.I4)(e=>u.createElement("svg",R({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 510 424"},e),u.createElement("rect",{width:509,height:253,x:.5,y:.5,stroke:"#E1D8C8",rx:126.5,style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}}),u.createElement("circle",{cx:425,cy:339,r:84.5,stroke:"#E1D8C8",style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}}),u.createElement("path",{stroke:"#E1D8C8",d:"M338.5 339C338.5 385.671 300.889 423.5 254.5 423.5C208.111 423.5 170.5 385.671 170.5 339C170.5 292.329 208.111 254.5 254.5 254.5C300.889 254.5 338.5 292.329 338.5 339Z",style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}}),u.createElement("circle",{cx:85,cy:339,r:84.5,stroke:"#E1D8C8",style:{stroke:"#E1D8C8",stroke:"color(display-p3 0.8824 0.8471 0.7843)",strokeOpacity:1}})),{...(0,g.vi)((0,g.AH)`
		margin: 418px 0 166px;
		opacity: 0;
	`),...(0,g.ZQ)((0,g.AH)`
		margin: 420px 0 156px;
		opacity: 1;
	`),...(0,g.PK)((0,g.AH)`
		height: auto;
		width: 100%;
		position: absolute;
		z-index: 0;
		left: 0;
		bottom: 0;
		margin: 0;
		opacity: 1;
	`)}),er=(0,g.I4)("span",{...(0,g.vi)((0,g.AH)`
		${C.Ay.kicker2};
		color: ${w.A.black2};
	`)}),ei=(0,g.I4)(n.A,{...(0,g.vi)((0,g.AH)`
		position: absolute;
		z-index: 2;
	`)}),eo=(0,g.I4)(ei,{...(0,g.vi)((0,g.AH)`
		left: 148px;
		top: calc(95vh + 160px);
	`),...(0,g.PK)((0,g.AH)`
		left: 20px;
		top: calc(95vh + 120px);
		width: 70px;
		height: 70px;
	`)}),el=(0,g.I4)(ei,{...(0,g.vi)((0,g.AH)`
		left: 665px;
		top: calc(95vh + 40px);
	`),...(0,g.PK)((0,g.AH)`
		left: unset;
		right: 60px;
		top: calc(95vh + 200px);
		width: 70px;
		height: 70px;
	`)}),es=(0,g.I4)(ei,{...(0,g.vi)((0,g.AH)`
		right: 148px;
		top: calc(95vh + 96px);
	`),...(0,g.ZQ)((0,g.AH)`
		display: none;
	`),...(0,g.PK)((0,g.AH)`
		display: none;
	`)}),en=(0,g.I4)("div",{...(0,g.vi)((0,g.AH)`
		display: none;
	`),...(0,g.PK)((0,g.AH)`
		position: relative;
		padding: 373px 0 200px;
		display: flex;
		grid-column: main;
		grid-row: 1 / 3;
		flex-direction: column;
		gap: 100px;
	`)})},6253:(e,t,r)=>{"use strict";r.d(t,{A:()=>c,U:()=>a});var i=r(884),o=r(5611),l=r(7537),s=r(9302),n=r(4522);function a(e,t){if(0===e.length)return[];let{triggerPoint:r=.9,duration:o=.8,ease:l="power3.inOut",delay:s=.15,from:n={yPercent:100,opacity:0},to:a={yPercent:0,opacity:1}}=t,c=[];if(1===e.length){let t=i.Ay.timeline({scrollTrigger:{trigger:e[0],start:`clamp(top ${100*r}%)`,toggleActions:"play none none reverse"}});i.Ay.set(e,n),t.to(e,{...a,duration:o,ease:l},s),c.push(t)}else for(let t of e){i.Ay.set(t,n);let e=i.Ay.timeline({scrollTrigger:{trigger:t,start:`clamp(top ${100*r}%)`,toggleActions:"play none none reverse"}});e.to(t,{...a,duration:o,ease:l},s),c.push(e)}return c}function c(e,t={}){let r=(0,n.useRef)(t);r.current=t,(0,s.s)(()=>{if(!e||!l.Bd)return;let t=(Array.isArray(e)?e:[e]).map(e=>e.current).filter(Boolean);0!==t.length&&a(t,r.current)},[e])}i.Ay.registerPlugin(o.u)},6267:(e,t,r)=>{Promise.resolve().then(r.bind(r,2508)),Promise.resolve().then(r.bind(r,1373)),Promise.resolve().then(r.bind(r,9384)),Promise.resolve().then(r.bind(r,5532)),Promise.resolve().then(r.bind(r,993)),Promise.resolve().then(r.bind(r,9082)),Promise.resolve().then(r.bind(r,3008)),Promise.resolve().then(r.bind(r,2114)),Promise.resolve().then(r.bind(r,7746))},7008:(e,t,r)=>{"use strict";r.d(t,{A:()=>l});var i=r(5611),o=r(1839);function l({smoothType:e="both",smoothLevel:t=200,...r}){let l=[],s=i.u.create({pin:!0,...r,onRefresh:(...e)=>{for(let e of l)e.scrollTrigger?.refresh();r.onRefresh?.(...e)}});if("fixed"===r.pinType||0===t)return s;let n=r.pin?.parentElement??r.trigger?.parentElement??null,a=e=>Math.min((s.end-s.start)/2,e);for(let r of(("in"===e||"both"===e)&&l.push(o.os.fromTo(n,{y:0},{y:a(t)/4,ease:"power1.in",scrollTrigger:{start:()=>s.start-a(t),end:()=>s.start,scrub:!0}}),o.os.fromTo(n,{y:a(t)/4},{y:0,ease:"power1.out",scrollTrigger:{start:()=>s.start,end:()=>s.start+a(t),scrub:!0}})),("out"===e||"both"===e)&&l.push(o.os.fromTo(n,{y:0},{y:-a(t)/4,ease:"power1.in",scrollTrigger:{start:()=>s.end-a(t),end:()=>s.end,scrub:!0}}),o.os.fromTo(n,{y:-a(t)/4},{y:0,ease:"power1.out",scrollTrigger:{start:()=>s.end,end:()=>s.end+a(t),scrub:!0}})),l))r.render(1);return s}},7606:(e,t,r)=>{"use strict";r.d(t,{default:()=>p});var i=r(8946),o=r(954),l=r(7248),s=r(7865),n=r(4522);let a=(0,n.createContext)(!1),c=(e,t)=>t?"eager":"default"!==e?void 0!==e?e:"lazy":void 0;function p(e){let t,r,l,s,p,d,y,A,g,f;let m=(0,o.c)(27);m[0]!==e?({src:s,alt:p,objectFit:d,objectPosition:r,loading:t,sizes:y,...l}=e,m[0]=e,m[1]=t,m[2]=r,m[3]=l,m[4]=s,m[5]=p,m[6]=d,m[7]=y):(t=m[1],r=m[2],l=m[3],s=m[4],p=m[5],d=m[6],y=m[7]);let x=void 0===p?"":p,k=void 0===d?"cover":d,b=void 0===y?"100vw":y;if(!s)return null;let v=(0,n.use)(a);m[8]!==v||m[9]!==t?(A=c(t,v),m[8]=v,m[9]=t,m[10]=A):A=m[10];let w=A;m[11]!==x||m[12]!==k||m[13]!==r||m[14]!==l||m[15]!==w?(g={objectFit:k,objectPosition:r,alt:x,loading:w,...l},m[11]=x,m[12]=k,m[13]=r,m[14]=l,m[15]=w,m[16]=g):g=m[16];let C=g;if("string"==typeof s){let e;let t=C.width&&C.height?`${C.width}/${C.height}`:"";return m[17]!==C||m[18]!==s||m[19]!==t?(e=(0,i.jsx)(u,{...C,src:s,aspectRatio:t}),m[17]=C,m[18]=s,m[19]=t,m[20]=e):e=m[20],e}let E=s.src.endsWith(".svg")||s.src.startsWith("data:image/svg+xml")?void 0:"blur",O=C.width&&C.height?`${C.width}/${C.height}`:void 0;return m[21]!==C||m[22]!==b||m[23]!==s||m[24]!==E||m[25]!==O?(f=(0,i.jsx)(h,{placeholder:E,...C,src:s,sizes:b,aspectRatio:O}),m[21]=C,m[22]=b,m[23]=s,m[24]=E,m[25]=O,m[26]=f):f=m[26],f}let d=({objectFit:e,objectPosition:t,aspectRatio:r})=>({display:"block",objectFit:e,objectPosition:t,height:"auto",width:"100%",aspectRatio:r}),u=(0,l.I4)("img",d),h=(0,l.I4)(s.default,d)},9082:(e,t,r)=>{"use strict";r.d(t,{default:()=>tt});var i,o,l,s,n,a,c,p,d,u,h,y,A=r(8946),g=r(954),f=r(1839),m=r(2478),x=r(1290),k=r(7606),b=r(7008),v=r(7248),w=r(9302),C=r(4052),E=r(9144),O=r(4522),H=r(9986),j=r(2048);let L={src:"/_next/static/media/CRM.0445427c.png",height:601,width:637,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEUaGxwVFhkjJCZNTE4TFBYbHB4ODxNIRy9tAAAABHRSTlPx/v75fE3PCQAAAAlwSFlzAAALEwAACxMBAJqcGAAAAC9JREFUeJw1ysENwwAQwzD7Knn/kYMGCN/M7+6E5gpsC6+Sqhai0rLU/5YUZSOfBx/8ANCsAdBnAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:8},_={src:"/_next/static/media/Calendar.09832af1.png",height:601,width:637,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAMFBMVEUgISLsvYUoKSjimp/lpJXkr4sTFBsOEBQaHCCbb2n1pKr3r6BFQkb5vJTZvbSWdFg2zCEOAAAABnRSTlP+/vf9/v7ArUxxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAOElEQVR4nB2JyQ0AMQyEcI6xc27/3a4cPiCBWe+t1YrZOWvNyb3fSNjbJXcnAgg5qReS8olCPsoPPBkBeauAkYQAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8},I={src:"/_next/static/media/Company.490f9ed7.png",height:606,width:642,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAP1BMVEUTFBcvT3A0YZp9fn1xLmdNF0UUJTcODhAWFxkdHiFEQ0cWGRonJykAAwIlECAfOlwOGiMeL0VER0iVjJTLO7UlkVtVAAAAD3RSTlP+/f39/v77/uT+/f////4xZN62AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAO0lEQVR4nC3GSRJAQBQE0US38lVPhvufVRBy8xK1lMU6cLpT7XNnuXKrxzTYT1uSiSgBfudDIFFss/09ULwCIfUZ1NQAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8};var B=r(3764);function F(e,t,r=["#68D9B7","#DEC073","#A888AB","#DEC6E0"]){var i;let o=e/window.innerWidth,l={origin:{x:o,y:t/window.innerHeight},colors:r,gravity:.19999999999999996*Math.random()+(i=.4),angle:120,decay:.85};function s(e,t){(0,B.A)({...l,...t,particleCount:Math.floor(100*e)})}s(.25,{spread:26,startVelocity:55}),s(.2,{spread:60}),s(.35,{spread:100,scalar:.8}),s(.1,{spread:120,startVelocity:25,scalar:1.2}),s(.1,{spread:120,startVelocity:45})}function R(){return(R=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let M=e=>O.createElement("svg",R({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 43 43"},e),O.createElement("path",{fill:"black",d:"M21.2201 25.2373C21.1135 26.2585 19.7214 26.4752 19.3095 25.5348L10.0268 4.34402C9.66148 3.51003 10.51 2.66148 11.344 3.02681L32.5348 12.3095C33.4752 12.7214 33.2585 14.1135 32.2373 14.2201L22.2611 15.2611L21.2201 25.2373Z",style:{fill:"black",fillOpacity:1}}),i||(i=O.createElement("path",{stroke:"url(#Cursor_svg__a)",strokeWidth:2,d:"M18.3935 25.936C19.2174 27.8169 22.0016 27.3834 22.2147 25.3411L23.1715 16.1715L32.3411 15.2147C34.3834 15.0016 34.8169 12.2174 32.936 11.3935L11.7453 2.11083C10.0773 1.38018 8.38017 3.07729 9.11083 4.74526L18.3935 25.936Z"})),O.createElement("defs",null,O.createElement("linearGradient",{id:"Cursor_svg__a",x1:15.894,x2:16.138,y1:29,y2:2.84,gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#A888AB",style:{stopColor:"#A888AB",stopColor:"color(display-p3 0.6588 0.5333 0.6706)",stopOpacity:1}}),O.createElement("stop",{offset:.141,stopColor:"#DFA35D",style:{stopColor:"#DFA35D",stopColor:"color(display-p3 0.8745 0.6392 0.3647)",stopOpacity:1}}),O.createElement("stop",{offset:.366,stopColor:"#6295AF",style:{stopColor:"#6295AF",stopColor:"color(display-p3 0.3843 0.5843 0.6863)",stopOpacity:1}}),O.createElement("stop",{offset:.576,stopColor:"#DEC073",style:{stopColor:"#DEC073",stopColor:"color(display-p3 0.8706 0.7529 0.4510)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#539590",style:{stopColor:"#539590",stopColor:"color(display-p3 0.3255 0.5843 0.5647)",stopOpacity:1}}))));var S=r(2564);let D={src:"/_next/static/media/CustomizedUI.1a6952d9.png",height:1480,width:2584,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAABlBMVEUaHCMXGB8Gx8I4AAAAAXRSTlP+GuMHfQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAA9JREFUeJxjYIQABgYiGAADUgAkJwCUCgAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:5},P={src:"/_next/static/media/CustomizedUIFill.95061eef.png",height:1370,width:2080,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAGFBMVEUqKzMXGB8gIio4OUCMmqZEWGFocnxfe4t6mXe4AAAACXBIWXMAABYlAAAWJQFJUiTwAAAAJUlEQVR4nE3GuREAIAwEsb0H6L9jxpkVCee1vQdhDQQY7wQc9AEHnwBCpWo02AAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:5};var $=r(5963),U=r(4977);function W(){return(W=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function z(e){let t,r,i,o;let l=(0,g.c)(7),{ref:s,className:n}=e,a=(0,U.A)(s);return l[0]===Symbol.for("react.memo_cache_sentinel")?(t=[],l[0]=t):t=l[0],l[1]!==a?(r={recreateOnResize:!0,scope:a},l[1]=a,l[2]=r):r=l[2],(0,w.s)(Q,t,r),l[3]===Symbol.for("react.memo_cache_sentinel")?(i=(0,A.jsx)(V,{}),l[3]=i):i=l[3],l[4]!==n||l[5]!==a?(o=(0,A.jsx)(T,{className:n,ref:a,children:i}),l[4]=n,l[5]=a,l[6]=o):o=l[6],o}function Q(){f.Ay.timeline({repeat:-1}).fromTo(".gradient-path",{drawSVG:0},{duration:1.5,drawSVG:"100% 0%",ease:"power2.inOut"},0).to(".gradient-path",{duration:1.5,drawSVG:"100% 100%",ease:"power2.inOut"},">")}f.Ay.registerPlugin($.E);let T=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		filter: blur(78px);
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -25%);
		z-index: 0;
		will-change: filter;
		pointer-events: none;
		opacity: 0;
	`),...(0,v.ZQ)((0,v.AH)`
		transform: translate(-50%, -30%);
	`)}),V=(0,v.I4)(e=>O.createElement("svg",W({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 2391 1500"},e),o||(o=O.createElement("path",{stroke:"url(#Gradient_svg__a)",strokeWidth:200,d:"M171 323.996C227.282 305.664 368.347 272.398 482.348 285.998C624.85 302.997 847.584 383.995 948.174 411.994C1048.76 439.993 1165.17 563.741 1418.79 539.99C1546.92 527.99 1924.13 475.992 2178 210",className:"gradient-path"})),O.createElement("defs",null,O.createElement("linearGradient",{id:"Gradient_svg__a",x1:171,x2:2109.55,y1:295.021,y2:404.299,gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#A888AB",style:{stopColor:"#A888AB",stopColor:"color(display-p3 0.6588 0.5333 0.6706)",stopOpacity:1}}),O.createElement("stop",{offset:.141,stopColor:"#DFA35D",style:{stopColor:"#DFA35D",stopColor:"color(display-p3 0.8745 0.6392 0.3647)",stopOpacity:1}}),O.createElement("stop",{offset:.366,stopColor:"#6295AF",style:{stopColor:"#6295AF",stopColor:"color(display-p3 0.3843 0.5843 0.6863)",stopOpacity:1}}),O.createElement("stop",{offset:.576,stopColor:"#DEC073",style:{stopColor:"#DEC073",stopColor:"color(display-p3 0.8706 0.7529 0.4510)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#539590",style:{stopColor:"#539590",stopColor:"color(display-p3 0.3255 0.5843 0.5647)",stopOpacity:1}})))),{...(0,v.vi)((0,v.AH)`
		width: 135vw;
		height: auto;
		opacity: 0.3;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 350vw;
	`)});function Z(){return(Z=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let G=e=>O.createElement("svg",Z({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 74 74"},e),l||(l=O.createElement("g",{filter:"url(#blurb_svg__a)"},O.createElement("rect",{width:74,height:74,y:-1,fill:"url(#blurb_svg__b)",rx:37}))),s||(s=O.createElement("rect",{width:74,height:74,fill:"url(#blurb_svg__c)",rx:37})),O.createElement("rect",{width:74,height:74,fill:"white",fillOpacity:.4,rx:37,style:{fill:"white",fillOpacity:.4}}),O.createElement("path",{fill:"white",fillOpacity:.3,d:"M9 28C9 12.536 21.536 0 37 0V0C52.464 0 65 12.536 65 28V46C65 61.464 52.464 74 37 74V74C21.536 74 9 61.464 9 46V28Z",style:{fill:"white",fillOpacity:.3}}),O.createElement("path",{fill:"white",fillOpacity:.3,d:"M22 15C22 6.71573 28.7157 0 37 0V0C45.2843 0 52 6.71573 52 15V59C52 67.2843 45.2843 74 37 74V74C28.7157 74 22 67.2843 22 59V15Z",style:{fill:"white",fillOpacity:.3}}),O.createElement("path",{fill:"white",fillOpacity:.3,d:"M34 3C34 1.34314 35.3431 0 37 0V0C38.6569 0 40 1.34315 40 3V71C40 72.6569 38.6569 74 37 74V74C35.3431 74 34 72.6569 34 71V3Z",style:{fill:"white",fillOpacity:.3}}),O.createElement("defs",null,O.createElement("radialGradient",{id:"blurb_svg__b",cx:0,cy:0,r:1,gradientTransform:"translate(-1.77508e-06 15) rotate(30.6403) scale(82.9109 63.8872)",gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#CC1ADD",style:{stopColor:"#CC1ADD",stopColor:"color(display-p3 0.8004 0.1003 0.8661)",stopOpacity:1}}),O.createElement("stop",{offset:.605,stopColor:"#188BD2",style:{stopColor:"#188BD2",stopColor:"color(display-p3 0.0942 0.5445 0.8244)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#D91627",style:{stopColor:"#D91627",stopColor:"color(display-p3 0.8517 0.0874 0.1511)",stopOpacity:1}})),O.createElement("radialGradient",{id:"blurb_svg__c",cx:0,cy:0,r:1,gradientTransform:"translate(-1.77508e-06 16) rotate(30.6403) scale(82.9109 63.8872)",gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#CC1ADD",style:{stopColor:"#CC1ADD",stopColor:"color(display-p3 0.8004 0.1003 0.8661)",stopOpacity:1}}),O.createElement("stop",{offset:.605,stopColor:"#188BD2",style:{stopColor:"#188BD2",stopColor:"color(display-p3 0.0942 0.5445 0.8244)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#D91627",style:{stopColor:"#D91627",stopColor:"color(display-p3 0.8517 0.0874 0.1511)",stopOpacity:1}})),n||(n=O.createElement("filter",{id:"blurb_svg__a",width:114,height:114,x:-20,y:-21,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_656_4621",stdDeviation:10})))));function N(){let e,t,r,i,o,l,s,n;let a=(0,g.c)(11),c=(0,O.useRef)(null),p=(0,O.useRef)(null),d=(0,O.useRef)(null),u=(0,O.useRef)(null),h=(0,O.useRef)(null),y=(0,O.useRef)(null),x=(0,O.useRef)(null),{tablet:k}=(0,O.useContext)(m.cH);return a[0]!==k?(e=()=>{f.Ay.from(h.current,{x:200,autoAlpha:0,ease:"power2.inOut",scrollTrigger:{trigger:h.current,start:"top bottom",end:"top 65%",scrub:!0}});let e=f.Ay.timeline({scrollTrigger:{trigger:c.current,start:"top bottom",end:"top 75%",toggleActions:"none play none reset"},defaults:{ease:"power2.in"}});e.timeScale(2);let t=y.current?.textContent??"";e.fromTo(y.current,{text:{value:""}},{text:{value:t},ease:"power4.inOut",duration:2}),e.to(p.current,{autoAlpha:0,duration:1.5,ease:"power2.inOut"},"+=1"),k||e.to(x.current,{opacity:1,duration:1.5,ease:"power2.inOut"},"<"),e.to(d.current,{opacity:1,rotateX:0,scale:1,duration:2,ease:"power2.inOut"},"<"),e.to(u.current,{opacity:1,ease:"power2.inOut",duration:1.5},"+=0.2"),k||e.to(x.current,{autoAlpha:0,duration:1.5,ease:"power2.inOut"},"+=1.5")},t=[k],a[0]=k,a[1]=e,a[2]=t):(e=a[1],t=a[2]),a[3]===Symbol.for("react.memo_cache_sentinel")?(r={recreateOnResize:!0,scope:c},a[3]=r):r=a[3],(0,w.s)(e,t,r),a[4]===Symbol.for("react.memo_cache_sentinel")?(i=(0,A.jsxs)(Y,{ref:h,children:[(0,A.jsx)("h5",{children:"Customized to work the way you do"}),(0,A.jsx)("p",{children:"Create custom apps, objects, properties and more to power any kind of experience you can imagine or use Micro AI to generate it from your description."})]}),a[4]=i):i=a[4],a[5]===Symbol.for("react.memo_cache_sentinel")?(o=(0,A.jsx)(X,{ref:p,children:(0,A.jsxs)(q,{children:[(0,A.jsx)(ee,{}),(0,A.jsx)("h4",{ref:y,children:"Help me organize our celebratory team offsite!"})]})}),a[5]=o):o=a[5],a[6]===Symbol.for("react.memo_cache_sentinel")?(l=(0,A.jsxs)(et,{children:[(0,A.jsx)(er,{ref:d,src:D,alt:""}),(0,A.jsx)(ei,{ref:u,src:P,alt:""})]}),a[6]=l):l=a[6],a[7]!==k?(s=!k&&(0,A.jsx)(eo,{ref:x}),a[7]=k,a[8]=s):s=a[8],a[9]!==s?(n=(0,A.jsx)(K,{ref:c,children:(0,A.jsxs)(J,{children:[i,o,l,s]})}),a[9]=s,a[10]=n):n=a[10],n}f.Ay.registerPlugin(S.J);let K=(0,v.I4)("section",{...(0,v.vi)((0,v.AH)`
		position: relative;
		display: grid;
		grid-template-columns: subgrid;
		grid-column: main;
		place-items: center;
	`)}),J=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		display: flex;
		flex-direction: column;
		position: relative;
		grid-column: main;
		margin: 320px 0 150px;
	`)}),Y=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: 692px;
		display: flex;
		flex-direction: column;
		grid-column: column-3-end / main;
		position: relative;
		gap: 36px;
		color: ${H.A.white1};

		h5 {
			${j.Ay.header1};
		}

		p {
			${j.Ay.body2};
			width: 505px;
		}
	`),...(0,v.ZQ)((0,v.AH)`
		width: 741px;
		grid-column: column-1-end / fullbleed;
		transform: translateX(144px);

		p {
			width: 400px;
		}
	`)}),X=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		background: linear-gradient(
			91deg,
			#ae86ad 0.24%,
			#eaa04e 13.8%,
			#5197b2 35.34%,
			#e4bf66 55.55%,
			#379790 96.24%
		);
		width: fit-content;
		border-radius: 104px;
		display: grid;
		place-items: center;
		margin-top: 51px;
		margin-bottom: -190px;
	`),...(0,v.ZQ)((0,v.AH)`
		scale: 0.8;
		margin: 90px auto 0;
	`)}),q=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		padding: 12px 40px 12px 12px;
		display: flex;
		gap: 24px;
		border-radius: 104px;
		background: ${H.A.black2};
		width: 99.5%;
		height: 97.5%;
		align-items: center;

		h4 {
			color: ${H.A.white1};
			${j.Ay.header4};
			width: 488px;
		}
	`)}),ee=(0,v.I4)(G,{...(0,v.vi)((0,v.AH)`
		width: 74px;
		height: 74px;
		overflow: visible;
	`)}),et=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		isolation: isolate;
		perspective: 1000px;
		margin-top: 88px;
		z-index: 1;
		transform-origin: top center;
	`),...(0,v.ZQ)((0,v.AH)`
		margin-top: 96px;
		transform: translateX(144px);
	`)}),er=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		width: 1292px;
		height: auto;
		position: relative;
		z-index: 1;
		transform: rotate3d(1, 0, 0, -90deg);
		opacity: 0;
		scale: 0.5;
		will-change: transform;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 1034px;
	`)}),ei=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		width: 1042px;
		height: auto;
		position: absolute;
		right: 15px;
		bottom: 13px;
		z-index: 2;
		opacity: 0;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 774px;
		right: 11px;
		bottom: 10px;
	`)}),eo=(0,v.I4)(z,{...(0,v.vi)((0,v.AH)`
		transform: translate(-50%, -20%);
	`)}),el={src:"/_next/static/media/Document.cbb17649.png",height:602,width:638,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEUTFBciIyUXGBnoViFsAAAAA3RSTlP+/u0RqMjyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAHUlEQVR4nGNgZGRkZEABIBFUIbAISAjCQJZkggIABAkAJ8oOR2AAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8},es={src:"/_next/static/media/Email.a5c31486.png",height:602,width:637,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEUWFhkXFhwQHiAhJCclIB8SERUeHiEVKStYxcldAAAABXRSTlP+4v779lXVULsAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAsSURBVHicNcpBDgAgDALBlQr9/4+Njc5pQ2Cnis+2IdeP2XuIdEsSZK6G9RwebwDUlpxozAAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:8},en={src:"/_next/static/media/CustomizedUIMobile.1b39f1b4.png",height:684,width:1120,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAFVBMVEUlJi0XGR8vMDgxNDyEkp1XZW1MY2+iZxb0AAAACXBIWXMAABYlAAAWJQFJUiTwAAAAJklEQVR4nB3IwQ0AIAzDQLsJ7D8yKvLrjHLbHpQkA8jgJvl0D+EBBoAAOfMx1sAAAAAASUVORK5CYII=",blurWidth:8,blurHeight:5},ea={src:"/_next/static/media/MountainsMobile.e5f3a612.png",height:862,width:1597,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAALVBMVEUMDRBMaXEKDBA7OjKFm4qinoAdGhn/+s4zLytDPjf////w4rE3My5uaVpgYFG2ZlGJAAAAD3RSTlPvAPesF03rGuPLBSS7mHqyghCLAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAJklEQVR4nBXBhw0AIAzAsNDN/P/cCps1PjOeZ26/StTRWQEgIkADC8kAkz9wLi0AAAAASUVORK5CYII=",blurWidth:8,blurHeight:4},ec={src:"/_next/static/media/SevenCardsMobile.414c5514.png",height:774,width:684,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAALVBMVEUPJSckJCgeICKLVUhWTmkcKSwnJiYUFxsbHiEPDRAyKyGURTlRT3FaXXodLDDZRiTsAAAAB3RSTlP+8P38/Pj7QndFowAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAADNJREFUeJwlxUEOwCAQA7EQkCa7lP7/uRWqL9Z6ztx7qrudvAKoQtjOPYljoR8JVDQujw8wdwFCbdvNcwAAAABJRU5ErkJggg==",blurWidth:7,blurHeight:8},ep={src:"/_next/static/media/TwoCardsMobile.a564d455.png",height:678,width:684,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAASFBMVEUYGRobHyIQDhAmJikUHiAUFRgQERMPGh0YHB4UFRcCBQVYXFovEisRPlwVVIdEQ0efiptaFE2KEHPQLLJEIkF4HGQMJC4KME60fOuhAAAACnRSTlPx////9P/+/evxme5KawAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAD9JREFUeJwVyEcOwDAMAzDZhpSdpvv/Py3KIyG/uisl1P286zsH2jp6HfPB1iinEswiKBrMSP5DuYI0ZKAAJX9VeQHqFfHIbQAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:8},ed={src:"/_next/static/media/cardGridMobile.45c50a31.png",height:941,width:1022,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAMFBMVEUXFhkJCw4QERQOFh8PEBIvJC0TEBcLDA0fHR4gHCYAAAAAAAAAAAAAAAAPEBROPz2kkoglAAAADnRSTlP9GvQkKfywxMTvAgwLAbGrCtwAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAA0SURBVHicJcZJEsAgEAOx9rAmAfP/31IQnYTCNk8iYXDkE/sm4E/BZUVGtbXeq3g/SRpzAyqcAVX2a785AAAAAElFTkSuQmCC",blurWidth:8,blurHeight:7};function eu(){return(eu=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let eh=e=>O.createElement("svg",eu({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 372 576"},e),O.createElement("g",{filter:"url(#coloredOrb_svg__a)"},O.createElement("path",{fill:"#DEAA6C",fillOpacity:.13,d:"M377 344.5C377 467.383 291.039 567 185 567C78.9613 567 -7 467.383 -7 344.5C-7 221.617 78.9613 122 185 122C291.039 122 377 221.617 377 344.5Z",style:{fill:"#DEAA6C",fill:"color(display-p3 0.8706 0.6667 0.4235)",fillOpacity:.13}})),O.createElement("mask",{id:"coloredOrb_svg__c",width:372,height:372,x:0,y:0,maskUnits:"userSpaceOnUse",style:{maskType:"alpha"}},a||(a=O.createElement("circle",{cx:185.882,cy:185.882,r:185.882,fill:"url(#coloredOrb_svg__b)"}))),O.createElement("g",{mask:"url(#coloredOrb_svg__c)"},O.createElement("g",{filter:"url(#coloredOrb_svg__d)"},O.createElement("circle",{cx:132.656,cy:136.877,r:81.957,fill:"white",fillOpacity:.9,style:{fill:"white",fillOpacity:.9}})),O.createElement("g",{filter:"url(#coloredOrb_svg__e)"},O.createElement("path",{fill:"#F0D8BA",fillRule:"evenodd",d:"M138.364 372.609C241.024 372.609 324.246 289.387 324.246 186.727C324.246 139.021 306.275 95.512 276.732 62.6016C325.814 96.0612 358.039 152.417 358.039 216.299C358.039 318.959 274.817 402.182 172.157 402.182C117.203 402.182 67.8196 378.335 33.7891 340.425C63.5824 360.735 99.5866 372.609 138.364 372.609Z",clipRule:"evenodd",style:{fill:"#F0D8BA",fill:"color(display-p3 0.9400 0.8462 0.7311)",fillOpacity:1}}))),O.createElement("defs",null,c||(c=O.createElement("filter",{id:"coloredOrb_svg__a",width:580.021,height:641.021,x:-105.011,y:23.989,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_430_3285",stdDeviation:49.005}))),p||(p=O.createElement("filter",{id:"coloredOrb_svg__d",width:292.342,height:292.342,x:-13.515,y:-9.294,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_430_3285",stdDeviation:32.107}))),d||(d=O.createElement("filter",{id:"coloredOrb_svg__e",width:452.678,height:468.008,x:-30.425,y:-1.612,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_430_3285",stdDeviation:32.107}))),O.createElement("linearGradient",{id:"coloredOrb_svg__b",x1:144.034,x2:427.17,y1:109.477,y2:341.555,gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#D91E1E",style:{stopColor:"#D91E1E",stopColor:"color(display-p3 0.8513 0.1188 0.1188)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#C4C4C4",style:{stopColor:"#C4C4C4",stopColor:"color(display-p3 0.7675 0.7675 0.7675)",stopOpacity:1}}))));function ey(){return(ey=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function eA(){return(eA=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let eg=e=>O.createElement("svg",eA({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 29 36"},e),O.createElement("path",{stroke:"#777777",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2.158,d:"M27.1761 14.9479C27.1761 23.029 18.4605 31.4451 15.5337 34.0444C15.2611 34.2553 14.9292 34.3693 14.5881 34.3693C14.2469 34.3693 13.915 34.2553 13.6424 34.0444C10.7157 31.4451 2 23.029 2 14.9479C2 11.5139 3.32624 8.22055 5.68696 5.79235C8.04768 3.36415 11.2495 2 14.5881 2C17.9266 2 21.1285 3.36415 23.4892 5.79235C25.8499 8.22055 27.1761 11.5139 27.1761 14.9479Z",className:"pin-path",style:{stroke:"#777777",stroke:"color(display-p3 0.4651 0.4651 0.4651)",strokeOpacity:1}}),O.createElement("path",{stroke:"#777777",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2.158,d:"M14.5929 20.497C17.753 20.497 20.3148 17.9091 20.3148 14.7168C20.3148 11.5244 17.753 8.93652 14.5929 8.93652C11.4329 8.93652 8.87109 11.5244 8.87109 14.7168C8.87109 17.9091 11.4329 20.497 14.5929 20.497Z",className:"pin-path",style:{stroke:"#777777",stroke:"color(display-p3 0.4651 0.4651 0.4651)",strokeOpacity:1}}));function ef(){let e,t,r,i,o,l,s,n,a,c,p,d,u,h,y,m,k,v,C,H,j,_,I,B,R,M,S,D;let P=(0,g.c)(29),$=(0,O.useRef)(null),U=(0,O.useRef)(null),W=(0,O.useRef)(null),z=(0,O.useRef)(null),Q=(0,O.useRef)(null),T=(0,O.useRef)(null),V=(0,O.useRef)(null),Z=(0,O.useRef)(null),G=(0,O.useRef)(null),N=(0,O.useRef)(null),K=(0,O.useRef)(null),J=(0,O.useRef)(null),Y=(0,O.useRef)(null),X=(0,O.useRef)(null),q=(0,O.useRef)(null),ee=(0,O.useRef)(null),et=(0,O.useRef)(null),er=(0,O.useRef)(null),ei=(0,O.useRef)(null),eo=(0,x.l5)();return P[0]===Symbol.for("react.memo_cache_sentinel")?(e=()=>{let e=f.Ay.timeline({repeat:-1,repeatDelay:3,defaults:{duration:2}});return e.to(J.current,{scale:1,ease:"elastic.out(0.9, 0.3)"},0).to(J.current,{y:(0,E.qM)(-10),x:(0,E.qM)(225),ease:"power2.inOut",duration:1.7},"<+=0.1").to(Y.current,{scale:1,ease:"elastic.out(0.9, 0.3)"},.5).to(Y.current,{y:(0,E.qM)(-150),x:(0,E.qM)(-237),ease:"power2.inOut",duration:1.7},"<+=0.1").to(ee.current,{duration:.5,ease:"power1.inOut",y:"-48%"},2).to(et.current,{duration:.5,ease:"power1.inOut",width:"22%",transformOrigin:"left"},2).to(X.current,{scale:1,ease:"elastic.out(0.9, 0.4)"},1).to(q.current,{scale:1,ease:"elastic.out(0.9, 0.4)",onStart:()=>{f.Ay.to(ei.current,{repeat:1,yoyo:!0,duration:.3,scale:.8,ease:"power3.inOut",onComplete:()=>{let e=Y.current;if(!e)return;let t=e.getBoundingClientRect();F(t.left+t.width/2,t.top+t.height/2)}})}},1.8).to([J.current,Y.current],{scale:0,duration:1,ease:"elastic.in(0.5, 0.5)",stagger:.3},">+=1").to(ee.current,{duration:.5,ease:"power1.inOut",y:"2%"},5.8).to(et.current,{duration:.5,ease:"power1.inOut",width:(0,E.qM)(135),transformOrigin:"left"},5.8),e},t=[],r={recreateOnResize:!0},P[0]=e,P[1]=t,P[2]=r):(e=P[0],t=P[1],r=P[2]),(0,w.s)(e,t,r),P[3]===Symbol.for("react.memo_cache_sentinel")?(i=()=>{f.Ay.timeline({scrollTrigger:{trigger:G.current,endTrigger:N.current,start:"top 40%",end:"bottom 90%",scrub:!0},defaults:{ease:"none"},duration:1}).to(Z.current,{duration:.6,ease:"power2.inOut",y:"-110%"},.2).to(K.current,{opacity:1,ease:"power2.inOut",duration:.8},.2)},o=[],P[3]=i,P[4]=o):(i=P[3],o=P[4]),(0,w.s)(i,o),P[5]!==eo?(l=()=>{let e=(0,b.A)({trigger:T.current,pinType:eo,pin:T.current,smoothType:"both",start:"top top",end:"bottom bottom"});f.Ay.timeline({scrollTrigger:{start:()=>e.start,end:()=>e.end,scrub:!0},defaults:{ease:"power2.inOut"}}).to(Q.current,{yPercent:-300,duration:1.75,ease:"power2.in"},0).to(z.current,{yPercent:-150,duration:2,ease:"power2.in"},0).to(V.current,{rotateX:0,duration:2,yPercent:25},0).to(W.current,{yPercent:-200,duration:4,ease:"power2.in"},.25)},s=[eo],P[5]=eo,P[6]=l,P[7]=s):(l=P[6],s=P[7]),P[8]===Symbol.for("react.memo_cache_sentinel")?(n={recreateOnResize:!0,scope:$},P[8]=n):n=P[8],(0,w.s)(l,s,n),P[9]===Symbol.for("react.memo_cache_sentinel")?(a=(0,A.jsxs)(ev,{ref:z,children:[(0,A.jsxs)(ew,{children:[(0,A.jsx)("div",{children:"AI-Powered"}),(0,A.jsx)("div",{children:"All-In-One Tool"}),(0,A.jsx)("div",{children:"Automatically"}),(0,A.jsx)("div",{children:"Organizes Itself"})]}),(0,A.jsx)(eC,{children:"Micro works the way you want to work"})]}),P[9]=a):a=P[9],P[10]===Symbol.for("react.memo_cache_sentinel")?(p=(0,A.jsx)(eE,{ref:Q,children:(0,A.jsx)(eO,{})}),c=(0,A.jsx)(eb,{ref:W,src:ea,alt:""}),P[10]=c,P[11]=p):(c=P[10],p=P[11]),P[12]===Symbol.for("react.memo_cache_sentinel")?(d=(0,A.jsxs)(ex,{ref:T,children:[a,p,c,(0,A.jsx)(eH,{children:(0,A.jsx)(ej,{ref:V,children:(0,A.jsx)(eL,{src:ed,alt:""})})})]}),P[12]=d):d=P[12],P[13]===Symbol.for("react.memo_cache_sentinel")?(u=(0,A.jsxs)(eR,{children:[(0,A.jsx)("h5",{children:"Everything in one place"}),(0,A.jsx)("p",{children:"Fully-featured email client, CRM, task manager and more integrated with Gmail, Calendar, Linkedin, WhatsApp and other tools. Plus the ability to create pipeline trackers, project management tools and more on top of this data."})]}),P[13]=u):u=P[13],P[14]===Symbol.for("react.memo_cache_sentinel")?(h=(0,A.jsx)(e_,{src:ec,alt:""}),P[14]=h):h=P[14],P[15]===Symbol.for("react.memo_cache_sentinel")?(y=(0,A.jsx)(eV,{ref:K}),m=(0,A.jsx)(eI,{src:ep,alt:""}),P[15]=y,P[16]=m):(y=P[15],m=P[16]),P[17]===Symbol.for("react.memo_cache_sentinel")?(k=(0,A.jsx)(e2,{}),P[17]=k):k=P[17],P[18]===Symbol.for("react.memo_cache_sentinel")?(v=(0,A.jsxs)(eX,{ref:N,children:[h,(0,A.jsxs)(eY,{ref:G,children:[y,m,(0,A.jsxs)(eq,{children:[k,(0,A.jsxs)(e0,{ref:Z,children:[(0,A.jsx)(e1,{children:"Salt Lake City"}),(0,A.jsx)(e1,{children:"Santa Cruz, CA"})]})]})]})]}),P[18]=v):v=P[18],P[19]===Symbol.for("react.memo_cache_sentinel")?(C=(0,A.jsxs)(eR,{children:[(0,A.jsx)("h5",{children:"Automatically Updated"}),(0,A.jsx)("p",{children:"Everything - companies, people, and more - is enriched with hundreds of datapoints from a rich global and personal knowledge graph. Plus any property can be updated automatically when there's new email or meeting activity."})]}),H={position:"relative"},P[19]=C,P[20]=H):(C=P[19],H=P[20]),P[21]===Symbol.for("react.memo_cache_sentinel")?(j=(0,A.jsxs)(e$,{ref:J,children:[(0,A.jsxs)("div",{children:[(0,A.jsx)(eM,{}),(0,A.jsx)(eU,{children:"Alec Douglas"})]}),(0,A.jsx)(eW,{ref:X,children:"killer meeting with Eric today! \uD83D\uDCAA"})]}),P[21]=j):j=P[21],P[22]===Symbol.for("react.memo_cache_sentinel")?(_=(0,A.jsxs)(ez,{ref:Y,children:[(0,A.jsx)(eM,{ref:ei}),(0,A.jsx)(eQ,{children:"Max Mason"}),(0,A.jsx)(eT,{ref:q,children:"Omg they signed! \uD83C\uDF89"})]}),I=(0,A.jsx)(eF,{ref:er,src:L,alt:""}),P[22]=_,P[23]=I):(_=P[22],I=P[23]),P[24]===Symbol.for("react.memo_cache_sentinel")?(B=(0,A.jsxs)("div",{style:H,children:[j,_,I,(0,A.jsx)(e5,{ref:et,children:(0,A.jsxs)(e3,{ref:ee,children:[(0,A.jsx)(e4,{className:"crm-ui-text",children:"Demo Meeting"}),(0,A.jsx)(e4,{className:"crm-ui-text",children:"Closed"})]})})]}),P[24]=B):B=P[24],P[25]===Symbol.for("react.memo_cache_sentinel")?(R=(0,A.jsxs)(eR,{children:[(0,A.jsx)("h5",{children:"Collaborative by default"}),(0,A.jsx)("p",{children:"Create custom apps, objects, properties and more to power any kind of experience you can imagine or use Micro AI to generate it from your description."})]}),P[25]=R):R=P[25],P[26]===Symbol.for("react.memo_cache_sentinel")?(M=(0,A.jsx)(eZ,{children:(0,A.jsxs)(eG,{children:[(0,A.jsx)(eN,{}),(0,A.jsx)("h4",{children:"Help me organize our celebratory team offsite!"})]})}),P[26]=M):M=P[26],P[27]===Symbol.for("react.memo_cache_sentinel")?(S=(0,A.jsxs)(eK,{children:[(0,A.jsx)(eV,{}),(0,A.jsx)(eJ,{src:en,alt:""})]}),P[27]=S):S=P[27],P[28]===Symbol.for("react.memo_cache_sentinel")?(D=(0,A.jsx)(A.Fragment,{children:(0,A.jsxs)(em,{ref:$,children:[d,(0,A.jsxs)(ek,{ref:U,children:[u,v,C,B,R,M,S,(0,A.jsxs)(eR,{children:[(0,A.jsx)("h5",{children:"Customized to work the way you do"}),(0,A.jsx)("p",{children:"Create custom apps, objects, properties and more to power any kind of experience you can imagine or use Micro AI to generate it from your description."})]})]})]})}),P[28]=D):D=P[28],D}let em=(0,v.I4)("section",{...(0,v.vi)((0,v.AH)`
		position: relative;
		display: grid;
		grid-column: fullbleed;
		grid-template-columns: subgrid;
		margin-top: 146px;
		padding-bottom: 150px;
	`)}),ex=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		grid-column: fullbleed;
		height: 150vh;
	`)}),ek=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		grid-column: column-1-start / fullbleed;
	`)}),eb=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		position: absolute;
		top: 254px;
		left: 0;
		z-index: 0;
	`)}),ev=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 36px;
		z-index: 4;
	`)}),ew=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		display: flex;
		justify-content: space-between;
		color: ${H.A.orange3};
		${j.Ay.kicker3};
		width: 355px;

		::before {
			display: none;
		}

		::after {
			display: none;
		}
	`)}),eC=(0,v.I4)("h1",{...(0,v.vi)((0,v.AH)`
		${j.Ay.header2};
		text-align: center;
		width: 335px;
	`)}),eE=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: 150px;
		height: 150px;
		z-index: 3;
		left: 50%;
		top: 170px;
		transform: translateX(-50%);
		backdrop-filter: blur(15px);
		will-change: filter;
		border-radius: 50%;
		background: linear-gradient(
			to bottom,
			color(display-p3 0.9067 0.69 0.4371 / 40%),
			color(display-p3 0.4745 0.3468 0.1979 / 40%)
		);
	`)}),eO=(0,v.I4)(eh,{...(0,v.vi)((0,v.AH)`
		overflow: visible;
	`)}),eH=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
		perspective: 900px;
		z-index: 1;
	`)}),ej=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		transform: rotate3d(1, 0, 0, 45deg);
		width: 389px;
		height: 368px;
	`)}),eL=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		width: 100%;
		height: 100%;
	`)}),e_=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		position: absolute;
		top: 0;
		width: 340px;
		height: 385px;
		margin-top: 35px;
		transform: translateX(-2px);
	`)}),eI=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		width: 100%;
		height: 100%;
		position: relative;
		z-index: 1;
		transform: translateX(-2px);
	`)}),eB=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		box-sizing: border-box;
		position: relative;
		z-index: 1;
		width: 340px;
		height: 321px;
	`)}),eF=(0,v.I4)(eB,{...(0,v.vi)((0,v.AH)`
		margin: 168px 0 93px;
		transform: translateX(-2px);
		object-fit: contain;
		width: 340px;
		height: auto;
		position: relative;
		z-index: 1;
	`)}),eR=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: 375px;
		display: flex;
		flex-direction: column;
		gap: 36px;
		color: ${H.A.white1};

		h5 {
			${j.Ay.header5};
			width: 339px;
		}

		p {
			${j.Ay.body2};
			width: 339px;
		}
	`)}),eM=(0,v.I4)(M,{...(0,v.vi)((0,v.AH)`
		width: 34px;
		height: 34px;
		scale: 1;
	`)}),eS=(0,v.AH)`
	display: flex;
	flex-direction: column;
	position: absolute;
	z-index: 3;
	scale: 0;
`,eD=(0,v.AH)`
	${j.Ay.body3};
	padding: 12px 20px;
	border-radius: 40px;
	width: fit-content;
`,eP=(0,v.AH)`
	${j.Ay.body4};
	padding: 22px 16px;
	width: fit-content;
	margin-right: 7px;
	scale: 0;
`,e$=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		${eS};
		align-items: flex-end;
		top: 261px;
		left: -117px;
	`)}),eU=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${eD};
		color: ${H.A.white1};
		background-color: ${H.A.blue1};
		margin: -7px 0 14px;
	`)}),eW=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${eP};
		color: ${H.A.white1};
		background-color: ${H.A.blue1};
		border-radius: 16px 0 16px 16px;
	`)}),ez=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		${eS};
		top: 241px;
		right: -120px;
	`)}),eQ=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${eD};
		color: ${H.A.black1};
		background-color: ${H.A.green4};
		margin: -7px 0 9px;
	`)}),eT=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${eP};
		color: ${H.A.black1};
		background-color: ${H.A.green4};
		border-radius: 0 16px 16px;
	`)}),eV=(0,v.I4)(e=>O.createElement("svg",ey({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 680 467"},e),u||(u=O.createElement("g",{filter:"url(#gradientMobile_svg__a)",opacity:.3},O.createElement("path",{stroke:"url(#gradientMobile_svg__b)",strokeWidth:100,d:"M108 174.033C120.703 159.554 152.543 133.281 178.274 144.022C210.439 157.448 260.712 221.419 283.416 243.533C306.12 265.646 332.395 363.381 389.638 344.623C418.559 335.146 503.699 294.078 561 84"}))),O.createElement("defs",null,O.createElement("linearGradient",{id:"gradientMobile_svg__b",x1:108,x2:546.827,y1:151.149,y2:158.218,gradientUnits:"userSpaceOnUse"},O.createElement("stop",{stopColor:"#A888AB",style:{stopColor:"#A888AB",stopColor:"color(display-p3 0.6588 0.5333 0.6706)",stopOpacity:1}}),O.createElement("stop",{offset:.141,stopColor:"#DFA35D",style:{stopColor:"#DFA35D",stopColor:"color(display-p3 0.8745 0.6392 0.3647)",stopOpacity:1}}),O.createElement("stop",{offset:.366,stopColor:"#6295AF",style:{stopColor:"#6295AF",stopColor:"color(display-p3 0.3843 0.5843 0.6863)",stopOpacity:1}}),O.createElement("stop",{offset:.576,stopColor:"#DEC073",style:{stopColor:"#DEC073",stopColor:"color(display-p3 0.8706 0.7529 0.4510)",stopOpacity:1}}),O.createElement("stop",{offset:1,stopColor:"#539590",style:{stopColor:"#539590",stopColor:"color(display-p3 0.3255 0.5843 0.5647)",stopOpacity:1}})),h||(h=O.createElement("filter",{id:"gradientMobile_svg__a",width:678.822,height:466.168,x:.416,y:.842,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_762_6355",stdDeviation:35}))))),{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: 200vw;
		height: auto;
		top: -125px;
		left: -200px;
		z-index: 0;
		opacity: 0;
	`)}),eZ=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		background: linear-gradient(
			91deg,
			#ae86ad 0.24%,
			#eaa04e 13.8%,
			#5197b2 35.34%,
			#e4bf66 55.55%,
			#379790 96.24%
		);
		width: fit-content;
		border-radius: 55px;
		display: grid;
		place-items: center;
		margin-top: 180px;
	`)}),eG=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		padding: 6px 20px 6px 6px;
		display: flex;
		gap: 12px;
		border-radius: 55px;
		background: ${H.A.black2};
		width: 99.5%;
		height: 97.5%;
		align-items: center;

		h4 {
			color: ${H.A.white1};
			${j.Ay.body4};
			width: 256px;
		}
	`)}),eN=(0,v.I4)(G,{...(0,v.vi)((0,v.AH)`
		width: 39px;
		height: 39px;
		overflow: visible;
	`)}),eK=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		margin: 27px 0 41px;
		width: 560px;
		height: 342px;
	`)}),eJ=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		width: 560px;
		height: 342px;
		position: absolute;
		z-index: 1;
	`)}),eY=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: sticky;
		top: 116px;
		width: 340px;
		height: 336.8px;
		display: flex;
		justify-content: center;
		align-items: center;
	`)}),eX=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		padding: 80px 0 54px;
		height: 1000px;
	`)}),eq=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		z-index: 2;
		overflow: clip;
		position: absolute;
		bottom: 55px;
		left: 16px;
		height: 17px;
		display: flex;
		gap: 7.2px;
		align-items: center;
	`)}),e0=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		height: 17px;
	`)}),e1=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #777;
		font-size: 15px;
		font-style: normal;
		font-weight: 500;

		&:last-of-type {
			color: #ad3186;
		}
	`)}),e2=(0,v.I4)(eg,{...(0,v.vi)((0,v.AH)`
		width: 14px;
		height: 17px;
	`)}),e5=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		overflow: clip;
		position: absolute;
		top: 72px;
		left: 56px;
		height: 28px;
		border-radius: 5.795px;
		border: 1.264px solid #00cfc4;
		width: 135px;
		z-index: 2;
	`)}),e3=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: fit-content;
		white-space: pre;
		transform: translateY(1px);
	`)}),e4=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #00cfc4;
		font-size: 17.386px;
		font-style: normal;
		font-weight: 500;
		line-height: 22.751px; /* 130.855% */
		margin: 0 10px;
	`)}),e6={src:"/_next/static/media/Mountains.0db84093.png",height:1750,width:3200,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAALVBMVEUKCw/V//8NDhLTxpoTExMvLikuKyiQiHAiIB4PDxDX/+tSUERxfHGHlodjXU4taTdzAAAAD3RSTlPgAdws9sfjaPPyDZQvIqzvbZaDAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAJ0lEQVR4nBXBiREAIAgEsfUAwbf/ch0TZvvOZqWZ5Q28evTygQQgPQxNAJi904IAAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:4},e8={src:"/_next/static/media/Person.5a0bb024.png",height:601,width:637,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAANlBMVEUdICETFBcOERMaGh2IJA9VSosWFxomJCbALA4GI7HNLAiAGwkvH0gHLsoFIpcwOmICF3aSGiIVEWKqAAAACnRSTlP9/////v7//f7+AJ880wAAAAlwSFlzAAALEwAACxMBAJqcGAAAADpJREFUeJwFwYkBgEAIBLEBdIH71P6bNaF736OqOL37GzVYz3vWnBeZcnc3gAhTECGTSUjmaWZkQgI/RUcBexh9mZ8AAAAASUVORK5CYII=",blurWidth:8,blurHeight:8},e7={src:"/_next/static/media/Task.5769925c.png",height:602,width:638,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAADFBMVEUQERQlJyoXGBkbHR8pkfGPAAAAA3RSTlP+/u0RqMjyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAJklEQVR4nD2IQQ4AIAyDwP7/z2aukQMlJQ4AamZZQ5bWv17YOOUCC0IAWbcRAZkAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8};function e9(){return(e9=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let te=e=>O.createElement("svg",e9({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 910 932"},e),O.createElement("g",{filter:"url(#cardGrid_svg__a)"},O.createElement("path",{fill:"black",fillOpacity:.6,d:"M861 162H50C45.5817 162 42 165.582 42 170V924C42 928.418 45.5817 932 50 932H861C865.418 932 869 928.418 869 924V170C869 165.582 865.418 162 861 162Z",style:{fill:"black",fillOpacity:.6}})),O.createElement("rect",{width:911,height:861,x:-.5,y:-.5,fill:"#0F1013",rx:10.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:911,height:861,x:-.5,y:-.5,stroke:"#282C33",rx:10.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:5.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:5.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:5.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:5.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:5.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:5.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:5.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:5.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:5.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:5.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:176.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:176.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:176.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:176.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:176.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:176.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:176.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:176.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:176.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:176.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:347.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:347.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:347.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:347.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:347.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:347.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:347.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:347.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:347.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:347.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:518.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:518.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:518.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:518.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:518.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:518.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:518.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:518.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:518.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:518.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:689.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:5.5,y:689.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:689.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:186.5,y:689.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:689.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:367.5,y:689.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:689.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:548.5,y:689.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:689.5,fill:"#0F1013",rx:5.5,style:{fill:"#0F1013",fill:"color(display-p3 0.0588 0.0627 0.0745)",fillOpacity:1}}),O.createElement("rect",{width:175,height:165,x:729.5,y:689.5,stroke:"#282C33",rx:5.5,style:{stroke:"#282C33",stroke:"color(display-p3 0.1562 0.1710 0.2005)",strokeOpacity:1}}),y||(y=O.createElement("defs",null,O.createElement("filter",{id:"cardGrid_svg__a",width:1187,height:1130,x:-138,y:-18,colorInterpolationFilters:"sRGB",filterUnits:"userSpaceOnUse"},O.createElement("feFlood",{floodOpacity:0,result:"BackgroundImageFix"}),O.createElement("feBlend",{in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),O.createElement("feGaussianBlur",{result:"effect1_foregroundBlur_453_11101",stdDeviation:90})))));function tt(){let e,t,r,i,o,l,s;let n=(0,g.c)(18),a=(0,O.useRef)(null),c=(0,O.useRef)(null),p=(0,O.useRef)(null),d=(0,O.useRef)(null),u=(0,O.useRef)(null),h=(0,O.useRef)(null),y=(0,O.useRef)(null),k=(0,O.useRef)(null),v=(0,O.useRef)(null),H=(0,O.useRef)(null),j=(0,O.useRef)(null),B=(0,O.useRef)(null),R=(0,O.useRef)(null),M=(0,O.useRef)(null),S=(0,O.useRef)(null),D=(0,O.useRef)(null),P=(0,O.useRef)(null),$=(0,O.useRef)(null),U=(0,O.useRef)(null),W=(0,O.useRef)(null),Q=(0,O.useRef)(null),T=(0,O.useRef)(null),V=(0,O.useRef)(null),Z=(0,O.useRef)(null),G=(0,O.useRef)(null),K=(0,O.useRef)(null),J=(0,O.useRef)(null),Y=(0,C.Q)("24%","24%","22%","20%"),X=(0,C.Q)(266,266,186,186),q=(0,C.Q)(-24,-24,-14,-10),ee=(0,C.Q)(-60,-60,-55,-30),et=(0,x.l5)(),{mobile:er,tablet:ei}=(0,O.useContext)(m.cH);n[0]!==Y||n[1]!==X||n[2]!==er||n[3]!==ei?(e=()=>{if(er)return;let e=f.Ay.timeline({repeat:-1,repeatDelay:3,defaults:{duration:2}});return e.to(U.current,{scale:1,ease:"elastic.out(0.9, 0.3)"},0).to(U.current,{y:(0,E.qM)(ei?244:180),x:(0,E.qM)(18),ease:"power2.inOut",duration:1.7},"<+=0.1").to(W.current,{scale:1,ease:"elastic.out(0.9, 0.3)"},.5).to(W.current,{y:(0,E.qM)(ei?-196:-80),x:(0,E.qM)(ei?-425:-507),ease:"power2.inOut",duration:1.7},"<+=0.1").to(K.current,{duration:.5,ease:"power1.inOut",y:"-48%"},2).to(J.current,{duration:.5,ease:"power1.inOut",width:Y,transformOrigin:"left"},2).to(Q.current,{scale:1,ease:"elastic.out(0.9, 0.4)"},1).to(T.current,{scale:1,ease:"elastic.out(0.9, 0.4)",onStart:()=>{let e=W.current;if(!e)return;let t=e.getBoundingClientRect();F(t.left+t.width/2,t.top+t.height/2)}},1.8).to([U.current,W.current],{scale:0,duration:1,ease:"elastic.in(0.5, 0.5)",stagger:.3},">+=1").to(K.current,{duration:.5,ease:"power1.inOut",y:"2%"},5.8).to(J.current,{duration:.5,ease:"power1.inOut",width:(0,E.qM)(X),transformOrigin:"left"},5.8),e},t=[er,ei,Y,X],n[0]=Y,n[1]=X,n[2]=er,n[3]=ei,n[4]=e,n[5]=t):(e=n[4],t=n[5]),n[6]===Symbol.for("react.memo_cache_sentinel")?(r={recreateOnResize:!0},n[6]=r):r=n[6];let eo=(0,w.s)(e,t,r);return n[7]!==eo.result||n[8]!==q||n[9]!==ee||n[10]!==er||n[11]!==et||n[12]!==ei?(i=()=>{if(er)return;eo.result?.pause();let e=ei?147.38:179,t=ei?139.24:171,r=3*!ei,i=8*!ei,o=tr;f.Ay.set(".card.large",{scale:ei?.283:.278}),f.Ay.set(D.current,{y:(0,E.qM)(ei?48:138)}),f.Ay.set(P.current,{y:(0,E.qM)(ei?-15:112)}),f.Ay.set($.current,{y:(0,E.qM)(84*!ei)});let l={duration:.001,visibility:"hidden",pointerEvents:"none"},s=(0,b.A)({trigger:a.current,pinType:et,pin:y.current,smoothType:"both",start:"top top",end:"bottom bottom"});f.Ay.timeline({scrollTrigger:{start:()=>s.start,end:()=>s.end,scrub:!0},defaults:{ease:"power2.inOut"}}).to(d.current,{yPercent:ei?-350:-250,duration:ei?2:1.75,ease:"power2.in"},0).to(p.current,{yPercent:-120,duration:2,ease:"power2.in"},0).to(u.current,{top:"16.67%",yPercent:-46,duration:2.25},.25).to(h.current,{rotateX:0,duration:2.25},.25).to(c.current,{yPercent:ei?-150:-100,duration:6,ease:"power2.in"},.25).to(k.current,{autoAlpha:0,duration:1,ease:"power2.in"},3).add(o(B,-(2*e+r),-t),"<").add(o(v,-(e+3*r+(ei?10:2)),-(2*t)),"<").add(o(H,ei?-(2*r)-6:-(2*r),t),"<").add(o(j,ei?-3:-r,-t),"<").add(o(R,-(e-(ei?3:2)),2*t),"<").add(o(M,2*e+2*r+(ei?7:4),t),"<").add(o(S,2*e+3*r+(ei?9:4),-(2*t)),"<").to(h.current,{yPercent:10,duration:1.5,ease:"power1.inOut"},"<+=0.25").to(k.current,l,">").to(".card.large",{scale:.556,duration:1.5,yPercent:16.5},"<").add(o(j,-(e+i+r-+!ei)),"<").add(o(H,-(2*e+18*!ei)),"<").add(o(v,-(4*e+2*i+12*!ei)),"<").add(o(R,i),"<").add(o(M,4*e+i+15*!ei),"<").add(o(S,5*e+2*i+15*!ei),"<").to(D.current,{autoAlpha:1,duration:1.5,x:ei?0:(0,E.qM)(-(2.2*e)/2)},"<").to(".card.large",{duration:1.5,scale:ei?.83:.663},">+=0.5").add(o(v,-(e*(ei?5.7:5.2)+36)),"<").add(o(j,-(e*(ei?1.9:1.4)+12)),"<").add(o(H,-(e*(ei?3.8:2.8)+24)),"<").add(o(R,e*(ei?.9:.4)+12),"<").add(o(M,e*(ei?5.8:4.8)+24),"<").add(o(S,e*(ei?6.7:6.2)+36),"<").to([H.current,M.current,v.current,S.current],l,">").to([v.current,S.current,H.current,M.current],{y:"+=100",duration:1.5,autoAlpha:0,ease:"power2.in"},"<-=1.5").to(D.current,{autoAlpha:0,duration:1},"<").to(P.current,{autoAlpha:1,duration:1,x:ei?0:(0,E.qM)(-(2.2*e)/2),onComplete:()=>{f.Ay.to(Z.current,{delay:.5,duration:.5,ease:"power1.inOut",y:(0,E.qM)(ee)}),f.Ay.to(G.current,{delay:1,duration:.5,ease:"power1.inOut",y:(0,E.qM)(q)}),f.Ay.fromTo(".pin-path",{stroke:"#777"},{delay:1,duration:.5,ease:"power1.inOut",stroke:"#8f7be3"})}},">").to(V.current,{autoAlpha:1,duration:1.5},"<").to(".card",{scale:1,duration:1.5,yPercent:27},">+=0.5").to(V.current,{autoAlpha:0,duration:1.5},"<").to(h.current,{yPercent:-8,duration:1.5},"<").add(o(j,-(2.6*e+12)),"<").add(o(R,1.6*e+12),"<").to(P.current,{autoAlpha:0,duration:1.5},"<").to([j.current,R.current],{yPercent:200,duration:1.5,autoAlpha:0},">+=0.5").to($.current,{autoAlpha:1,duration:1.5,x:ei?0:(0,E.qM)(-(2.2*e)/2)},">-0.5").call(()=>{f.Ay.to([U.current,W.current],{autoAlpha:0,ease:"power1.out",onComplete:()=>{eo.result?.restart(),eo.result?.pause()}})},[],">-=0.25").to([j.current,R.current],l,">").call(()=>{f.Ay.to([U.current,W.current],{autoAlpha:1,ease:"power2.in",onComplete:()=>{eo.result?.play()}})},[],">").to($.current,{autoAlpha:0,duration:1.5})},o=[et,eo.result,er,ei,q,ee],n[7]=eo.result,n[8]=q,n[9]=ee,n[10]=er,n[11]=et,n[12]=ei,n[13]=i,n[14]=o):(i=n[13],o=n[14]),n[15]===Symbol.for("react.memo_cache_sentinel")?(l={recreateOnResize:!0,scope:a},n[15]=l):l=n[15],(0,w.s)(i,o,l),n[16]!==er?(s=(0,A.jsx)(A.Fragment,{children:er?(0,A.jsx)(A.Fragment,{children:(0,A.jsx)(ef,{})}):(0,A.jsxs)(A.Fragment,{children:[(0,A.jsx)(ti,{ref:a,children:(0,A.jsxs)(to,{ref:y,children:[(0,A.jsxs)(ts,{ref:p,children:[(0,A.jsxs)(tn,{children:[(0,A.jsx)("div",{children:"AI-Powered"}),(0,A.jsx)("div",{children:"All-In-One Tool"}),(0,A.jsx)("div",{children:"Automatically"}),(0,A.jsx)("div",{children:"Organizes Itself"})]}),(0,A.jsxs)(ta,{children:["Micro works the way",(0,A.jsx)("br",{}),"you want to work"]}),(0,A.jsx)(tc,{children:"Micro works the way you want to work"})]}),(0,A.jsx)(tp,{ref:d,children:(0,A.jsx)(td,{})}),(0,A.jsx)(tl,{ref:c,src:e6,alt:""}),(0,A.jsx)(tu,{ref:u,children:(0,A.jsxs)(th,{ref:h,className:"grid-wrapper",children:[(0,A.jsxs)(tH,{ref:D,children:[(0,A.jsx)("h5",{children:"Everything in one place"}),(0,A.jsx)("p",{children:"Fully-featured email client, CRM, task manager and more integrated with Gmail, Calendar, Linkedin, WhatsApp and other tools. Plus the ability to create pipeline trackers, project management tools and more on top of this data."})]}),(0,A.jsxs)(tH,{ref:P,children:[(0,A.jsx)("h5",{children:"Automatically Updated"}),(0,A.jsx)("p",{children:"Everything - companies, people, and more - is enriched with hundreds of datapoints from a rich global and personal knowledge graph. Plus any property can be updated automatically when there's new email or meeting activity."})]}),(0,A.jsxs)(tH,{ref:$,children:[(0,A.jsx)("h5",{children:"Collaborative by default"}),(0,A.jsx)("p",{children:"Create custom apps, objects, properties and more to power any kind of experience you can imagine or use Micro AI to generate it from your description."})]}),(0,A.jsx)(ty,{ref:k,children:(0,A.jsx)(te,{})}),(0,A.jsxs)(tf,{ref:R,className:"card large",children:[(0,A.jsx)(tm,{src:I,alt:""}),(0,A.jsxs)(tW,{children:[(0,A.jsx)(tT,{}),(0,A.jsxs)(tz,{ref:G,children:[(0,A.jsx)(tQ,{children:"Salt Lake City"}),(0,A.jsx)(tQ,{children:"Santa Cruz, CA"})]})]})]}),(0,A.jsx)(tx,{ref:H,className:"card large",src:e7,alt:""}),(0,A.jsx)(tk,{ref:M,className:"card large",src:el,alt:""}),(0,A.jsxs)(tb,{ref:j,className:"card large",children:[(0,A.jsx)(tv,{src:es,alt:""}),(0,A.jsx)(tP,{children:(0,A.jsxs)(t$,{ref:Z,children:[(0,A.jsx)(tU,{children:"Set up time with Eric"}),(0,A.jsx)(tU,{children:"Call Scheduled with Eric"})]})})]}),(0,A.jsxs)(tw,{ref:B,className:"card large",children:[(0,A.jsx)(tC,{src:L,alt:""}),(0,A.jsx)(tV,{ref:J,children:(0,A.jsxs)(tZ,{ref:K,children:[(0,A.jsx)(tG,{className:"crm-ui-text",children:"Demo Meeting"}),(0,A.jsx)(tG,{className:"crm-ui-text",children:"Closed"})]})})]}),(0,A.jsx)(tE,{ref:v,className:"card large",src:e8,alt:""}),(0,A.jsx)(tO,{ref:S,className:"card large",src:_,alt:""}),(0,A.jsx)(z,{ref:V}),(0,A.jsxs)(tB,{ref:U,children:[(0,A.jsxs)("div",{children:[(0,A.jsx)(tj,{}),(0,A.jsx)(tF,{children:"Alec Douglas"})]}),(0,A.jsx)(tR,{ref:Q,children:"killer meeting with Eric today! \uD83D\uDCAA"})]}),(0,A.jsxs)(tM,{ref:W,children:[(0,A.jsx)(tj,{}),(0,A.jsx)(tS,{children:"Max Mason"}),(0,A.jsx)(tD,{ref:T,children:"Omg they signed! \uD83C\uDF89"})]})]})})]})}),(0,A.jsx)(N,{})]})}),n[16]=er,n[17]=s):s=n[17],s}function tr(e,t,r){return f.Ay.to(e.current,{x:(0,E.qM)(t),y:r&&(0,E.qM)(r),duration:1.5,ease:"power2.inOut"})}let ti=(0,v.I4)("section",{...(0,v.vi)((0,v.AH)`
		position: relative;
		display: grid;
		grid-column: fullbleed;
		grid-template-columns: subgrid;
		margin-top: 424px;
	`),...(0,v.ZQ)((0,v.AH)`
		margin-top: 324px;
	`)}),to=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		grid-column: fullbleed;
		height: 300vh;
	`)}),tl=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		position: absolute;
		top: 127px;
		left: 0;
		z-index: 0;
	`),...(0,v.ZQ)((0,v.AH)`
		top: 294px;
	`)}),ts=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 20px;
		z-index: 4;
	`)}),tn=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		display: flex;
		justify-content: space-between;
		color: ${H.A.orange3};
		${j.Ay.kicker2};
		width: 1090px;

		::before {
			display: none;
		}

		::after {
			display: none;
		}
	`),...(0,v.ZQ)((0,v.AH)`
		width: 741px;
	`)}),ta=(0,v.I4)("h1",{...(0,v.vi)((0,v.AH)`
		${j.Ay.oversize3};
		text-align: center;
		width: 1300px;
	`),...(0,v.ZQ)((0,v.AH)`
		display: none;
	`)}),tc=(0,v.I4)("h1",{...(0,v.vi)((0,v.AH)`
		display: none;
	`),...(0,v.ZQ)((0,v.AH)`
		display: block;
		${j.Ay.oversize3};
		text-align: center;
		width: 745px;
	`),...(0,v.PK)((0,v.AH)`
		display: none;
	`)}),tp=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: 372px;
		height: 372px;
		z-index: 3;
		left: 50%;
		top: 202px;
		transform: translateX(-50%);
		backdrop-filter: blur(15px);
		border-radius: 50%;
		background: linear-gradient(
			to bottom,
			color(display-p3 0.9067 0.69 0.4371 / 40%),
			color(display-p3 0.4745 0.3468 0.1979 / 40%)
		);
		will-change: filter;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 242px;
		height: 242px;
		top: 387px;
	`)}),td=(0,v.I4)(eh,{...(0,v.vi)((0,v.AH)`
		overflow: visible;
	`)}),tu=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
		perspective: 900px;
		top: 215px;
		z-index: 1;
	`),...(0,v.ZQ)((0,v.AH)`
		top: 340px;
	`)}),th=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: relative;
		transform: rotate3d(1, 0, 0, 45deg);
		isolation: isolate;
	`)}),ty=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		opacity: 1;
		width: 910px;
		height: 932px;
		position: relative;
		z-index: 0;

		svg {
			width: 100%;
			height: 100%;
			overflow: visible;
			display: block;

			* {
				will-change: filter;
			}
		}
	`),...(0,v.ZQ)((0,v.AH)`
		width: 741px;
		height: 760px;
	`)}),tA=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		box-sizing: border-box;
		position: absolute;
		z-index: 1;
		will-change: transform;
	`)}),tg=(0,v.I4)(tA,{...(0,v.vi)((0,v.AH)`
		width: 633px;
		height: auto;
		object-fit: cover;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 506px;
	`)}),tf=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: 633px;
		height: auto;
		position: absolute;
		z-index: 1;
		will-change: transform;
		right: -223px;
		top: -211px;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 506px;
		right: -177px;
		top: -167px;
	`)}),tm=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		object-fit: cover;
		box-sizing: border-box;
	`)}),tx=(0,v.I4)(tg,{...(0,v.vi)((0,v.AH)`
		left: -224px;
		top: -40px;
	`),...(0,v.ZQ)((0,v.AH)`
		left: -177.5px;
		top: -27.5px;
	`)}),tk=(0,v.I4)(tg,{...(0,v.vi)((0,v.AH)`
		left: 138.5px;
		top: -40px;
	`),...(0,v.ZQ)((0,v.AH)`
		left: 117.5px;
		top: -27px;
	`)}),tb=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: 633px;
		height: auto;
		position: absolute;
		z-index: 1;
		will-change: transform;
		left: -42px;
		top: 302px;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 506px;
		left: -30px;
		top: 250.5px;
	`)}),tv=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		object-fit: cover;
		box-sizing: border-box;
	`)}),tw=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: 633px;
		height: auto;
		position: absolute;
		z-index: 1;
		will-change: transform;
		right: -223px;
		bottom: 32px;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 506px;
		right: -177px;
		bottom: 31px;
	`)}),tC=(0,v.I4)(k.default,{...(0,v.vi)((0,v.AH)`
		object-fit: cover;
		box-sizing: border-box;
	`)}),tE=(0,v.I4)(tg,{...(0,v.vi)((0,v.AH)`
		left: -224px;
		bottom: -138.5px;
	`),...(0,v.ZQ)((0,v.AH)`
		left: -177px;
		bottom: -108px;
	`)}),tO=(0,v.I4)(tg,{...(0,v.vi)((0,v.AH)`
		right: -43px;
		bottom: -138.5px;
	`),...(0,v.ZQ)((0,v.AH)`
		right: -30px;
		bottom: -108px;
	`)}),tH=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: 696px;
		display: flex;
		flex-direction: column;
		gap: 36px;
		color: ${H.A.white1};
		grid-area: copy;
		opacity: 0;
		visibility: hidden;

		h5 {
			${j.Ay.header1};
		}

		p {
			${j.Ay.body2};
			width: 400px;
		}
	`),...(0,v.ZQ)((0,v.AH)`
		width: 741px;
	`)}),tj=(0,v.I4)(M,{...(0,v.vi)((0,v.AH)`
		width: 43px;
		height: 43px;
		filter: drop-shadow(0 7px 7px #000);
	`),...(0,v.ZQ)((0,v.AH)`
		height: 34px;
		width: 34px;
	`)}),tL=(0,v.AH)`
	display: flex;
	flex-direction: column;
	position: absolute;
	scale: 0;
	z-index: 3;
`,t_=(0,v.AH)`
	${j.Ay.body1};
	padding: 16px 24px;
	border-radius: 40px;
	width: fit-content;
`,tI=(0,v.AH)`
	${j.Ay.body2};
	padding: 22px 16px;
	width: fit-content;
	margin-right: 7px;
	scale: 0;
`,tB=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		${tL};
		align-items: flex-end;
		top: 420px;
		left: -150px;
	`),...(0,v.ZQ)((0,v.AH)`
		top: 410px;
		left: -140px;
	`)}),tF=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${t_};
		color: ${H.A.white1};
		background-color: ${H.A.blue1};
		margin: -7px 0 14px;
	`),...(0,v.ZQ)((0,v.AH)`
		${j.Ay.body3};
		padding: 13px 19px;
		border-radius: 32px;
	`)}),tR=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${tI};
		color: ${H.A.white1};
		background-color: ${H.A.blue1};
		border-radius: 16px 0 16px 16px;
		transform-origin: top right;
	`),...(0,v.ZQ)((0,v.AH)`
		${j.Ay.body4};
	`)}),tM=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		${tL};
		top: 542px;
		right: -82px;
	`),...(0,v.ZQ)((0,v.AH)`
		top: 578px;
	`)}),tS=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${t_};
		color: ${H.A.black1};
		background-color: ${H.A.green4};
		margin: -7px 0 9px;
	`),...(0,v.ZQ)((0,v.AH)`
		${j.Ay.body3};
		padding: 13px 19px;
		border-radius: 32px;
	`)}),tD=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		${tI};
		color: ${H.A.black1};
		background-color: ${H.A.green4};
		border-radius: 0 16px 16px;
		transform-origin: top left;
	`),...(0,v.ZQ)((0,v.AH)`
		${j.Ay.body4};
	`)}),tP=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		overflow: clip;
		position: absolute;
		bottom: 58px;
		left: 129px;
		height: 37px;
	`),...(0,v.ZQ)((0,v.AH)`
		left: 110px;
		height: 55px;
		bottom: 38px;
	`)}),t$=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: fit-content;
		transform: translateY(-9px);
	`),...(0,v.ZQ)((0,v.AH)`
		transform: translateY(0);
	`)}),tU=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #c3ccd2;
		font-size: 32.944px;
		font-style: normal;
		font-weight: 500;
		line-height: 150%; /* 49.416px */

		&:last-of-type {
			color: #8f7be3;
		}
	`),...(0,v.ZQ)((0,v.AH)`
		font-size: 22px;
		line-height: 55px;

		&:last-of-type {
			font-size: 21.85px;
			color: #8f7be3;
		}
	`)}),tW=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		overflow: clip;
		position: absolute;
		bottom: 100px;
		left: 40px;
		height: 35px;
		display: flex;
		gap: 7.2px;
		align-items: center;
	`),...(0,v.ZQ)((0,v.AH)`
		overflow: clip;
		position: absolute;
		bottom: 84px;
		left: 30px;
		height: 32px;
		display: flex;
		align-items: center;
	`)}),tz=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		width: fit-content;
		white-space: pre;
		transform: translateY(22px);
	`),...(0,v.ZQ)((0,v.AH)`
		transform: translateY(16px);
	`)}),tQ=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #777;
		font-size: 28.773px;
		font-style: normal;
		font-weight: 500;
		line-height: 44.924px;

		&:last-of-type {
			color: #8f7be3;
		}
	`),...(0,v.ZQ)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #777;
		font-size: 19px;
		font-style: normal;
		font-weight: 500;
		line-height: 150%;

		&:last-of-type {
			color: #8f7be3;
		}
	`)}),tT=(0,v.I4)(eg,{...(0,v.vi)((0,v.AH)`
		width: 25.176px;
		height: 32.369px;
	`),...(0,v.ZQ)((0,v.AH)`
		width: 11px;
		height: 14px;
	`)}),tV=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		overflow: clip;
		position: absolute;
		top: 133px;
		left: 104px;
		height: 52px;
		border-radius: 10.79px;
		border: 2.353px solid #00cfc4;
		width: 266px;
	`),...(0,v.ZQ)((0,v.AH)`
		border-radius: 7%.157px;
		top: 112px;
		left: 80px;
		height: 36px;
		border-width: 1.561px;
		width: 186px;
	`)}),tZ=(0,v.I4)("div",{...(0,v.vi)((0,v.AH)`
		position: absolute;
		width: fit-content;
		white-space: pre;
		transform: translateY(1px);
	`),...(0,v.ZQ)((0,v.AH)`
		transform: translateY(2px);
	`)}),tG=(0,v.I4)("p",{...(0,v.vi)((0,v.AH)`
		font-family: Inter, sans-serif;
		color: #00cfc4;
		font-size: 32.369px;
		font-style: normal;
		font-weight: 500;
		line-height: 42.357px; /* 130.855% */
		margin: 0 18px;
	`),...(0,v.ZQ)((0,v.AH)`
		font-size: 21.47px;
		line-height: 28.094px;
	`)})},9144:(e,t,r)=>{"use strict";r.d(t,{BS:()=>p,Ne:()=>d,_y:()=>c,bJ:()=>a,qM:()=>u}),r(954);var i=r(4764);r(4522);var o=r(9240);r(2478);var l=r(7537),s=r(4052);let n=(()=>{if(!l.Bd)return;let e=document.createElement("div");return e.style.position="absolute",e.style.top="0",e.style.left="0",e.style.width="100%",e.style.height="100vh",e.style.visibility="hidden",document.body.append(e),e})();function a(e){return(n?.clientHeight??0)/100*e}let c=()=>{let{innerWidth:e}=window;return e<=o.ik?"mobile":e<=o.g8?"tablet":e<=o.gR?"desktop":"fullWidth"};function p(e){let t=c(),r=o.ol;return("mobile"===t?r=o.E5:"tablet"===t&&(r=o.KF),l.Bd)?e/(r/100):0}function d(e){return l.Bd?e*(window.innerWidth/100):0}function u(e){let t=d(p(e)),r=Number.parseFloat((e/o.ol*100).toFixed(3))/100*o.gR;return i.A.scaleFully?t:(0,s.x)(r,t,t,t)}},9302:(e,t,r)=>{"use strict";r.d(t,{s:()=>a});var i=r(884),o=r(4522),l=r(2478),s=r(7537);let n="undefined"!=typeof document?o.useLayoutEffect:o.useEffect;i.Ay.config({nullTargetWarn:!1});let a=(e,t,r)=>{let{extraDeps:s=[],recreateOnResize:a=!1,scope:c={current:null},updateBehavior:p="revert",unmountBehavior:d="kill"}=r??{},{innerWidth:u,shouldHydrateUtilities:h}=(0,o.use)(l.cH),y=[...t,...s],A=(0,o.useRef)([]),g=()=>{for(let e of A.current)e();A.current=[]},[f,m]=(0,o.useState)(),[x,k]=(0,o.useState)(i.Ay.context(()=>{})),b=(0,o.useMemo)(()=>e=>x.add(null,e),[x]),v=(0,o.useRef)(x);return v.current=x,n(()=>()=>{v.current.isReverted||("revert"===d?v.current.revert():"kill"===d&&v.current.kill()),x.isReverted||("revert"===d?x.revert():"kill"===d&&x.kill()),"revert"!==d&&g()},[d]),n(()=>{if(!h)return;let t=i.Ay.context(t=>{let r=e({context:t,contextSafe:e=>x.add(null,e)});if("function"==typeof r)return A.current.push(r),r;m(r)},c.current??void 0);return k(t),()=>{if(!t.isReverted)switch(p){case"kill":t.kill(),g();break;case"revert":t.revert()}}},[p,h,a?u:null,p,...y,null]),{contextSafe:b,result:f,context:x}};if((s.Bd?window.gsapVersions??[]:[]).length>1)throw Error("Multiple versions of gsap detected! This will cause MAJOR issues!")},9384:(e,t,r)=>{"use strict";r.d(t,{default:()=>z});var i,o,l,s,n,a,c,p,d,u,h,y,A,g,f=r(8946),m=r(954),x=r(862),k=r(1839),b=r(3336),v=r(5611),w=r(4522),C=r(1285),E=r(9302),O=r(4977);function H(e){let t,r,i,o,l,s,n,a,c,p,d,u;let h=(0,m.c)(24);h[0]!==e?({autoPlay:t,loop:i,muted:o,onLoad:l,ref:n,children:r,...s}=e,h[0]=e,h[1]=t,h[2]=r,h[3]=i,h[4]=o,h[5]=l,h[6]=s,h[7]=n):(t=h[1],r=h[2],i=h[3],o=h[4],l=h[5],s=h[6],n=h[7]);let[y,A]=(0,w.useState)(!1),g=(0,O.A)(n),x=(0,w.useRef)(!1),{completed:k}=(0,C.i)();h[8]!==k||h[9]!==y||h[10]!==g?(a=()=>{if(!k||y)return;let e=e=>{g.current&&(e.start<0||e.end<0||A(!0))};v.u.create({trigger:g.current,start:()=>{if(!g.current)return Number.NEGATIVE_INFINITY;let e=g.current.getBoundingClientRect();return window.scrollY-window.innerHeight+e.top-200},end:()=>{if(!g.current)return Number.NEGATIVE_INFINITY;let e=g.current.getBoundingClientRect();return`+=${e.height+400}`},onEnter:e,onEnterBack:e})},c=[g,k,y],h[8]=k,h[9]=y,h[10]=g,h[11]=a,h[12]=c):(a=h[11],c=h[12]),h[13]===Symbol.for("react.memo_cache_sentinel")?(p={recreateOnResize:!0},h[13]=p):p=h[13],(0,E.s)(a,c,p);let b=o||t;h[14]!==l?(d=e=>{if(!x.current){let t=e.target;x.current=!0,l?.(t)}},h[14]=l,h[15]=d):d=h[15];let H=y&&r;return h[16]!==t||h[17]!==i||h[18]!==s||h[19]!==b||h[20]!==d||h[21]!==H||h[22]!==g?(u=(0,f.jsx)("video",{...s,ref:g,autoPlay:t,muted:b,loop:i,playsInline:!0,onLoadedData:d,children:H}),h[16]=t,h[17]=i,h[18]=s,h[19]=b,h[20]=d,h[21]=H,h[22]=g,h[23]=u):u=h[23],u}var j=r(7606),L=r(2896),_=r(3352),I=r(7248),B=r(9986),F=r(2048),R=r(1442);function M(){return(M=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function S(){return(S=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function D(){return(D=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function P(){return(P=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}function $(){return($=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)({}).hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(null,arguments)}let U=[{videoName:"home",button:"Home",icon:e=>w.createElement("svg",S({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 17 16"},e),s||(s=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M10.5 14V8.66667C10.5 8.48986 10.4298 8.32029 10.3047 8.19526C10.1797 8.07024 10.0101 8 9.83333 8H7.16667C6.98986 8 6.82029 8.07024 6.69526 8.19526C6.57024 8.32029 6.5 8.48986 6.5 8.66667V14"})),n||(n=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M2.5 6.66648C2.49995 6.47253 2.54222 6.2809 2.62386 6.10496C2.70549 5.92902 2.82453 5.77301 2.97267 5.64782L7.63933 1.64848C7.87999 1.44509 8.1849 1.3335 8.5 1.3335C8.8151 1.3335 9.12001 1.44509 9.36067 1.64848L14.0273 5.64782C14.1755 5.77301 14.2945 5.92902 14.3761 6.10496C14.4578 6.2809 14.5 6.47253 14.5 6.66648V12.6665C14.5 13.0201 14.3595 13.3592 14.1095 13.6093C13.8594 13.8593 13.5203 13.9998 13.1667 13.9998H3.83333C3.47971 13.9998 3.14057 13.8593 2.89052 13.6093C2.64048 13.3592 2.5 13.0201 2.5 12.6665V6.66648Z"})))},{videoName:"messages",button:"Messages",icon:e=>w.createElement("svg",D({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 17 16"},e),a||(a=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M13.832 2.6665H3.16536C2.42898 2.6665 1.83203 3.26346 1.83203 3.99984V11.9998C1.83203 12.7362 2.42898 13.3332 3.16536 13.3332H13.832C14.5684 13.3332 15.1654 12.7362 15.1654 11.9998V3.99984C15.1654 3.26346 14.5684 2.6665 13.832 2.6665Z"})),c||(c=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M15.1654 4.6665L9.18536 8.4665C8.97955 8.59545 8.74158 8.66384 8.4987 8.66384C8.25582 8.66384 8.01785 8.59545 7.81203 8.4665L1.83203 4.6665"})))},{videoName:"crm",button:"CRM",icon:e=>w.createElement("svg",M({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 17 16"},e),i||(i=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M12.4987 13.9998C12.4987 12.5853 11.9368 11.2288 10.9366 10.2286C9.93641 9.22841 8.57985 8.6665 7.16536 8.6665C5.75088 8.6665 4.39432 9.22841 3.39413 10.2286C2.39393 11.2288 1.83203 12.5853 1.83203 13.9998"})),o||(o=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M7.16536 8.66667C9.00631 8.66667 10.4987 7.17428 10.4987 5.33333C10.4987 3.49238 9.00631 2 7.16536 2C5.32442 2 3.83203 3.49238 3.83203 5.33333C3.83203 7.17428 5.32442 8.66667 7.16536 8.66667Z"})),l||(l=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M15.1659 13.3335C15.1659 11.0868 13.8326 9.00013 12.4992 8.00013C12.9375 7.67131 13.288 7.23952 13.5196 6.74298C13.7512 6.24643 13.8569 5.70044 13.8272 5.15333C13.7976 4.60622 13.6335 4.07485 13.3495 3.60626C13.0656 3.13767 12.6705 2.7463 12.1992 2.4668"})))},{videoName:"projects",button:"Projects",icon:e=>w.createElement("svg",$({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 17 16"},e),A||(A=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M8.4987 14.6668C12.1806 14.6668 15.1654 11.6821 15.1654 8.00016C15.1654 4.31826 12.1806 1.3335 8.4987 1.3335C4.8168 1.3335 1.83203 4.31826 1.83203 8.00016C1.83203 11.6821 4.8168 14.6668 8.4987 14.6668Z"})),g||(g=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M6.5 7.99984L7.83333 9.33317L10.5 6.6665"})))},{videoName:"ai",button:"Micro AI",icon:e=>w.createElement("svg",P({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 17 16"},e),p||(p=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M7.12625 10.3332C7.06674 10.1025 6.94648 9.89191 6.778 9.72343C6.60952 9.55495 6.39897 9.43469 6.16825 9.37517L2.07825 8.32051C2.00847 8.3007 1.94706 8.25867 1.90333 8.2008C1.8596 8.14293 1.83594 8.07238 1.83594 7.99984C1.83594 7.9273 1.8596 7.85675 1.90333 7.79888C1.94706 7.74101 2.00847 7.69898 2.07825 7.67917L6.16825 6.62384C6.39889 6.56438 6.60938 6.44422 6.77786 6.27587C6.94633 6.10751 7.06663 5.8971 7.12625 5.66651L8.18092 1.57651C8.20053 1.50645 8.24251 1.44474 8.30047 1.40077C8.35843 1.35681 8.42917 1.33301 8.50192 1.33301C8.57467 1.33301 8.64542 1.35681 8.70337 1.40077C8.76133 1.44474 8.80332 1.50645 8.82292 1.57651L9.87692 5.66651C9.93644 5.89722 10.0567 6.10777 10.2252 6.27625C10.3937 6.44473 10.6042 6.56499 10.8349 6.62451L14.9249 7.67851C14.9953 7.69791 15.0573 7.73985 15.1015 7.79789C15.1457 7.85594 15.1696 7.92688 15.1696 7.99984C15.1696 8.0728 15.1457 8.14374 15.1015 8.20179C15.0573 8.25983 14.9953 8.30177 14.9249 8.32117L10.8349 9.37517C10.6042 9.43469 10.3937 9.55495 10.2252 9.72343C10.0567 9.89191 9.93644 10.1025 9.87692 10.3332L8.82225 14.4232C8.80265 14.4932 8.76067 14.5549 8.70271 14.5989C8.64475 14.6429 8.574 14.6667 8.50125 14.6667C8.42851 14.6667 8.35776 14.6429 8.2998 14.5989C8.24184 14.5549 8.19986 14.4932 8.18025 14.4232L7.12625 10.3332Z"})),d||(d=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M13.832 2V4.66667"})),u||(u=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M15.1667 3.3335H12.5"})),h||(h=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M3.16797 11.3335V12.6668"})),y||(y=w.createElement("path",{stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",d:"M3.83333 12H2.5"})))}];function W(e){let t,r,i,o,l;let s=(0,m.c)(13),{videoName:n}=e,a=`/videos/optimized/${n}-low-265.mp4`;s[0]!==a?(t=(0,f.jsx)("source",{type:"video/mp4",src:a,media:"(max-width: 800px)"}),s[0]=a,s[1]=t):t=s[1];let c=`/videos/optimized/${n}-low-264.mp4`;s[2]!==c?(r=(0,f.jsx)("source",{type:"video/mp4",src:c,media:"(max-width: 800px)"}),s[2]=c,s[3]=r):r=s[3];let p=`/videos/optimized/${n}-high-265.mp4`;s[4]!==p?(i=(0,f.jsx)("source",{type:"video/mp4",src:p}),s[4]=p,s[5]=i):i=s[5];let d=`/videos/optimized/${n}-high-264.mp4`;return s[6]!==d?(o=(0,f.jsx)("source",{type:"video/mp4",src:d}),s[6]=d,s[7]=o):o=s[7],s[8]!==t||s[9]!==r||s[10]!==i||s[11]!==o?(l=(0,f.jsxs)(f.Fragment,{children:[t,r,i,o]}),s[8]=t,s[9]=r,s[10]=i,s[11]=o,s[12]=l):l=s[12],l}function z(){let e,t,r,i,o,l,s,n,a,c,p,d,u,h,y;let A=(0,m.c)(23),[g,b]=(0,w.useState)(0),[v,C]=(0,w.useState)(-1),O=U[g],H=U[v],j=(0,w.useRef)(null),L=(0,w.useRef)(null);return O||b(0),A[0]===Symbol.for("react.memo_cache_sentinel")?(e=()=>{let e=j.current,t=e?.parentElement;if(!e||!t)return;let r=e.getBoundingClientRect(),i=t.getBoundingClientRect();k.Ay.set(L.current,{width:r.width,height:r.height,x:r.x-i.x,y:r.y-i.y})},t=[],A[0]=e,A[1]=t):(e=A[0],t=A[1]),A[2]!==g?(r={extraDeps:[g],updateBehavior:"kill",recreateOnResize:!0},A[2]=g,A[3]=r):r=A[3],(0,E.s)(e,t,r),A[4]===Symbol.for("react.memo_cache_sentinel")?(i=(0,f.jsx)(x.A,{size:236,css:{...(0,I.vi)((0,I.AH)`
						top: 525px;
						left: 10px;
						z-index: -1;
					`),...(0,I.ZQ)((0,I.AH)`
						top: 300px;
						left: -50px;
					`)}}),A[4]=i):i=A[4],A[5]===Symbol.for("react.memo_cache_sentinel")?(o=(0,f.jsx)(x.A,{size:165,css:{...(0,I.vi)((0,I.AH)`
						right: 55vw;
						top: 116px;
						z-index: -1;
					`),...(0,I.ZQ)((0,I.AH)`
						right: 45vw;
						top: 0;
					`)}}),A[5]=o):o=A[5],A[6]===Symbol.for("react.memo_cache_sentinel")?(l=(0,f.jsx)(x.A,{size:177,css:{...(0,I.vi)((0,I.AH)`
						right: -100px;
						top: 387px;
						z-index: -1;
					`),...(0,I.ZQ)((0,I.AH)`
						right: -100px;
						top: 800px;
					`)}}),A[6]=l):l=A[6],A[7]===Symbol.for("react.memo_cache_sentinel")?(s=(0,f.jsx)(Z,{children:"Introducing Micro"}),n=(0,f.jsx)(G,{children:"The all-in-one tool that organizes itself"}),A[7]=s,A[8]=n):(s=A[7],n=A[8]),A[9]===Symbol.for("react.memo_cache_sentinel")?(a=(0,f.jsx)(K,{ref:L}),A[9]=a):a=A[9],A[10]!==g?(c=U.map((e,t)=>(0,f.jsxs)(J,{active:t===g,type:"button",onClick:()=>b(t),onMouseEnter:()=>C(t),ref:t===g?j:null,analyticsLocation:null,children:[(0,f.jsx)(e.icon,{}),(0,f.jsx)(Y,{children:e.button})]},e.button)),A[10]=g,A[11]=c):c=A[11],A[12]!==c?(p=(0,f.jsxs)(V,{children:[s,n,(0,f.jsxs)(N,{children:[a,c]})]}),A[12]=c,A[13]=p):p=A[13],A[14]!==H?(d=H&&(0,f.jsx)(X,{muted:!0,playsInline:!0,poster:`/videos/posters/${H.videoName}.webp`,children:(0,f.jsx)(W,{videoName:H.videoName})},H.button),A[14]=H,A[15]=d):d=A[15],A[16]!==O?(u=O&&(0,f.jsx)(q,{children:(0,f.jsx)(ee,{skipFirstAnimation:!0,parameters:{yPercent:void 0,opacity:0},children:(0,f.jsx)(et,{autoPlay:!0,muted:!0,loop:!0,poster:`/videos/posters/${O.videoName}.webp`,children:(0,f.jsx)(W,{videoName:O.videoName})},O.button)})}),A[16]=O,A[17]=u):u=A[17],A[18]===Symbol.for("react.memo_cache_sentinel")?(h=(0,f.jsx)(er,{children:U.map(Q)}),A[18]=h):h=A[18],A[19]!==p||A[20]!==d||A[21]!==u?(y=(0,f.jsxs)(T,{children:[i,o,l,p,d,u,h]}),A[19]=p,A[20]=d,A[21]=u,A[22]=y):y=A[22],y}function Q(e){return(0,f.jsxs)(ei,{children:[(0,f.jsxs)(eo,{children:[(0,f.jsx)(el,{children:e.button}),(0,f.jsx)(e.icon,{})]}),(0,f.jsx)(es,{muted:!0,autoPlay:!0,loop:!0,poster:`/videos/posters/${e.videoName}.webp`,children:(0,f.jsx)(W,{videoName:e.videoName})},e.button)]},e.button)}let T=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		display: grid;
		grid-column: fullbleed;
		grid-template-columns: subgrid;
		padding-top: 341px;
		position: relative;
	`),...(0,I.PK)((0,I.AH)`
		padding-top: 0;
	`)}),V=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		grid-column: main;
		display: grid;
		place-items: center;
		margin-bottom: 30px;
		will-change: transform;
	`),...(0,I.PK)((0,I.AH)`
		margin-bottom: 44px;
	`)}),Z=(0,I.I4)("h1",{...(0,I.vi)((0,I.AH)`
		${F.Ay.oversize4};
		text-align: center;
	`),...(0,I.PK)((0,I.AH)`
		${F.Ay.header5};
	`)}),G=(0,I.I4)("h2",{...(0,I.vi)((0,I.AH)`
		${F.Ay.header3};
		margin-top: 45px;
		margin-bottom: 32px;
		text-align: center;
	`)}),N=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		display: flex;
		padding: 2px;
		gap: 24px;
		align-items: center;
		margin-top: 84px;
		border-radius: 99vw;
		background: rgba(38 41 48 / 60%);
		background: color(display-p3 0.1505 0.1597 0.1873 / 60%);
		backdrop-filter: blur(1px);
		will-change: filter;
	`),...(0,I.PK)((0,I.AH)`
		display: none;
	`)}),K=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		position: absolute;
		top: 0;
		left: 0;
		z-index: -1;
		padding: 11px 17px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 8px;
		border-radius: 99vw;
		border: 1px solid ${B.A.black1};
		background: linear-gradient(
			180deg,
			color(display-p3 0.1101 0.1111 0.1408) 0%,
			color(display-p3 0 0 0) 100%
		);
		width: 100%;
		height: 100%;
		transition: 0.5s ${L.Y.cubic.out};
		transition-property: transform;
	`)}),J=(0,I.I4)(R.AnalyticsLink,({active:e})=>({...(0,I.vi)((0,I.AH)`
		padding: 11px 17px;
		display: flex;
		align-items: center;
		gap: 8px;
		transition: color 0.2s ${L.Y.cubic.out};

		svg {
			width: 16px;
			height: 16px;
			flex-shrink: 0;
		}

		${e?(0,I.AH)`
					color: ${B.A.white1};
				`:(0,I.AH)`
					color: #818a94;
					color: color(display-p3 0.5138 0.5403 0.5758);
				`}
	`)})),Y=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		${F.Ay.body4};
	`)}),X=(0,I.I4)("video",{...(0,I.vi)((0,I.AH)`
		position: absolute;
		opacity: 0;
		pointer-events: none;
		background: white;
	`)}),q=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		grid-column: column-2 / column-11;
		padding: 6px;
		backdrop-filter: blur(7px);
		will-change: filter;
		border-radius: 10px;
		border: 1px solid color(display-p3 1 1 1 / 16%);

		&::before {
			content: "";
			position: absolute;
			inset: 0;
			background: color(display-p3 1 1 1 / 23%);
			border-radius: 9px;
			z-index: -1;
		}

		&::after {
			content: "";
			position: absolute;
			top: 0;
			left: 19px;
			right: 19px;
			height: calc(100% + 18px);
			z-index: -2;
			border-radius: 24px;
			background: #000;
			background: color(display-p3 0 0 0);
			filter: blur(38px);
			will-change: filter;
		}
	`),...(0,I.ZQ)((0,I.AH)`
		grid-column: main;
		margin: 0 64px;
	`),...(0,I.PK)((0,I.AH)`
		display: none;
	`)}),ee=(0,I.I4)(b.A,{...(0,I.vi)((0,I.AH)`
		border-radius: 8px;
	`)}),et=(0,I.I4)(H,{...(0,I.vi)((0,I.AH)`
		width: 100vw;
		max-width: 100%;
		aspect-ratio: 1268 / 694;
		object-fit: cover;
		display: block;
		border-radius: 8px;
		background: white;
	`)});(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		grid-column: column-3 / column-10;
		display: flex;
		justify-content: space-between;
		margin-top: 58px;
	`),...(0,I.ZQ)((0,I.AH)`
		grid-column: column-1-end / column-8-start;
	`),...(0,I.PK)((0,I.AH)`
		grid-column: fullbleed;
		flex-wrap: wrap;
		justify-content: center;
		gap: 22px;
	`)}),(0,I.I4)(j.default,{...(0,I.vi)((0,I.AH)`
		height: 44px;
		width: auto;
	`)});let er=(0,I.I4)("div",{display:"none",...(0,I.PK)((0,I.AH)`
		display: grid;
		gap: 28px;
		grid-column: main;
	`)}),ei=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		background: ${B.A.black5};
		padding: 24px 8px 8px;
		position: relative;
		border-radius: 8px;
		${(0,_.sv)(B.A.electric,1)}
	`)}),eo=(0,I.I4)("div",{...(0,I.vi)((0,I.AH)`
		display: flex;
		margin-bottom: 22px;
		align-items: center;
		justify-content: space-between;

		svg {
			width: 16px;
			height: 16px;
		}
	`)}),el=(0,I.I4)("h2",{...(0,I.vi)((0,I.AH)`
		${F.Ay.header4}
	`)}),es=(0,I.I4)(H,{...(0,I.vi)((0,I.AH)`
		width: 100%;
		border-radius: 5px;
		aspect-ratio: 360/200;
		object-fit: cover;
	`)})}},e=>{var t=t=>e(e.s=t);e.O(0,[896,86,700,821,835,865,242,972,757,513,705,358],()=>t(6267)),_N_E=e.O()}]);