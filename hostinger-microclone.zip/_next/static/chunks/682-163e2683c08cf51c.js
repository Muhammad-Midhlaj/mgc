"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[682],{330:(e,i,t)=>{t.d(i,{default:()=>E});var n=t(8946),r=t(954),l=t(8972),a=t(7248),o=t(9986),s=t(2048),c=t(1442);let d={primary:{color:o.A.green3,fontStyle:s.Ay.body2},black:{color:o.A.black1,fontStyle:s.Ay.kicker2}};function h(e){let i,t,l,a,o,s;let c=(0,r.c)(14);c[0]!==e?({children:i,variant:l,...t}=e,c[0]=e,c[1]=i,c[2]=t,c[3]=l):(i=c[1],t=c[2],l=c[3]);let d=void 0===l?"primary":l;return c[4]!==i||c[5]!==d?(a=(0,n.jsx)(A,{variant:d,children:i}),c[4]=i,c[5]=d,c[6]=a):a=c[6],c[7]!==d?(o=(0,n.jsx)(p,{variant:d}),c[7]=d,c[8]=o):o=c[8],c[9]!==t||c[10]!==a||c[11]!==o||c[12]!==d?(s=(0,n.jsxs)(g,{variant:d,...t,children:[a,o]}),c[9]=t,c[10]=a,c[11]=o,c[12]=d,c[13]=s):s=c[13],s}let g=(0,a.I4)(c.AnalyticsLink,({variant:e="primary"})=>{let i=d[e||"primary"];return{...(0,a.vi)((0,a.AH)`
				display: grid;
				grid-template-columns: 1fr auto;
				gap: 8px;
				color: ${i.color};
				text-decoration: none;
				height: fit-content;
			`)}}),A=(0,a.I4)("div",({variant:e="primary"})=>{let i=d[e||"primary"];return{...(0,a.vi)((0,a.AH)`
				${i.fontStyle?i.fontStyle:""}
				place-self: end;
				color: ${i.color};
			`)}}),p=(0,a.I4)(l.A,({variant:e="primary"})=>{let i=d[e||"primary"];return{...(0,a.vi)((0,a.AH)`
				place-self: start;
				width: 8px;
				height: 8px;
				color: ${i.color};
				fill: ${i.color};
			`)}});var m=t(7606),f=t(4052),v=t(4522),x=t(3568),u=t(6253);let w={src:"/_next/static/media/FooterLogo.7147597f.svg",height:341,width:1540,blurWidth:0,blurHeight:0},C={src:"/_next/static/media/desktop-background.af5ee2d6.png",height:1558,width:3200,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAM1BMVEVMaXHPs5djhFVwe22Gj6aDi3RUg3H/vemXvcgrQEOSjmGdlWZoeFX/yuY+YEonVkg9S0ROucefAAAAD3RSTlMAUfDQZNSpIgv9xr35E/49mx3iAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAJ0lEQVR4nGNggAAOBhYWdgYGBnY2Bj5+ZnYORlZ+Bk4BHm4uJj5OAAiuALzR1hQAAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:4};function b(){return(b=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}function y(){return(y=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let j={src:"/_next/static/media/mobile-background.f8ff292f.png",height:1124,width:750,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAG1BMVEVMaXFEa1m9nbFbeWP/8sKXkWdlg1aUlG9CX08u0dxgAAAACHRSTlMAuVmfFZnU5K3rs4QAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAXSURBVHicY2AgAjAyMbAwM3Cws7JxAAAA6wAtjBXj7AAAAABJRU5ErkJggg==",blurWidth:5,blurHeight:8},H={src:"/_next/static/media/tablet-background.043813a0.png",height:1388,width:2048,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAOVBMVEVMaXE0ZEmyf//Xt5Ofm2+lmJDmo9r/12fywMdqgVyMfm5xeVlKb1v/08usnnGEkGBVfk1beVcsT0JhgJpdAAAAEHRSTlMA/QpHxIEqARPotPfEQKnw4AWmeQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAC1JREFUeJxjYAADdnYGDhDJzsDEwMMKYrKxMghx8nJwMLMIMnDz83GxcAowAgAP3gD5QAuDKgAAAABJRU5ErkJggg==",blurWidth:8,blurHeight:5};function k(){return(k=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}function E(){let e,i,t,l,a,o,s,d,g,A,p,m;let b=(0,r.c)(15),y=(0,v.useRef)(null),k=(0,v.useRef)(null),E=(0,v.useRef)(null),J=(0,v.useRef)(null),W=(0,f.Q)(.8,.8,1,1),K=(0,f.Q)(C,C,H,j);return b[0]===Symbol.for("react.memo_cache_sentinel")?(e=[y,k,E,J],b[0]=e):e=b[0],b[1]===Symbol.for("react.memo_cache_sentinel")?(i={duration:1.3,yPercent:20,opacity:0},b[1]=i):i=b[1],b[2]!==W?(t={triggerPoint:W,from:i},b[2]=W,b[3]=t):t=b[3],(0,u.A)(e,t),b[4]!==K?(l=K&&(0,n.jsx)(L,{src:K,alt:"Footer background"}),b[4]=K,b[5]=l):l=b[5],b[6]===Symbol.for("react.memo_cache_sentinel")?(a=(0,n.jsxs)(S,{ref:y,children:[(0,n.jsx)($,{children:"Organized."}),(0,n.jsx)(I,{children:"So you don't have to be."})]}),b[6]=a):a=b[6],b[7]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)(c.AnalyticsLink,{"aria-label":"Linkedin",href:x.A.linkedin,analyticsLocation:"Footer",children:(0,n.jsx)(P,{})}),b[7]=o):o=b[7],b[8]===Symbol.for("react.memo_cache_sentinel")?(s=(0,n.jsx)(c.AnalyticsLink,{"aria-label":"Instagram",href:x.A.instagram,analyticsLocation:"Footer",children:(0,n.jsx)(R,{})}),b[8]=s):s=b[8],b[9]===Symbol.for("react.memo_cache_sentinel")?(d=(0,n.jsxs)(B,{ref:k,children:[o,s,(0,n.jsx)(c.AnalyticsLink,{"aria-label":"X",href:x.A.x,analyticsLocation:"Footer",children:(0,n.jsx)(Z,{})})]}),b[9]=d):d=b[9],b[10]===Symbol.for("react.memo_cache_sentinel")?(g=(0,n.jsxs)(U,{ref:E,children:[(0,n.jsx)(h,{variant:"black",href:x.A.supportEmail.mail,analyticsLocation:"Footer",children:"Contact Us"}),(0,n.jsx)(h,{variant:"black",href:x.A.careers,analyticsLocation:"Footer",children:"Careers"}),(0,n.jsx)(h,{variant:"black",href:x.A.privacy,analyticsLocation:"Footer",children:"Privacy"}),(0,n.jsx)(h,{variant:"black",href:x.A.terms,analyticsLocation:"Footer",children:"Terms"})]}),A=(0,n.jsx)(F,{ref:J,children:"\xa9 Micro Applications Inc. 2025"}),b[10]=g,b[11]=A):(g=b[10],A=b[11]),b[12]===Symbol.for("react.memo_cache_sentinel")?(p=(0,n.jsxs)(O,{children:[a,d,g,A,(0,n.jsx)(V,{href:x.A.home,analyticsLocation:"Footer",children:(0,n.jsx)(_,{src:w,alt:"Footer Logo"})})]}),b[12]=p):p=b[12],b[13]!==l?(m=(0,n.jsxs)(M,{"data-header-hide":!0,children:[l,p]}),b[13]=l,b[14]=m):m=b[14],m}let M=(0,a.I4)("footer",{...(0,a.vi)((0,a.AH)`
		position: relative;
		color: white;
		display: grid;
		grid-column: 1 / -1;
		grid-template-columns: subgrid;
		grid-template-rows: 1fr;
		overflow: hidden;
		min-height: 500px;
		${o.A.lightDotBackground};
	`)}),O=(0,a.I4)("div",{...(0,a.vi)((0,a.AH)`
		grid-column: scaled-main;
		grid-row: 1;
		position: relative;
		z-index: 2;
		align-self: end;
		height: 100%;
		color: white;
		padding: clamp(12.431vw, 12.431vw, 179px) 0 0;
		display: grid;
		grid-template-columns: subgrid;
		grid-template-rows: 82px 28px 1fr;
	`),...(0,a.ZQ)((0,a.AH)`
		padding: 171px 0 0;
	`),...(0,a.PK)((0,a.AH)`
		padding: 232px 0 0;
		grid-template-rows: 133px auto 69.5px;
	`)}),L=(0,a.I4)(m.default,{...(0,a.vi)((0,a.AH)`
		grid-column: fullbleed;
		grid-row: 1;
		position: relative;
		width: 100%;
		height: 100%;
		object-fit: cover;
		object-position: center center;
		z-index: 1;
	`),...(0,a.PK)((0,a.AH)`
		margin-top: 108px;
	`)}),_=(0,a.I4)(m.default,(0,a.vi)((0,a.AH)`
		width: 100%;
		height: 100%;
	`)),V=(0,a.I4)(c.AnalyticsLink,(0,a.vi)((0,a.AH)`
		width: 100%;
		position: absolute;
		bottom: 0;
		left: 0;
	`)),S=(0,a.I4)("div",{...(0,a.vi)((0,a.AH)`
		grid-column: 1 / -1;
		grid-row: 1;
		position: relative;
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		color: ${o.A.black3};
		border-bottom: 1px solid ${o.A.black3};
		padding-bottom: 32px;
	`),...(0,a.PK)((0,a.AH)`
		flex-direction: column;
		align-items: flex-start;
		padding-bottom: 48px;
		gap: 16px;
		grid-column: 1 / -1;
	`)}),$=(0,a.I4)("div",{...(0,a.vi)((0,a.AH)`
		${s.Ay.header1};
	`),...(0,a.PK)((0,a.AH)`
		${s.Ay.header5};
	`)}),I=(0,a.I4)("div",(0,a.vi)((0,a.AH)`
		${s.Ay.header3};
	`)),B=(0,a.I4)("div",{...(0,a.vi)((0,a.AH)`
			position: relative;
			grid-column: scaled-main / column-3;
			grid-row: 2;
			display: flex;
			gap: 36px;
			flex-wrap: wrap;
			padding-top: 16px;
			align-items: flex-start;
			height: 100%;
		`),...(0,a.ZQ)((0,a.AH)`
			grid-column: 1 / 4;
		`),...(0,a.PK)((0,a.AH)`
			padding-top: 48px;
			grid-column: 1 / -1;
			justify-content: flex-end;
		`)}),R=(0,a.I4)(e=>v.createElement("svg",b({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 13 12"},e),v.createElement("path",{fill:"black",d:"M6.49999 1.0811C8.10207 1.0811 8.29182 1.0872 8.92449 1.11607C9.50949 1.14277 9.82718 1.24051 10.0386 1.32266C10.3187 1.4315 10.5186 1.56154 10.7285 1.77149C10.9385 1.98143 11.0685 2.18133 11.1773 2.46137C11.2595 2.67282 11.3572 2.99051 11.3839 3.57549C11.4128 4.20818 11.4189 4.39794 11.4189 6.00001C11.4189 7.60209 11.4128 7.79184 11.3839 8.42451C11.3572 9.00951 11.2595 9.3272 11.1773 9.53865C11.0685 9.81869 10.9385 10.0186 10.7285 10.2285C10.5186 10.4385 10.3187 10.5685 10.0386 10.6773C9.82718 10.7595 9.50949 10.8573 8.92449 10.884C8.29191 10.9128 8.10216 10.9189 6.49999 10.9189C4.89782 10.9189 4.70807 10.9128 4.07549 10.884C3.49049 10.8573 3.1728 10.7595 2.96137 10.6773C2.68131 10.5685 2.48141 10.4385 2.27146 10.2285C2.06152 10.0186 1.93148 9.81869 1.82266 9.53865C1.74049 9.3272 1.64274 9.00951 1.61604 8.42454C1.58718 7.79184 1.58108 7.60209 1.58108 6.00001C1.58108 4.39794 1.58718 4.20818 1.61604 3.57551C1.64274 2.99051 1.74049 2.67282 1.82266 2.46137C1.93148 2.18133 2.06152 1.98143 2.27146 1.77149C2.48141 1.56154 2.68131 1.4315 2.96137 1.32266C3.1728 1.24051 3.49049 1.14277 4.07546 1.11607C4.70816 1.0872 4.89791 1.0811 6.49999 1.0811ZM6.49999 0C4.87047 0 4.66617 0.00690694 4.02621 0.0361066C3.38755 0.0652587 2.95142 0.166672 2.56975 0.315004C2.1752 0.468338 1.84059 0.673498 1.50703 1.00706C1.17347 1.34061 0.968314 1.67522 0.81498 2.06977C0.666648 2.45144 0.565235 2.88758 0.536083 3.52623C0.506883 4.16617 0.5 4.3705 0.5 6.00001C0.5 7.62953 0.506883 7.83385 0.536083 8.47379C0.565235 9.11245 0.666648 9.54858 0.81498 9.93025C0.968314 10.3248 1.17347 10.6594 1.50703 10.993C1.84059 11.3265 2.1752 11.5317 2.56975 11.685C2.95142 11.8334 3.38755 11.9348 4.02621 11.9639C4.66617 11.9931 4.87047 12 6.49999 12C8.1295 12 8.33383 11.9931 8.97377 11.9639C9.61242 11.9348 10.0486 11.8334 10.4302 11.685C10.8248 11.5317 11.1594 11.3265 11.4929 10.993C11.8265 10.6594 12.0317 10.3248 12.185 9.93025C12.3333 9.54858 12.4347 9.11245 12.4639 8.47379C12.4931 7.83385 12.5 7.62953 12.5 6.00001C12.5 4.3705 12.4931 4.16617 12.4639 3.52623C12.4347 2.88758 12.3333 2.45144 12.185 2.06977C12.0317 1.67522 11.8265 1.34061 11.4929 1.00706C11.1594 0.673498 10.8248 0.468338 10.4302 0.315004C10.0486 0.166672 9.61242 0.0652587 8.97377 0.0361066C8.33383 0.00690694 8.1295 0 6.49999 0ZM6.49999 2.91892C4.79836 2.91892 3.4189 4.29838 3.4189 6.00001C3.4189 7.70164 4.79836 9.0811 6.49999 9.0811C8.20162 9.0811 9.58108 7.70164 9.58108 6.00001C9.58108 4.29838 8.20162 2.91892 6.49999 2.91892ZM6.49999 8.00002C5.39543 8.00002 4.49998 7.10457 4.49998 6.00001C4.49998 4.89545 5.39543 4 6.49999 4C7.60455 4 8.5 4.89545 8.5 6.00001C8.5 7.10457 7.60455 8.00002 6.49999 8.00002ZM10.4228 2.79719C10.4228 3.19484 10.1005 3.5172 9.70281 3.5172C9.30516 3.5172 8.98279 3.19484 8.98279 2.79719C8.98279 2.39954 9.30516 2.0772 9.70281 2.0772C10.1005 2.0772 10.4228 2.39954 10.4228 2.79719Z",style:{fill:"black",fillOpacity:1}})),{...(0,a.vi)((0,a.AH)`
		height: 12px;
		overflow: visible;
	`)}),P=(0,a.I4)(e=>v.createElement("svg",y({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 13 12"},e),v.createElement("path",{fill:"black",d:"M0 1.39394C0 0.989891 0.14077 0.656558 0.422297 0.393939C0.703825 0.131309 1.06982 0 1.52027 0C1.96268 0 2.32062 0.129285 2.59411 0.387879C2.87564 0.654545 3.01641 1.00201 3.01641 1.4303C3.01641 1.81818 2.87967 2.14141 2.60618 2.4C2.32465 2.66667 1.95463 2.8 1.49614 2.8H1.48407C1.04166 2.8 0.683723 2.66667 0.410232 2.4C0.13674 2.13333 0 1.79798 0 1.39394ZM0.156853 12V3.90303H2.83542V12H0.156853ZM4.3195 12H6.99807V7.47879C6.99807 7.19595 7.03025 6.97777 7.09459 6.82424C7.2072 6.54949 7.37814 6.31716 7.60738 6.12727C7.83663 5.93737 8.12419 5.84242 8.47008 5.84242C9.37098 5.84242 9.82143 6.45252 9.82143 7.67273V12H12.5V7.35758C12.5 6.16161 12.2185 5.25455 11.6554 4.63636C11.0923 4.01818 10.3483 3.70909 9.42326 3.70909C8.38562 3.70909 7.57722 4.15758 6.99807 5.05455V5.07879H6.986L6.99807 5.05455V3.90303H4.3195C4.33558 4.16161 4.34363 4.96565 4.34363 6.31515C4.34363 7.66464 4.33558 9.55959 4.3195 12Z",style:{fill:"black",fillOpacity:1}})),{...(0,a.vi)((0,a.AH)`
		height: 12px;
		overflow: visible;
	`)}),Z=(0,a.I4)(e=>v.createElement("svg",k({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 13 12"},e),v.createElement("path",{fill:"black",d:"M7.49289 5.08125L11.8671 0H10.8304L7.03245 4.41188L3.99888 0H0.5L5.08731 6.67163L0.5 12H1.53664L5.54756 7.34091L8.75112 12H12.25L7.4926 5.08125H7.49289ZM6.07311 6.73031L5.60826 6.066L1.91012 0.779812H3.50233L6.48664 5.046L6.95139 5.71031L10.8309 11.2556H9.23886L6.07311 6.73059V6.73031Z",style:{fill:"black",fillOpacity:1}})),{...(0,a.vi)((0,a.AH)`
		height: 12px;
		overflow: visible;
	`)}),F=(0,a.I4)("p",{...(0,a.vi)((0,a.AH)`
		grid-column: scaled-main;
		${s.Ay.kicker3};
		color: ${o.A.black1};
		margin-top: 24px;
		position: relative;
		z-index: 1;
		place-self: start;
	`),...(0,a.PK)((0,a.AH)`
		grid-row: 2/3;
		margin-top: 16px;
	`)}),U=(0,a.I4)("div",{...(0,a.vi)((0,a.AH)`
		grid-column: column-5-start / column-8-end;
		grid-row: 2;
		display: flex;
		justify-content: space-between;
		padding-top: 16px;
	`),...(0,a.ZQ)((0,a.AH)`
		grid-column: column-4-start / main-end;
	`),...(0,a.PK)((0,a.AH)`
		padding-top: 56px;
		grid-column: column-1-start / column-3-end;
		flex-direction: column;
		gap: 24px;
		align-items: flex-start;
		justify-content: flex-start;
	`)})},1765:(e,i,t)=>{t.d(i,{default:()=>M});var n,r,l,a,o,s=t(8946),c=t(954),d=t(4522);function h(){return(h=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let g=e=>d.createElement("svg",h({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 95 22"},e),n||(n=d.createElement("path",{fill:"white",d:"M49.8514 22C47.7968 22 45.9751 21.5395 44.3862 20.6186C42.7974 19.6976 41.5646 18.411 40.688 16.7586C39.8114 15.0792 39.373 13.1696 39.373 11.0297C39.373 8.88984 39.8114 6.99374 40.688 5.34143C41.5646 3.68911 42.7974 2.40247 44.3862 1.48151C45.9751 0.560548 47.7968 0.100067 49.8514 0.100067C52.2895 0.100067 54.3441 0.736615 56.0152 2.00971C57.7136 3.25572 58.7409 4.94866 59.097 7.08854L55.3166 7.77927H55.1522C54.9057 6.53326 54.303 5.51749 53.3442 4.73197C52.3854 3.94644 51.2348 3.55367 49.8925 3.55367C47.9749 3.55367 46.4271 4.2444 45.2492 5.62584C44.0712 6.9802 43.4822 8.78149 43.4822 11.0297C43.4822 13.278 44.0712 15.0928 45.2492 16.4742C46.4271 17.8557 47.9749 18.5464 49.8925 18.5464C51.317 18.5464 52.5087 18.1536 53.4675 17.3681C54.4263 16.5555 55.0427 15.4178 55.3166 13.9551L59.2614 14.6865C58.8231 16.9618 57.7547 18.7495 56.0563 20.0497C54.3852 21.3499 52.3169 22 49.8514 22Z"})));function A(){return(A=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let p=e=>d.createElement("svg",A({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 95 22"},e),r||(r=d.createElement("path",{fill:"white",d:"M34.0731 21.9561V0.100067H38.2463V21.9561H34.0731Z"})));function m(){return(m=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let f=e=>d.createElement("svg",m({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 95 22"},e),l||(l=d.createElement("path",{fill:"white",fillRule:"evenodd",d:"M14.3079 9.25599V21.9561H18.481L18.481 18.8389V9.25599C18.481 6.48297 20.7498 4.235 23.5484 4.235C26.347 4.235 28.6158 6.48297 28.6158 9.25599V21.9561H32.7889V9.25599C32.7889 4.19931 28.6518 0.100067 23.5484 0.100067C20.6644 0.100067 18.089 1.40915 16.3944 3.46032C14.6999 1.40915 12.1245 0.100067 9.2405 0.100067C4.13711 0.100067 0 4.19931 0 9.25599V21.9561H4.17313V9.25599C4.17313 6.48297 6.44187 4.235 9.2405 4.235C12.0391 4.235 14.3079 6.48297 14.3079 9.25599Z",clipRule:"evenodd"})));function v(){return(v=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let x=e=>d.createElement("svg",v({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 95 22"},e),a||(a=d.createElement("path",{fill:"white",fillRule:"evenodd",d:"M83.8948 18.1233C87.8666 18.1233 91.0863 14.9341 91.0863 11C91.0863 7.06586 87.8666 3.87664 83.8948 3.87664C79.9231 3.87664 76.7034 7.06586 76.7034 11C76.7034 14.9341 79.9231 18.1233 83.8948 18.1233ZM83.8948 21.9999C90.0281 21.9999 95 17.0751 95 11C95 4.92485 90.0281 0 83.8948 0C77.7616 0 72.7897 4.92485 72.7897 11C72.7897 17.0751 77.7616 21.9999 83.8948 21.9999Z",clipRule:"evenodd"})));function u(){return(u=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var n in t)({}).hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}).apply(null,arguments)}let w=e=>d.createElement("svg",u({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 95 22"},e),o||(o=d.createElement("path",{fill:"white",d:"M60.3721 10.4994C60.3721 4.75628 65.071 0.100067 70.8675 0.100067H73.7992V4.21345H70.8675C67.3638 4.21345 64.5235 7.02793 64.5235 10.4994V21.8546H60.3721V10.4994Z"})));var C=t(2896),b=t(3352),y=t(1285),j=t(7248),H=t(9986),k=t(2048);let E=(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("div",{children:"0"}),(0,s.jsx)("div",{children:"1"}),(0,s.jsx)("div",{children:"2"}),(0,s.jsx)("div",{children:"3"}),(0,s.jsx)("div",{children:"4"}),(0,s.jsx)("div",{children:"5"}),(0,s.jsx)("div",{children:"6"}),(0,s.jsx)("div",{children:"7"}),(0,s.jsx)("div",{children:"8"}),(0,s.jsx)("div",{children:"9"})]});function M(){let e,i,t,n,r,l,a,o,h,A,m,v,u,C;let b=(0,c.c)(16),j=(0,d.useRef)(null);b[0]===Symbol.for("react.memo_cache_sentinel")?(e={minDuration:1e3,stopAnimations:".logo > div",scope:j},b[0]=e):e=b[0];let{completed:H,ready:k,isAtPageTop:M}=(0,y.i)(e);return H?null:(b[1]===Symbol.for("react.memo_cache_sentinel")?(i=(0,s.jsxs)($,{className:"logo",children:[(0,s.jsx)("div",{children:(0,s.jsx)(f,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(p,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(g,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(w,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(x,{})})]}),b[1]=i):i=b[1],b[2]===Symbol.for("react.memo_cache_sentinel")?(t=(0,s.jsxs)(V,{children:[i,(0,s.jsxs)($,{className:"logo",children:[(0,s.jsx)("div",{children:(0,s.jsx)(f,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(p,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(g,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(w,{})}),(0,s.jsx)("div",{children:(0,s.jsx)(x,{})})]})]}),b[2]=t):t=b[2],b[3]===Symbol.for("react.memo_cache_sentinel")?(n=(0,s.jsx)(R,{}),b[3]=n):n=b[3],b[4]===Symbol.for("react.memo_cache_sentinel")?(r=(0,s.jsxs)(F,{children:[(0,s.jsx)("div",{children:"\xa0"}),(0,s.jsx)("div",{children:"\xa0"}),(0,s.jsx)("div",{children:"\xa0"}),(0,s.jsx)("div",{children:"\xa0"}),(0,s.jsx)("div",{children:"\xa0"}),(0,s.jsx)("div",{children:"1"})]}),b[4]=r):r=b[4],b[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,s.jsxs)(F,{children:[E,(0,s.jsx)("div",{children:"0"})]}),b[5]=l):l=b[5],b[6]===Symbol.for("react.memo_cache_sentinel")?(a=(0,s.jsxs)(F,{children:[E,E,E,E,E,E,(0,s.jsx)("div",{children:"0"})]}),b[6]=a):a=b[6],b[7]===Symbol.for("react.memo_cache_sentinel")?(m=(0,s.jsxs)(B,{children:[n,(0,s.jsxs)(P,{children:[r,l,a,(0,s.jsx)(F,{children:(0,s.jsx)("div",{children:"%"})})]})]}),v=(0,s.jsx)(S,{}),u=(0,s.jsx)(Z,{}),o=(0,s.jsx)(I,{}),h=(0,s.jsx)(O,{}),A=(0,s.jsx)(L,{}),b[7]=o,b[8]=h,b[9]=A,b[10]=m,b[11]=v,b[12]=u):(o=b[7],h=b[8],A=b[9],m=b[10],v=b[11],u=b[12]),b[13]!==M||b[14]!==k?(C=(0,s.jsxs)(_,{ref:j,ready:k,isAtTop:M,children:[t,m,v,u,o,h,A]}),b[13]=M,b[14]=k,b[15]=C):C=b[15],C)}let O=(0,j.i7)`
	0% {
		transform: translate(0, 0);
	}
	30% {
		transform: translate(0, 1px);
	}
	100% {
		transform: translate(0, -110vh);
	}
`,L=(0,j.i7)`
	from {
		opacity: 1;
	}
	to {
		opacity: 0;
	}
`,_=(0,j.I4)("div",({ready:e,isAtTop:i})=>({...(0,j.vi)((0,j.AH)`
			position: fixed;
			top: 50%;
			left: 50%;
			translate: -50% -50%;
			z-index: 1000;
			overflow: clip;

			/* overflow: clip visible causes a weird rendering bug in firefox, so padding it is (prevents number clipping) */
			padding: 100px 0;

			${e?i?(0,j.AH)`
							animation: ${O} 1.5s ${C.Y.cubic.inOut} both;
						`:(0,j.AH)`
							animation: ${L} 1s ${C.Y.quad.out} both;
						`:""}
		`),...(0,j.PK)((0,j.AH)`
			scale: 0.68;
		`)})),V=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		--gap: 60px;

		padding: 15px 30px;
		border-radius: 20px;
		position: relative;
		isolation: isolate;
		background: ${H.A.black2};
		overflow: clip;
		display: grid;
		gap: var(--gap);
		height: 130px;

		${(0,b.sv)(H.A.electric,3)}
	`)}),S=(0,j.i7)`
	0% {
		translate: 0 0;
	}
	100% {
		translate: 0 calc(-100% - var(--gap) + var(--render-compensation));
	}
`,$=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		--base-delay: 300ms;

		display: grid;

		> * {
			grid-area: 1/1/2/2;
			width: 627px;
			animation: ${S} ${1.3}s infinite;

			/* safari won't accelerate this if it has a positive delay */
			animation-delay: -160ms;
			margin: -100px;
			padding: 100px;

			/* firefox will unrender the letter if it leaves the wrapper, add padding so it never leaves */
			--render-compensation: 200px;

			:nth-child(2) {
				animation-delay: -120ms;
			}

			:nth-child(3) {
				animation-delay: -80ms;
			}

			:nth-child(4) {
				animation-delay: -40ms;
			}

			:nth-child(5) {
				animation-delay: 0ms;
			}
		}
	`)}),I=(0,j.i7)`
	from {
		translate: var(--bar-width) 0;
	}
	to {
		translate: 0 0;
	}
`,B=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		display: flex;
		align-items: end;
		gap: 8px;
		margin-top: 18px;

		--bar-width: -400px;

		> * {
			animation: ${I} ${1.3}s ${C.Y.cubic.inOut} both;
		}
	`)}),R=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		height: 1px;
		background: ${H.A.black6};
		flex-grow: 1;
	`),minHeight:"1.5px"}),P=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		display: flex;
		overflow: clip;
		height: 26px;
		padding: 6.5px 0;
		margin: -6.5px 0;
	`)}),Z=(0,j.i7)`
from {
	translate: 0 0;
}
to {
	translate: 0 calc(-100% + var(--digit-height));
}
`,F=(0,j.I4)("div",{...(0,j.vi)((0,j.AH)`
		--digit-height: 13.1px;
		--top-padding: 10px;

		animation: ${Z} ${1.3}s ${C.Y.cubic.out} both;
		height: fit-content;

		> div {
			min-height: var(--digit-height);

			:not(:first-child) {
				padding-top: var(--top-padding);
			}

			${k.Ay.body1}
		}
	`)})},4052:(e,i,t)=>{t.d(i,{Q:()=>o,x:()=>s});var n=t(4522),r=t(9240),l=t(2478),a=t(7537);function o(e,i,t,r){let{desktop:a,fullWidth:o,mobile:s,tablet:c}=(0,n.use)(l.cH);if(o)return e;if(a)return i;if(c)return t;if(s)return r;throw Error("useMedia must be used within a ScreenProvider")}function s(e,i,t,n){return!a.Bd||window.innerWidth<=r.ik?n:window.innerWidth>r.ik&&window.innerWidth<=r.g8?t:window.innerWidth>r.g8&&window.innerWidth<=r.gR?i:window.innerWidth>r.gR?e:void 0}},6253:(e,i,t)=>{t.d(i,{A:()=>c,U:()=>s});var n=t(884),r=t(5611),l=t(7537),a=t(9302),o=t(4522);function s(e,i){if(0===e.length)return[];let{triggerPoint:t=.9,duration:r=.8,ease:l="power3.inOut",delay:a=.15,from:o={yPercent:100,opacity:0},to:s={yPercent:0,opacity:1}}=i,c=[];if(1===e.length){let i=n.Ay.timeline({scrollTrigger:{trigger:e[0],start:`clamp(top ${100*t}%)`,toggleActions:"play none none reverse"}});n.Ay.set(e,o),i.to(e,{...s,duration:r,ease:l},a),c.push(i)}else for(let i of e){n.Ay.set(i,o);let e=n.Ay.timeline({scrollTrigger:{trigger:i,start:`clamp(top ${100*t}%)`,toggleActions:"play none none reverse"}});e.to(i,{...s,duration:r,ease:l},a),c.push(e)}return c}function c(e,i={}){let t=(0,o.useRef)(i);t.current=i,(0,a.s)(()=>{if(!e||!l.Bd)return;let i=(Array.isArray(e)?e:[e]).map(e=>e.current).filter(Boolean);0!==i.length&&s(i,t.current)},[e])}n.Ay.registerPlugin(r.u)},7606:(e,i,t)=>{t.d(i,{default:()=>d});var n=t(8946),r=t(954),l=t(7248),a=t(7865),o=t(4522);let s=(0,o.createContext)(!1),c=(e,i)=>i?"eager":"default"!==e?void 0!==e?e:"lazy":void 0;function d(e){let i,t,l,a,d,h,p,m,f,v;let x=(0,r.c)(27);x[0]!==e?({src:a,alt:d,objectFit:h,objectPosition:t,loading:i,sizes:p,...l}=e,x[0]=e,x[1]=i,x[2]=t,x[3]=l,x[4]=a,x[5]=d,x[6]=h,x[7]=p):(i=x[1],t=x[2],l=x[3],a=x[4],d=x[5],h=x[6],p=x[7]);let u=void 0===d?"":d,w=void 0===h?"cover":h,C=void 0===p?"100vw":p;if(!a)return null;let b=(0,o.use)(s);x[8]!==b||x[9]!==i?(m=c(i,b),x[8]=b,x[9]=i,x[10]=m):m=x[10];let y=m;x[11]!==u||x[12]!==w||x[13]!==t||x[14]!==l||x[15]!==y?(f={objectFit:w,objectPosition:t,alt:u,loading:y,...l},x[11]=u,x[12]=w,x[13]=t,x[14]=l,x[15]=y,x[16]=f):f=x[16];let j=f;if("string"==typeof a){let e;let i=j.width&&j.height?`${j.width}/${j.height}`:"";return x[17]!==j||x[18]!==a||x[19]!==i?(e=(0,n.jsx)(g,{...j,src:a,aspectRatio:i}),x[17]=j,x[18]=a,x[19]=i,x[20]=e):e=x[20],e}let H=a.src.endsWith(".svg")||a.src.startsWith("data:image/svg+xml")?void 0:"blur",k=j.width&&j.height?`${j.width}/${j.height}`:void 0;return x[21]!==j||x[22]!==C||x[23]!==a||x[24]!==H||x[25]!==k?(v=(0,n.jsx)(A,{placeholder:H,...j,src:a,sizes:C,aspectRatio:k}),x[21]=j,x[22]=C,x[23]=a,x[24]=H,x[25]=k,x[26]=v):v=x[26],v}let h=({objectFit:e,objectPosition:i,aspectRatio:t})=>({display:"block",objectFit:e,objectPosition:i,height:"auto",width:"100%",aspectRatio:t}),g=(0,l.I4)("img",h),A=(0,l.I4)(a.default,h)}}]);